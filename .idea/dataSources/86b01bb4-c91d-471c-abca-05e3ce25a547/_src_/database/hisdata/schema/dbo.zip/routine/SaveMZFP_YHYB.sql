CREATE PROCEDURE [dbo].[SaveMZFP_YHYB] 
(@fpnum integer,@fpname char(20),@opername char(10),@currentdate datetime,@fpmoney numeric(12,2),@userid numeric(18),
 @ybcardnum char(20),@ybnum char(20),@ybareacodeval char(4)=null,@ybareaname varchar(20),@ybattrib char(20),@fpflag integer,@age numeric(8,2)=null,
 @sex char(10),@transaction_no char(20),@serial_no char(20),@dwbm char(10),@dwmc char(60),@arranger char(20),@section_name char(50),
 @sicksortcode char(10),@ryxx_qfx numeric(12,2),@ryxx_tclj numeric(12,2),@ryxx_dczfxe numeric(12,2),@ryxx_dbxe numeric(12,2),
 @ryxx_jslj numeric(12,2),@ryxx_qfxinfo char(20),@ryxx_spbzbm char(50),@ryxx_yyxz char(20),@selfpay numeric(12,2),
 @hookpay numeric(12,2),@tcpay numeric(12,2),@tcselfpay numeric(12,2),@basepay numeric(12,2),@outpay numeric(12,2),@preqpay numeric(12,2),
 @dbzf numeric(12,2),@actualselfpay numeric(12,2),@subsidypay numeric(12,2),@officialpay numeric(12,2),@ryzt char(3),
 @tsggzfbf numeric(12,2),@initinstitution char(10),@feebalancetype char(10),@xtcs numeric(12,2),@cardleftmoney numeric(12,2),
 @cardmoney numeric(12,2),@xjmoney numeric(12,2),@oldfpnumval int=null,@retval varchar(1024)='' output,@mznum int=null,@patientid nvarchar(10)=null,
 @tgbz numeric(12,2)=null,@txbz numeric(12,2)=null,@cyyy varchar(3)=null,@tcqcode varchar(6)=null,@jylsnum varchar(30)=null,@jyyznum varchar(30)=null,
 @jsid varchar(20)=null,@fhbcfwmoney numeric(16,2)=null,@tcpercent numeric(10,4)=null,@dbpercent numeric(10,4)=null,@ylzgrypay numeric(16,2)=null,
 @qybcyljjpay numeric(16,2)=null,@otherbzjjpay numeric(16,2)=null,@mzyljzpay numeric(16,2)=null,@mzyljjpay numeric(16,2)=null,@tczybzpay numeric(16,2)=null,
 @dbzybzpay numeric(16,2)=null,@ydflag char(1)=null,@ywzqnum varchar(30)=null,@delywzqnum varchar(30)=null,@yllbcode varchar(3)=null,@ybfpmoney numeric(16,2)=null,
 @OfficialDBPay numeric(14,2)=null,@OfficialCXPay numeric(14,2)=null,@SubsidyZX1Pay numeric(14,2)=null,@SubsidyZX2Pay numeric(14,2)=null,@yyzfpay numeric(16,2)=null,
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  if (exists(select userid from _yhyb_transsheet (nolock) where userid=@userid)) or (@oldfpnumval is not null)
  begin
    declare @ybmoney numeric(12,2)
    if @oldfpnumval is null
    begin 
      if @ybfpmoney is null
        select @ybmoney=sum(xmmoney) from _yhyb_transsheet where userid=@userid
      else
        set @ybmoney=@ybfpmoney
    end else
    begin
      select @ybmoney=-ybmoney from yhyb_invoicebase (nolock) where fpnum=@oldfpnumval
    end

    declare @ybzf numeric(12,2)
    select @ybzf=@ybmoney-@xjmoney-ISNULL(@yyzfpay,0)
    declare @yberror numeric(12,2)
    select @yberror=0
    select @yberror=@fpmoney-@ybmoney


    declare @ybareacode char(10)
    if @ybareacodeval is not null
    begin
       set @ybareacode=@ybareacodeval
    end else
    begin
        if @ybareaname='省医保' 
          set @ybareacode='00'
        else
          set @ybareacode='01'
    end
   
    declare @yldyname char(20)
    if @ybareacodeval is not null
    begin
        set @yldyname=@ybareaname
    end else
    begin
        if @ybattrib=1
          set @yldyname=@ybareaname+'职工'
        else if @ybattrib=2
          set @yldyname=@ybareaname+'居民'
        else
          set @yldyname=@ybareaname+'离休'
    end

    declare @ret int
    execute @ret=SaveMZFP @fpnum=@fpnum,
                          @userid=@userid,
                          @fpname=@fpname,
                          @fpmoney=@fpmoney,
                          @opername=@opername,
                          @retval=@retval output,
                          @currentdate=@currentdate,
                          @oldfpnum=@oldfpnumval,
                          @ybflag=1,
                          @ybnum=@ybnum,
                          @jfcardid=null,
                          @roundflag=null,
                          @ybareacode=@ybareacode,
                          @ybareaname=@yldyname,
                          @zfmoney1=@ybzf,
                          @zfmoney2=@xjmoney,
                          @roundmoney=null,
                          @mznum=@mznum,
                          @yldyname=@ybareaname,
                          @fpnum_tmp=null,
                          @yberror=@yberror,
                          @patientid=@patientID,
                          @zfmoney3=@yyzfpay,
                          @InvoiceNum=@InvoiceNum,
                          @InvoiceOperID=@InvoiceOperID,
                          @sex=@sex
                          
    /*exec @ret=SaveMZFP @fpnum,@userid,@fpname,@fpmoney,@opername,@retval output,@currentdate,
         @oldfpnumval,1,@ybnum,null,null,@ybareacode,@yldyname,@ybzf,@xjmoney,
         null,@mznum,@ybareaname,null,@yberror,@patientID*/
    if @ret <> 0 
      return @ret

    if @oldfpnumval is null
      insert yhyb_transsheet(FPNum,FPFlag,Transaction_No,Serial_No,Data_Number,Charge_Category,Charge_Item,Charge_Name,
             XMCount,Price,XMMoney,Pr_Area,Usage_Dosage,Standard,Arranger,Section_Name,Doctor_Name,JZ_DateTime,Pay_Proportion,
             Pay_Amount,Wipe_Amount,Digose,Unit,XMCode,XMName,CFNum,CFSheetNum,KMCode,Section_Code,AllSelfPay,OutSelfPay,
             GGSelfPay,FHBCFWMoney,YBLBCode,JYLSNum,CheckNum,JZLSNum,XMSPName,BZ,CZ,Dose)
      select @FPNum,@FPFlag,Transaction_No,Serial_No,Data_Number,Charge_Category,Charge_Item,Charge_Name,
             XMCount,Price,XMMoney,Pr_Area,Usage_Dosage,Standard,Arranger,Section_Name,Doctor_Name,JZ_DateTime,Pay_Proportion,
             Pay_Amount,Wipe_Amount,Digose,Unit,XMCode,XMName,CFNum,CFSheetNum,KMCode,Section_Code,AllSelfPay,OutSelfPay,
             GGSelfPay,FHBCFWMoney,YBLBCode,JYLSNum,CheckNum,JZLSNum,XMSPName,BZ,CZ,Dose
        from _yhyb_transsheet (nolock) where userid=@userid
    else
      insert yhyb_transsheet(FPNum,FPFlag,Transaction_No,Serial_No,Data_Number,Charge_Category,Charge_Item,Charge_Name,
             XMCount,Price,XMMoney,Pr_Area,Usage_Dosage,Standard,Arranger,Section_Name,Doctor_Name,JZ_DateTime,Pay_Proportion,
             Pay_Amount,Wipe_Amount,Digose,Unit,XMCode,XMName,CFNum,CFSheetNum,KMCode,Section_Code,AllSelfPay,OutSelfPay,
             GGSelfPay,FHBCFWMoney,YBLBCode,JYLSNum,CheckNum,JZLSNum,XMSPName,BZ,CZ,Dose)
      select @FPNum,FPFlag,Transaction_No,Serial_No,Data_Number,Charge_Category,Charge_Item,Charge_Name,
             -XMCount,Price,-XMMoney,Pr_Area,Usage_Dosage,Standard,Arranger,Section_Name,Doctor_Name,JZ_DateTime,Pay_Proportion,
             -Pay_Amount,-Wipe_Amount,Digose,Unit,XMCode,XMName,CFNum,CFSheetNum,KMCode,Section_Code,-AllSelfPay,-OutSelfPay,
             -GGSelfPay,-FHBCFWMoney,YBLBCode,JYLSNum,CheckNum,JZLSNum,XMSPName,BZ,CZ,Dose
        from yhyb_transsheet (nolock) where fpnum=@oldfpnumval


    insert yhyb_invoicebase(ybcardnum,ybnum,YBAreaCode,YBAreaName,FPFlag,YBAttrib,FPNum,FPName,age,sex,Transaction_No,
                            Serial_No,DWBM,DWMC,Arranger,Section_Name,SicksortCode,Selfpay,Hookpay,Tcpay,TcSelfpay,
                            Basepay,Outpay,Preqpay,Dbzf,ActualSelfpay,SubsidyPay,OfficialPay,Ryzt,Tsggzfbf,Initinstitution,
                            FeebalanceType,CardLeftMoney,CardMoney,XJMoney,YBMoney,FPMoney,YBError,FPOper,FPDate,mznum,
                            patientstate,TGBZ,TXBZ,CYYY,TCQCode,JYLSNum,JYYZNum,JSID,FHBCFWMoney,TCPercent,DBPercent,YLZGRYPay,
                            QYBCYLJJPay,OtherBZJJPay,MZYLJZPay,MZYLJJPay,TCZYBZPay,DBZYBZPay,YDFlag,YWZQNum,DelYWZQNum,YLLBCode,
                            OfficialDBPay,OfficialCXPay,SubsidyZX1Pay,SubsidyZX2Pay,YYZFPay)
                     values(@ybcardnum,@ybnum,@ybareacode,@YBAreaName,@FPFlag,@YBAttrib,@FPNum,@FPName,@age,@sex,@Transaction_No,
                            @Serial_No,@DWBM,@DWMC,@Arranger,@Section_Name,@SicksortCode,@Selfpay,@Hookpay,@Tcpay,@TcSelfpay,
                            @Basepay,@Outpay,@Preqpay,@Dbzf,@ActualSelfpay,@SubsidyPay,@OfficialPay,@Ryzt,@Tsggzfbf,@Initinstitution,
                            @FeebalanceType,@CardLeftMoney,@CardMoney,@XJMoney,@YBMoney,@FPMoney,@yberror,@opername,@currentdate,@mznum,
                            1,@tgbz,@txbz,@cyyy,@tcqcode,@jylsnum,@jyyznum,@jsid,@fhbcfwmoney,@tcpercent,@dbpercent,@ylzgrypay,
                            @qybcyljjpay,@otherbzjjpay,@mzyljzpay,@mzyljjpay,@tczybzpay,@dbzybzpay,@ydflag,@ywzqnum,@delywzqnum,@yllbcode,
                            @OfficialDBPay,@OfficialCXPay,@SubsidyZX1Pay,@SubsidyZX2Pay,@yyzfpay)

    delete _yhyb_transsheet where userid=@userid
  end
end
GO
