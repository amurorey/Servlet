


CREATE VIEW MZALLYPVIEW 
AS
select c05 as goodsno,rtrim(a07) as goodsname,a12 as unit,c17*a13 as ypcount,c13_1 as price1,c16_1 as price2,
  00000000000 as _ypcount,c03 as procdate,c09 as yfcode,1 as flag,c18 as ypmoney1,c18_1 as ypmoney2
  from outstock,goods (nolock)
  where c05=a01
union all
select yfstart.goodsno,rtrim(a07),a12,ypcount,ypprice1,ypprice2,0,operdate,yfcode,2,ypmoney1,ypmoney2
  from yfstart,goods (nolock)
  where yfstart.goodsno=a01
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,fpdate,yfcode,3,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount
  from mzcfypk (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,fpdate,yfcode,4,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount
  from mzcfypkhis (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,jzdate,yfcode,5,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount
  from zycfypk (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,jzdate,yfcode,6,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount
  from zycfypkhis (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unit,ypcount,price1,price2,0,procdate,yfcode,7,
  price1*ypcount,price2*ypcount
  from yfstorechange (nolock)
union all
select goodsno,rtrim(a07),a12,0,newprice2,newprice1,0,procdate,yfcode,8,money2,money1
  from mzchangeprice,goods (nolock)
  where goodsno=a01


GO
