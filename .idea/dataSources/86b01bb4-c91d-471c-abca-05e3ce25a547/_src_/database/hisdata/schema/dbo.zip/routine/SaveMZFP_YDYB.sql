CREATE   PROCEDURE [dbo].[SaveMZFP_YDYB]
(@yldyname char(20),@ywzqid char(40),@jsid char(40),@ybmzandzynum char(40),@userid numeric,
 @fpnum int,@fpname char(20),@ybnum char(20),@jfcardid char(10)=null,
 @ybcardnum char(20),@ybareacode char(10),@ybareaname char(20),@rylbname char(20),@ybattrib char(20),@sex char(4),
 @personno char(20),@unitcode char(20),@unitname char(40),@fpdate datetime,@fpopercode char(10),@fpoper char(10),
 @fpmoney numeric(12,2),@oldfpnumval int=null,@leftzhmoney numeric(12,2),@yberror numeric(12,2)=null,
 @akc264 numeric(12,2),@akc260 numeric(12,2),@akc255 numeric(12,2),@akc261 numeric(12,2),@akc290 numeric(12,2),
 @akc090 numeric(12,2),@akc272 numeric(12,2),@akc801 numeric(12,2),@ckc120 numeric(12,2),@ckc121 numeric(12,2),
 @ckc155 numeric(12,2),@ckc156 numeric(12,2),@ckc161 numeric(12,2),@ckc162 numeric(12,2),@ckc170 numeric(12,2),
 @akc802 numeric(12,2),@akc803 numeric(12,2),@akc804 numeric(12,2),@ckc103 numeric(12,2),@akc805 numeric(12,2),
 @akc806 numeric(12,2),@akc808 numeric(12,2),@printstr char(256),
 @retval char(1024) output,@mznum int=null,@patientid nvarchar(10)=null,
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  declare @ret int
  declare @ybzf numeric(12,2)
  select @ybzf=@akc264-@akc261  --医保总费用-现金支付=医保支付总额

  execute @ret=SaveMZFP @fpnum=@fpnum,
                        @userid=@userid,
                        @fpname=@fpname,
                        @fpmoney=@fpmoney,
                        @opername=@fpoper,
                        @retval=@retval output,
                        @currentdate=@fpdate,
                        @oldfpnum=@oldfpnumval,
                        @ybflag=1,
                        @ybnum=@ybnum,
                        @jfcardid=@jfcardid,
                        @roundflag=null,
                        @ybareacode=@ybareacode,
                        @ybareaname=@ybareaname,
                        @zfmoney1=@ybzf,
                        @zfmoney2=@akc261,
                        @roundmoney=null,
                        @mznum=@mznum,
                        @yldyname=@yldyname,
                        @fpnum_tmp=null,
                        @yberror=@yberror,
                        @patientid=@patientID,
                        @InvoiceNum=@InvoiceNum,
                        @InvoiceOperID=@InvoiceOperID,
                        @sex=@sex
                        

/*  exec @ret=SaveMZFP @fpnum,@userid,@fpname,@fpmoney,@fpoper,@retval output,@fpdate,
       @oldfpnumval,1,@ybnum,@jfcardid,null,@ybareacode,@ybareaname,@ybzf,@akc261,
       null,@mznum,@yldyname,null,@yberror,@patientid*/
  if @ret <> 0 
    return @ret

  insert ydyb_invoicebase(FPNum,PatientState,YWZQID,JSID,YBMZAndZYNum,FPName,YBNum,YBCardNum,
                          YBAreaCode,YBAreaName,RYLBName,YBAttrib,Sex,PersonNo,
                          UnitCode,UnitName,MZNum,FPDate,FPOperCode,FPOperName,LeftZHMoney,FPMoney,
                          AKC264,AKC260,AKC255,AKC261,AKC290,AKC090,AKC272,AKC801,CKC120,
                          CKC121,CKC155,CKC156,CKC161,CKC162,CKC170,AKC802,AKC803,AKC804,
                          CKC103,AKC805,AKC806,AKC808,PRINTSTR)
    values(@FPNum,1,@ywzqid,@JSID,@ybmzandzynum,@FPName,@YBNum,@YBCardNum,
           @YBAreaCode,@YBAreaName,@RYLBName,@YBAttrib,@Sex,@PersonNo,
           @UnitCode,@UnitName,@FPNum,@FPDate,@fpopercode,@FPOper,@LeftZHMoney,@FPMoney,
           @AKC264,@AKC260,@AKC255,@AKC261,@AKC290,@AKC090,@AKC272,@AKC801,@CKC120,
           @CKC121,@CKC155,@CKC156,@CKC161,@CKC162,@CKC170,@AKC802,@AKC803,@AKC804,
           @CKC103,@AKC805,@AKC806,@AKC808,@PRINTSTR)

  return 0
end
GO
