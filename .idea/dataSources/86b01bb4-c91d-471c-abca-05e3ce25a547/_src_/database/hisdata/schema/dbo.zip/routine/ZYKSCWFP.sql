/*科室床位分配*/
/*@flag=1  为已入院的病人分配床位 病区日报中增加一个入院病人*/
/*@flag=2  为提出转科申请的病人分配床位 病区日报中转入、转出个增加一个人*/
/*@flag=3  为已做出院申请的病人重新分配床位（即取消出院申请）*/
/*@flag=4  病人从科室出到出院处在日报中增加一出院人数*/
/*@flag=5  取消病人入室操作，在日报中减少一个入院人数，删除首页记录，并重置mbase*/
/*@swflag 死亡标志，只有在@flag=4时有用，0默认未死  1死亡*/

/*@blflag   该参数只在@flag=1是会传入*/
/*@blflag=null  书写病历并参与日报统计（默认）*/
/*@blflag=1     不书写病历且不参与日报统计*/
CREATE                      procedure [dbo].[ZYKSCWFP]
(@zynum int,@kscode char(4),@ksname char(20),@cwname char(20),@opercode char(10),@opername char(10),@flag int,@swflag int=0,@yscode char(4)=null,@hscode char(4)=null,
 @rkdate datetime=null,@ckdate datetime=null,@blflag int=null,@zkdate datetime=null)
as
begin
  declare @t_zyyzid int  /*定义一个临时变量存放ZYYZID*/

  declare @currentdate datetime
  select @currentdate=getdate()

--  declare @Currentdate_ymd datetime
--  select @currentdate_ymd=convert(datetime,convert(char(10),@currentdate,101))  /*仅保留年、月、日*/


  declare @t_YSName char(20)
  declare @t_HSName Char(20)
  select @t_YSName=name from yscode (nolock) where code=@yscode
  select @t_HSName=name from yscode (nolock) where code=@hscode
  declare @t_cw char(20)  --床位临时变量

  declare @t_blflag int  --临时变量

  if @flag=1 
  begin
    if exists(select currentzynum from kscwset where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum is not null)  
      return 101  /*当前床位已被分配*/

    if exists(select currentzynum from kscwset where currentzynum=@zynum)
      return 102  /*该病人已被分配床位*/

    if exists(select m01 from mbase (nolock) where m01=@zynum and m51 is not null)
      return 102  /*该病人已入室*/

--    if exists(select fp0 from ba_fpage where fp0=rtrim(convert(char(20),@zynum)) and fp24 is not null)  
--      return 102  /*该病人已被分配床位*/
    
    if not exists(select m01 from mbase where m01=@zynum)  
      return 103  /*该病人已被取消入院*/

    if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null)
      return 104  /*该病人已出院（财务）*/

    if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
      return 105  /*该病人已取消入院*/

    /*-------------写入日志，0：表示入科----------------------*/
    insert zybrkslog(zynum,kscode,ksname,cwname,logdate,opername,flag)
      values(@zynum,@kscode,@ksname,@cwname,@rkdate,@opername,0)
    /*-------------------------------------------------------*/

    update kscwset
      set currentzynum=@zynum,hscode=@hscode,hsname=@t_hsname,
          yscode=@yscode,ysname=@t_ysname
      where kscode=@kscode and ltrim(rtrim(cwname))=@cwname

    execute GetUniqueNo 16,@NewUniqueNo=@t_zyyzid output

    update mbase
      set m18=@cwname,m38=@t_zyyzid,m51=@rkdate,m52=@opername,m63=@cwname,m35=@t_ysname,m64=@blflag
      where m01=@zynum

/*    update mbase
      set m35=@t_ysname
      from mbase
      where m01=@zynum*/

    update zycfypk
      set zgysname=@t_ysname
      where zynum=@zynum and (zgysname is null or rtrim(zgysname)='')

    update zycheck
      set zgysname=@t_ysname
      where zynum=@zynum and (zgysname is null or rtrim(zgysname)='')

--    declare @t_m11 datetime  --入院日期
--    declare @t_m35 char(20)  --主管医师
--    select /*@t_m11=m11,*/@t_m35=m35 from mbase (nolock) where m01=@zynum

    if @blflag is null
    begin
      insert ba_fpage(fp0,fp2,fp3,fp4,fp5,fp6,fp7,fp14,
                      fp22,fp23,fp23_name,fp24,fp25,fp40,
                      fp81,fp118,fp149,fp_patientid,
                      PersonNo,FP137_YS,FP17_YS)
          select rtrim(convert(char(20),m01)) as m01,m04,case when m05='男' then '1' else '2' end,m06,m07,M02,m03,m10,
                 m09,m16,m17,@cwname,@rkdate,@rkdate,
                 1,@t_ysname,@t_hsname,patientid,
                 M08,M10,M10
          from mbase where m01=@zynum and m16=@kscode

    /*初始化病案首页库中的字段*/
      update ba_fpage
        set fp80='1',fp122='1',fp82='1',fp83='0',fp84='0',fp85='0',fp90='1'
            /*fp98='2'*,fp86='2',fp96='2',fp114='2',fp87='1',fp77='1'*/
        where fp0=rtrim(convert(char(20),@zynum))

      declare @t_rkdate datetime
      select @t_rkdate=convert(datetime,convert(char(10),@rkdate,101)) /*仅保留年、月、日*/
      execute ba_processbqgzrb @KSCode,@KSName,@t_rkdate,1,1  /*在日报中增加一个入院病人*/
    end
  end else if @flag=2
  begin
    if exists(select currentzynum from kscwset (nolock) where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum is not null)  /*当前床位已被分配*/
      return 201

    if not exists(select zynum from preturnmess (nolock) where @zynum=@zynum and receivedate is null and turncode=@kscode)  /*转科申请已被执行或取消*/
      return 202

    if exists(select m01 from mbase (nolock) where m01=@zynum and m64=1)
      return 204  --不书写病历的患者不允许转科

    declare @t_LastZKDate datetime
    select @t_LastZKDate=max(turndate) from turnmess (nolock) where zynum=@zynum
    if @ZKDate<=@t_LastZKDate
      return 205  --实际转科时间小于上次转科时间

--    if exists(select zynum from turnmess (nolock) where zynum=@zynum and turndate=@currentdate)  --每天只能进行一次转科
--      return 203

    declare @t_sourcekscode char(4) declare @t_sourceksname char(20)  /*原科室代码、名称*/
    select @t_sourcekscode=fromcode,@t_sourceksname=fromname from preturnmess where zynum=@zynum and receivedate is null

    /*-------------写入日志，0：表示入科  1:出科---------------*/
    insert zybrkslog(zynum,kscode,ksname,cwname,logdate,opername,flag)
      select @zynum,@t_sourcekscode,@t_sourceksname,cwname,@currentdate,@opername,1
        from kscwset where kscode=@t_sourcekscode and currentzynum=@zynum

    insert zybrkslog(zynum,kscode,ksname,cwname,logdate,opername,flag)
      values(@zynum,@kscode,@ksname,@cwname,@currentdate,@opername,0) 
    /*-------------------------------------------------------*/


    insert kscwmess(ZYNum,CWName,KSCode,KSName,OperDate,OperCode,OperName,ZYYZID_CW)
      values(@zynum,@cwname,@kscode,@ksname,@zkdate,@opercode,@opername,@t_ZYYZID)

    /*将原科室的床位值为NULL*/
    update kscwset
      set currentzynum=null
      where kscode=@t_sourcekscode and currentzynum=@zynum

    /*将转入科室的的床位值为当前住院号*/
    update kscwset
      set currentzynum=@zynum,hscode=@hscode,hsname=@t_hsname,
          yscode=@yscode,ysname=@t_ysname
      where kscode=@kscode and ltrim(rtrim(cwname))=@cwname

    declare @t_oldyzid int
    select @t_oldyzid=m38 from mbase (nolock) where m01=@zynum

    execute GetUniqueNo 16,@NewUniqueNo=@t_zyyzid output  /*重新生成新的zyyzid*/
    update mbase
      set m16=@kscode,m17=@ksname,m18=@cwname,m35=@t_ysname,m38=@t_zyyzid
      where m01=@zynum

    update ba_fpage
      set fp28=@kscode,fp118=@t_ysname
      where fp0=rtrim(convert(char(20),@zynum))

    insert turnmess(zynum,fromcode,fromname,turncode,turnname,turndate,oldyzid)
      select zynum,fromcode,fromname,turncode,turnname,@zkdate,@t_oldyzid 
      from preturnmess where zynum=@zynum and receivedate is null

    update preturnmess
      set receiveoper=@opername,receivedate=@currentdate
      where zynum=@zynum and receivedate is null


    /*更新病区工作日报*/
    /*1、在原科室中增加转出数*/
    /*2、在现科室中增加转入数*/
    select @zkdate=convert(datetime,convert(char(10),@zkdate,101))  /*仅保留年、月、日*/
    execute ba_processbqgzrb @t_sourcekscode,@t_sourceksname,@zkdate,3,1  /*在原科室日报中增加一个转出数*/
    execute ba_processbqgzrb @kscode,@ksname,@zkdate,4,1  /*在当前科室日报中增加一个转入数*/
  end else if @flag=3  /*取消出院申请并重新分配床位*/
  begin
    if exists(select currentzynum from kscwset where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum is not null)  /*当前床位已被分配*/
      return 301

    if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null)
      return 302  /*该病人已被出院院处确认出院*/

    if exists(select currentzynum from kscwset where kscode=@kscode and currentzynum=@zynum)
      return 303  /*该病人已被分配床位*/

    if exists(select fp0 from ba_fpage where fp0=rtrim(convert(char(20),@zynum)) and fp121 is not null)
      return 304  /*病历已被病案室审核*/

    if exists(select fp0 from ba_fpage where fp0=rtrim(convert(char(20),@zynum)) and fp121 is not null)
      return 305  /*首页已被医师审核*/

   
    /*-------------写入日志，0：表示入科----------------------*/
    insert zybrkslog(zynum,kscode,ksname,cwname,logdate,opername,flag)
      values(@zynum,@kscode,@ksname,@cwname,@currentdate,@opername,0)
    /*-------------------------------------------------------*/

    update kscwset
      set currentzynum=@zynum,hscode=@hscode,hsname=@t_hsname,
          yscode=@yscode,ysname=@t_ysname
      where kscode=@kscode and ltrim(rtrim(cwname))=@cwname

--    execute GetUniqueNo 16,@NewUniqueNo=@t_zyyzid output

    update mbase
      set m18=@cwname,m53=null,m54=null,m35=@t_ysname
      where m01=@zynum

    select @t_cw=m18 from mbase (nolock) where m01=@zynum
    if @t_cw<>@cwname
      insert kscwmess(ZYNum,CWName,KSCode,KSName,OperDate,OperCode,OperName)
        values(@zynum,@cwname,@kscode,@ksname,getdate(),@opercode,@opername)

    
    select @t_blflag=m64 from mbase (nolock) where m01=@zynum

    if @t_blflag is null
    begin    
      declare @t_swflag int
      select @t_swflag=0
      declare @t_fp42 char(10)
      select @t_fp42=fp42 from ba_fpage where fp0=rtrim(convert(char(20),@zynum))
      if rtrim(@t_fp42)='4'
        select @t_swflag=1

      declare @t_fp31 datetime
      select @t_fp31=convert(datetime,convert(char(10),fp31,101))from ba_fpage where fp0=rtrim(convert(char(20),@zynum)) /*仅保留年、月、日*/


      exec ba_processbqgzrb @kscode,@ksname,@t_fp31,2,-1,@t_swflag  /*更新病区工作日报数据*/

      update ba_fpage 
        set fp29=null,fp29_name=null,fp31=null,fp33=null,fp42=null
        where fp0=rtrim(convert(char(20),@zynum))
    end
  end else if @flag=4
  begin
--    if exists(select fp0 from ba_fpage (nolock) where fp0=rtrim(convert(char(20),@zynum)) and fp31 is not null)
--      return 401  /*该病人已做出院申请*/
    if exists(select m01 from mbase (nolock) where m01=@zynum and m53 is not null)
      return 401  /*该病人已做出室处理*/

    if exists(select zynum from preturnmess where zynum=@zynum and receivedate is null)
      return 402  /*该病人有转科申请*/

    if not exists(select m01 from mbase (nolock) where m01=@zynum)
      return 403  /*无该病人信息或已被取消入院登记*/

    if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
      return 403  /*无该病人信息或已被取消入院登记*/


--    if not exists(select fp0 from ba_fpage (nolock) where fp0=rtrim(convert(char(20),@zynum)))
--      return 403  /*无该病人信息*/

    if not exists(select currentzynum from kscwset (nolock) where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum=@zynum)
      return 404  /*当前床位的病人不是@zynum的病人*/

    --保山市医院特例
    declare @t_unitno varchar(20)
    select @t_unitno=rtrim(unitno) from unitset
    if (@t_unitno='432695504') and (not exists(select yzid from yzsheet (nolock),mbase (nolock) where zynum=m01 and zyyzid=m38 and zynum=@zynum and (notjzyzflag=3 or notjzyzflag=5) and yzlastrundate is not null))
      return 405  /*必须有“今日出院”或“死亡”医嘱方能出室*/
    if (@t_unitno='432695504') and (exists(select yzid from yzsheet (nolock),mbase (nolock) where zynum=m01 and zyyzid=m38 and zynum=@zynum and notjzyzflag=5 and yzlastrundate is not null)) and @swflag=0
      return 406  /*死亡”医嘱对应的出院方式必须选择死亡*/

    if @ckdate is null
      select @ckdate=@currentdate

    update mbase
      set m53=@ckdate,m54=@opername
      where m01=@zynum

    /*-------------写入日志，1:出科---------------*/
    insert zybrkslog(zynum,kscode,ksname,cwname,logdate,opername,flag)
      values(@zynum,@kscode,@ksname,@cwname,@ckdate,@opername,1)
    /*-------------------------------------------*/

    select @t_cw=cwname from kscwset (nolock) where currentzynum=@zynum and kscode=@kscode

    update kscwset
      set currentzynum=null
      where currentzynum=@zynum and kscode=@kscode

    select @t_blflag=m64 from mbase (nolock) where m01=@zynum

    if @t_blflag is null
    begin
      update ba_fpage
        set fp42=case when @swflag=0 then '1' else '4' end
        where fp0=rtrim(convert(char(20),@zynum))

      /*更新首页库中的出院科室代码、科室名称、出院日期、住院天数字段*/
      /* declare @swflag int
      select @swflag=0*/
      declare @fp42 char(10)
      select @fp42=fp42 from ba_fpage where fp0=rtrim(convert(char(20),@zynum))
      /*  if rtrim(@fp42)='4'
        select @swflag=1*/
  
      update ba_fpage 
        set fp29=@kscode,fp29_name=@ksname,fp31=@ckdate,fp33=case when datediff(day,fp25,@ckdate)>1 then datediff(day,fp25,@ckdate) else 1 end,
            fp30=@t_cw
        where fp0=rtrim(convert(char(20),@zynum))

       exec SaveZYInvoiceToBAFpage @zynum  --将费用添加到首页中


      select @ckdate=convert(datetime,convert(char(10),@ckdate,101))  /*仅保留年、月、日*/
      exec ba_processbqgzrb @kscode,@ksname,@ckdate,2,1,@swflag  /*更新病区工作日报数据*/
    end
  end else if @flag=5
  begin
    if exists(select currentzynum from kscwset (nolock) where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum is null)
      return 501  /*当前床位未被分配*/

--    if not exists(select fp0 from ba_fpage (nolock) where fp0=rtrim(convert(char(20),@zynum)))  
--      return 501  /*该病人未分配床位*/
    if exists(select m01 from mbase (nolock) where m01=@zynum and m51 is null)
       return 501  /*该病人未进行入室操作*/

    if not exists(select currentzynum from kscwset (nolock) where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum=@zynum)
      return 502  /*当前床位的病人不是@zynum的病人*/

    if exists(select m25 from mbase (nolock) where m01=@zynum and m25>0 and m25 is not null)
      return 503  /*该病人在当前科室已发生费用*/


    if exists(select zynum from turnmess (nolock) where zynum=@zynum)
      return 504  /*该病人已发生转科*/

    if exists(select zynum from PRETURNMESS (nolock) where zynum=@zynum)
      return 505  /*该病人已申请转科*/

    if exists(select zynum from yzsheet (nolock) where zynum=@zynum and deldate is null and yzstopdate is null and xmflag<>10)
      return 506  /*该病人已发生医嘱*/

    /*-------------写入日志，0：表示入科----------------------*/
    delete zybrkslog where zynum=@zynum
    /*-------------------------------------------------------*/

    update kscwset
      set currentzynum=null
      where kscode=@kscode and ltrim(rtrim(cwname))=@cwname and currentzynum=@zynum

    delete kscwmess where zynum=@zynum

    update mbase
      set m18=null,m38=null,m51=null,m52=null,m63=null,m35=null,m64=null
      where m01=@zynum


    select @t_blflag=m64 from mbase (nolock) where m01=@zynum

    if @t_blflag is null
    begin
      declare @t_fp25 datetime
      select @t_fp25=convert(datetime,convert(char(10),fp25,101)) from ba_fpage where fp0=rtrim(convert(char(20),@zynum))  /*仅保留年、月、日*/
      execute ba_processbqgzrb @KSCode,@KSName,@t_fp25,1,-1  /*在日报中减少一个入院病人*/

      delete ba_fpage where fp0=rtrim(convert(char(20),@zynum))
      delete ba_invoice where zynum=rtrim(convert(char(20),@zynum))
    end
  end
end
GO
