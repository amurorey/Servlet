


CREATE VIEW AllPrepayView AS
select * from prepay (nolock)
union all
select * from prepayhis (nolock)


GO
