/*@flag=1  入院      */
/*@flag=2  出院      */
/*@flag=3  转出      */
/*@flag=4  转入      */
/*@rs=1正常操作  @rs=-1冲正常操作*/
/*@swflag死亡标志  @swflag=0未死  1死亡*/  
CREATE   procedure [dbo].[BA_ProcessBQGZRB]
(@ksdm char(4),@ksname char(20),@pcdate datetime,@flag int,@rs int,@swflag int=0)
as
begin
  select @pcdate=convert(datetime,convert(char(10),@pcdate,101))  /*仅保留年、月、日*/
 
  declare @firstpcdate datetime  /*首次日报填报日期*/
  select @firstpcdate=min(pcdate) from ba_bqgzrb where ksdm=@ksdm

  declare @lastpcdate datetime  /*最末日报填报日期*/
  select @lastpcdate=max(pcdate) from ba_bqgzrb where ksdm=@ksdm
  
  /*如果lastpcdate=null 则表示病区工作日报首次录入*/
  declare @bzbcs int
  select @BZBCS=bcs from kscode where bcs is not null and bcs<>0 and code=@ksdm
  if @BZBCS is null or @BZBCS=0
    return -1  --该科室无编制病床
  if @lastpcdate is null 
  begin

    insert ba_bqgzrb(PCDATE,KSDM,KSNAME,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13)
      values(@pcdate,@ksdm,@ksname,@bzbcs,0,0,0,0,0,0,0,0,0,0,0,0)

    select @lastpcdate=@pcdate,@firstpcdate=@pcdate
  end

  declare @yyrs int  /*定义原有人数*/

  /*如果入院日期小于日报首次填报日期则增加原有数后返回*/
  if @pcdate<@firstpcdate
  begin
    update ba_bqgzrb set a3=a3+@rs where ksdm=@ksdm and pcdate=@firstpcdate
    
    update ba_bqgzrb
      set a9=a3+case when a4 is null then 0 else a4 end+case when a5 is null then 0 else a5 end-case when a6 is null then 0 else a6 end-case when a8 is null then 0 else a8 end
      where pcdate=@firstpcdate and ksdm=@ksdm    

    select @yyrs=a9 from ba_bqgzrb where pcdate=@firstpcdate and ksdm=@ksdm

    select @firstpcdate=DATEADD(day,1,@firstpcdate)
    /*自动更新从开始日报起至最末日报的各个数据项*/
    while @firstpcdate<=@lastpcdate
    begin
      update ba_bqgzrb
        set a3=@yyrs,a9=@yyrs+case when a4 is null then 0 else a4 end+case when a5 is null then 0 else a5 end-case when a6 is null then 0 else a6 end-case when a8 is null then 0 else a8 end
        where pcdate=@firstpcdate and ksdm=@ksdm    

      /*自动生成加床*/
      update ba_bqgzrb
        set a2=case when a9>a1 then a9-a1 else 0 end
        where pcdate=@firstpcdate and ksdm=@ksdm

      select @yyrs=a9 from ba_bqgzrb where pcdate=@firstpcdate and ksdm=@ksdm
      select @firstpcdate=DATEADD(day,1,@firstpcdate)
    end
    return 0
  end

  /*如果入院日期大于或等于日报首次填报日期则程序运行以下语句*/
  /*得到本日期前最末一次本科室的日报日期*/

  /*得到最末一次本科室的编制病床数、留院人数*/
  select @bzbcs=a1,@yyrs=a9 from ba_bqgzrb where ksdm=@ksdm and pcdate=@lastpcdate

  /*自动填写最末一次日报至本日区间内的空日报*/
  select @lastpcdate=DATEADD(day,1,@lastpcdate)
  WHILE @lastpcdate<=@pcdate
  BEGIN
    insert ba_bqgzrb(PCDATE,KSDM,KSNAME,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13) 
      values(@lastpcdate,@ksdm,@ksname,@bzbcs,0,@yyrs,0,0,0,0,0,@yyrs,0,0,0,0)

    /*自动生成加床*/
    update ba_bqgzrb
     set a2=case when a9>a1 then a9-a1 else 0 end
      where pcdate=@lastpcdate and ksdm=@ksdm

    /*日期加一天*/
    select @lastpcdate=DATEADD(day,1,@lastpcdate)
  END

  if @flag=1 
    update ba_bqgzrb set a4=case when a4 is null then 0 else a4 end + @rs where ksdm=@ksdm and pcdate=@pcdate
  else if @flag=2
    update ba_bqgzrb 
      set a6=case when a6 is null then 0 else a6 end + @rs,
          a7=case when @swflag=1 then (case when a7 is null then 0 else a7 end) + @rs else a7 end
      where ksdm=@ksdm and pcdate=@pcdate
  else if @flag=3
    update ba_bqgzrb set a8=case when a8 is null then 0 else a8 end + @rs where ksdm=@ksdm and pcdate=@pcdate
  else if @flag=4
    update ba_bqgzrb set a5=case when a5 is null then 0 else a5 end + @rs where ksdm=@ksdm and pcdate=@pcdate

  update ba_bqgzrb
    set a9=a3+case when a4 is null then 0 else a4 end+case when a5 is null then 0 else a5 end-case when a6 is null then 0 else a6 end-case when a8 is null then 0 else a8 end
    where pcdate=@pcdate and ksdm=@ksdm    

  /*自动生成加床*/
  update ba_bqgzrb
    set a2=case when a9>a1 then a9-a1 else 0 end
    where pcdate=@pcdate and ksdm=@ksdm


  /*更新自日报日期至当前日期的日报留院人数*/
  select @yyrs=a9 from ba_bqgzrb where pcdate=@pcdate and ksdm=@ksdm
  declare @t_date datetime
  select @t_date=DATEADD(day,1,@pcdate)
  while @t_date<=getdate()
  begin
    update ba_bqgzrb
      set a3=@yyrs,a9=@yyrs+case when a4 is null then 0 else a4 end+case when a5 is null then 0 else a5 end-case when a6 is null then 0 else a6 end-case when a8 is null then 0 else a8 end
      where pcdate=@t_date and ksdm=@ksdm    

    /*自动生成加床*/
    update ba_bqgzrb
      set a2=case when a9>a1 then a9-a1 else 0 end
      where pcdate=@t_date and ksdm=@ksdm

    select @yyrs=a9 from ba_bqgzrb where pcdate=@t_date and ksdm=@ksdm
    select @t_date=DATEADD(day,1,@t_date)
  end
  

end
GO
