


CREATE VIEW AllKFYPView AS
/* if flag is 0 means instock; if flag is 1 means outstock; if flag is 2 means kfchangestore */
select 0 as flag,b24 as storecode,b05 as goodsno,b06 as goodsname,b07 as lbcode,b08 as lbname,b02 as sheetno,
       b28 as sheetdate,b10+b26 as note,b13 as price1,b16 as price2,b17 as quanlity,
       b18 as money1,b18_1 as money2,goodsid from start (nolock)
union all
select 0,b24 as storecode,b05 as goodsno,b06 as goodsname,b07 as lbcode,b08 as lbname,b02 as sheetno,
       b28 as sheetdate,b10+b26 as note,b13 as price1,b16 as price2,b17 as quanlity,
       b18 as money1,b18_1 as money2,goodsid from instock (nolock)
union all
select 1,c24 as storecode,c05 as goodsno,c06 as goodsname,c07 as lbcode,c08 as lbname,c02 as sheetno,
       c28 as sheetdate,c10+c26 as note,c13 as price1,c16 as price2,-c17 as quanlity,
       -c18 as money1,-c18_1 as money2,goodsid from outstock (nolock)
union all
select 2,b24 as storecode,b05 as goodsno,b06 as goodsname,b07 as lbcode,b08 as lbname,b02 as sheetno,
       b28 as sheetdate,b10+b26 as note,b13 as price1,b16 as price2,b17 as quanlity,
       b18 as money1,b18_1 as money2,goodsid from kfchangestore (nolock)
union all
select 3,storecode,goodsno,goodsname,a02 as lbcode,a03 as lbname,sheetno,
       operdate,note,0 as price1,0 as price2,0 as quanlity,
       yypjmoney as money1,yyljmoney as money2,goodsid from kfchangeprice,goods (nolock)
       where goodsno=a01


GO
