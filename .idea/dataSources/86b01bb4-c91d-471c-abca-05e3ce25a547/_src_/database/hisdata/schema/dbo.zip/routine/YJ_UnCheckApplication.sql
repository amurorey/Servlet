CREATE      PROCEDURE [dbo].[YJ_UnCheckApplication]
(@applynum int,@opername char(20))
AS
begin
  declare @t_applynum int
  declare @t_jzflag int
  select @t_applynum=null
  select @t_applynum=applynum,@t_jzflag=jzflag from patient_applicationsheet (nolock) where applynum=@applynum
  if @t_applynum is null
    return -1  --无此申请单号

  select @t_applynum=null
  select @t_applynum=applynum from patient_applicationsheet (nolock) where applynum=@applynum and yjcheckdate is null
  if @t_applynum is not null
    return 1  --此申请单尚未被审核，不能取消审核

  declare @t_zynum int
  select @t_zynum=zynum from patient_applicationsheet (nolock)
    where applynum=@applynum

  declare @t_m19 datetime
  declare @t_m56 datetime
  select @t_m19=null
  select @t_m19=m19,@t_m56=m56 from mbase (nolock) where m01=@t_zynum
  if (@t_m19 is not null) or (@t_m56 is not null)
    return 2  --住院患者已出院，不能取消此申请

  if exists(select zynum from zycheck (nolock) where zynum=@t_zynum and yjapplynum=@applynum and yjfpnum is not null)
    return 3  --当前记录已结算，不能取消申请

  --如住院号不为空则为住院患者，则进行以下操作
  if @t_zynum is not null and @t_jzflag=1  --必须满足由医技科室审核后记账方式才允许取消记账曹祖偶
  begin   
    declare @sumcheckmoney numeric(12,2)
    select @sumcheckmoney=sum(checkmoney) from zycheck (nolock) where zynum=@t_zynum and YJApplyNum=@applynum and deldate is null
    
    select @sumcheckmoney=case when @sumcheckmoney is null then 0 else @sumcheckmoney end

    update zycheck
      set deldate=getdate(),deloper=@opername,yjcheckdate=null,yjcheckoper=null,groupkeyno=-groupkeyno
      where zynum=@t_zynum and yjapplynum=@applynum and deldate is null

    update mbase
      set m25=m25-@sumcheckmoney
      where m01=@t_zynum and @sumcheckmoney is not null

    update patient_applicationsheet
      set jzdate=null,jzoper=null
      where zynum=@t_zynum and applynum=@applynum and jzdate is not null
      
    update yj_applysheet
      set deldate=getdate(),Delopername=@opername
      where applynum=@applynum

    update yj_applysheet
      set deldate=getdate(),Delopername=@opername
      where applynum=@applynum
  end


  --以下对申请单进行取消审核（包括门诊及住院，此步骤不包括退费）
  update patient_applicationsheet
    set yjcheckdate=null,yjcheckoper=null,YJCheckDate2=null,YJCheckOper2=null
    where applynum=@applynum and yjcheckdate is not null

  update patient_applicationcheckcode
    set yjcheckdate=null,yjcheckoper=null
    where applynum=@applynum and yjcheckdate is not null

  update yj_applysheet
    set yjcheckdate=null,yjcheckopername=null
    where applynum=@applynum and yjcheckdate is not null

  update yj_applysheethis
    set yjcheckdate=null,yjcheckopername=null
    where applynum=@applynum and yjcheckdate is not null
  -----------------------------------------------------


  return 0
end
GO
