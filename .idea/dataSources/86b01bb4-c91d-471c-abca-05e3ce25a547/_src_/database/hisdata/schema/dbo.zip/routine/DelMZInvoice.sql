--@YWZQID_YDYB(异地医保当前的业务周期号)
CREATE          PROCEDURE [dbo].[DelMZInvoice]
(@fpnum int, @opername char(10), @note char(30)='',@jfcardid char(10)=null,@YWZQID_YDYB char(40)=null)
AS
begin
  declare @t_fpnum int

  select @t_fpnum=null
  select @t_fpnum=fpnum from mzinvoice where fpnum=@fpnum and deldate is not null
  if @t_fpnum is not null
    return 1

  select @t_fpnum=null
  select @t_fpnum=fpnum from mzinvoice (nolock) where fpnum=@fpnum and jsdate is not null
  if @t_fpnum is not null
    return 2

  select @t_fpnum=null
  select @t_fpnum=fpnum from mzcfinf (nolock) where fpnum=@fpnum and fydate is not null
  if @t_fpnum is not null
    return 3

  select @t_fpnum=null
  select @t_fpnum=fpnum from mzinvoice (nolock) where fpnum=@fpnum and cdnum is not null and ybnum is not null
  if @t_fpnum is not null
    return 4

  select @t_fpnum=null
  select @t_fpnum=mzinvoice.fpnum from mzinvoice (nolock) 
    join yj_applysheet on mzinvoice.fpnum=yj_applysheet.fpnum and mzinvoice.fpnum=@fpnum
      and yjcheckdate is not null
  if @t_fpnum is not null
    return 5  --医技科室已审核

  declare @t_mznum int
  select @t_mznum=mznum from mzinvoice (nolock) where fpnum=@fpnum and mzregisterflag=1 and jsdate is null
  if @t_mznum is not null
  begin
    declare @t_mzcount int
    select @t_mzcount=count(*) from mzinvoice (nolock) where mznum=@t_mznum and mzregisterflag is null and deldate is null
    if @t_mzcount is not null and @t_mzcount>0
      return 6  --挂号的患者已有缴费记录不能删除

    select @t_mzcount=null
    select @t_mzcount=mznum from mzregistersheet (nolock) where mznum=@t_mznum and processdate is not null
    if @t_mzcount is not null 
      return 7  --挂号患者已被医师处理
  end

  declare @currentdate datetime
  select @currentdate=getdate()
  /***Compute the count of this invoice***/
  select yfcode,fpnum,goodsno,sum(ypcount*cfcount) as sumypcount 
    into #fpypcount
    from mzcfypk
    where fpnum=@fpnum
    group by yfcode,fpnum,goodsno
  update yfstore
    set a09=a09+sumypcount,a15=a15-sumypcount,a16=a16-sumypcount
    from yfstore,#fpypcount
    where yfstore.a10=#fpypcount.yfcode and
       yfstore.a01=#fpypcount.goodsno
  update mzinvoice
    set deldate=@currentdate
  where fpnum=@fpnum
  update mzcfinf
    set deldate=@currentdate  where fpnum=@fpnum
  update mzcfypk
    set deldate=@currentdate
  where fpnum=@fpnum
  update mzcheck
    set deldate=@currentdate
  where fpnum=@fpnum
  update yhyb_invoicebase
    set deldate=@currentdate,deloper=@opername
    where fpnum=@fpnum
  update yhyb_transsheet
    set deldate=@currentdate
    where fpnum=@fpnum
  update yj_applysheet
    set deldate=@currentdate,
        delopername=@opername
    where fpnum=@fpnum
  update mzregistersheet
    set deldate=@currentdate
    where fpnum=@fpnum
  update dryb_invoicebase
    set deldate=@Currentdate,deloper=@opername
    where fpnum=@fpnum and PatientState='1'
  update xnh_invoicebase
    set deldate=@currentdate,deloper=@opername
    where fpnum=@fpnum and PatientState='1'
  update ydyb_invoicebase
    set deldate=@currentdate,deloper=@opername,ywzqid_del=@ywzqid_ydyb
    where fpnum=@fpnum and PatientState='1' 

  declare @fpmoney numeric(12,2)
  select @fpmoney=fpmoney from mzinvoice (nolock) where fpnum=@fpnum
  update cardbase
    set totmoney=totmoney-@fpmoney
    where cardid=@jfcardid

  insert mzchangeprice
      select mzcfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,ypcount*cfcount,
            (a08-ypprice)*ypcount*cfcount,(a07-ypprice_1)*ypcount*cfcount,@opername,
            @note,yfcode.yfcode,yfcode.yfname
      from yfstore,mzcfypk,yfcode
      where a01=mzcfypk.goodsno and yfstore.a10=mzcfypk.yfcode and mzcfypk.yfcode=yfcode.yfcode
            and (mzcfypk.ypprice<>a08 or mzcfypk.ypprice_1<>a07) and mzcfypk.fpnum=@fpnum

  update mzcfinf_yz
    set mzoper=null,mzoperdate=null,fpnum=null
    where fpnum=@fpnum

  update patient_applicationsheet
    set jzoper=null,
        jzdate=null,
        fpnum=null,
        CHECKMONEY=case when PriceFlag=1 then 0 else CHECKMONEY end
    where fpnum=@fpnum

  return 0
end
GO
