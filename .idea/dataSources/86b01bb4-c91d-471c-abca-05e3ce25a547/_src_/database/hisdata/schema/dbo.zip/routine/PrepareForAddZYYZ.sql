-- =============================================
-- Author:		Lanyuzhi	
-- Create date: 2015-5-25
-- Description:	用于生成医嘱执行前的各种表的处理
-- =============================================
CREATE PROCEDURE [dbo].[PrepareForAddZYYZ] 
	-- Add the parameters for the stored procedure here
(@zynum int,@zyyzid int,@userid numeric,@opercode char(4),@opername char(10),
 @retval varchar(1024)='' output,@operkscode char(4),@operksname char(20),
 @qfsetflag int,@yzflag int,@xmflag int=null,@subyzid int=0,@nowdate datetime)
AS
BEGIN
  if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
    return 5  --已取消入院


  /*在MBASE中定义当前的护理级别*/
  declare @t_hljbcount int
  declare @t_hljbflag char(10)

  select @t_hljbcount=0
  DECLARE hljb_cursor CURSOR FOR
    select hljbflag from
    (select hljbflag from yzsheet (nolock),checkcode (nolock)
      where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzstopdate is null and yzsheet.deldate is null and yzflag=1
            and hljbflag is not null and hljbflag<>''
     union all--附加计价
     select hljbflag from yzfjcheck (nolock),checkcode (nolock)
      where checkno=code and yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzstopdate is null and yzsheet.deldate is null and yzflag=1)
            and hljbflag is not null and hljbflag<>''
     group by hljbflag) disp
  OPEN hljb_cursor
  FETCH NEXT FROM hljb_cursor into @t_hljbflag
  WHILE @@FETCH_STATUS = 0
  BEGIN
    select @t_hljbcount=@t_hljbcount + 1

    FETCH NEXT FROM hljb_cursor into @t_hljbflag
  END
  CLOSE hljb_cursor
  DEALLOCATE hljb_cursor

         
  if @t_hljbcount>1 and (@yzflag=1 or @yzflag=2)  /*在未停长期医嘱中不能同时有两个以上护理级别*/
    return -1

  update mbase
    set m37=@t_hljbflag
    where m01=@zynum and @t_hljbflag is not null and rtrim(@t_hljbflag)<>''

  --declare @nowdate datetime
  --select @nowdate=getdate()

  update yzsheet
    set yzcountforday=countforday,
        yzcountforweek=countforweek
    from yzsheet,yzusedmethodcode
    where zynum=@zynum and yzusedmethod=methodcode and zyyzid=@zyyzid 
          and (yzcountforweek is null or yzcountforday is null or yzsheet.YZCOUNTFORDAY<>YZUSEDMETHODCODE.COUNTFORDAY or yzsheet.YZCOUNTFORWEEK<>YZUSEDMETHODCODE.COUNTFORWEEK)
          and case when subyzid is null then 0 else subyzid end=@subyzid

  --如果没有输入频次则自动将每天用法设置为1次
  update yzsheet
    set YZCOUNTFORDAY=1,YZCOUNTFORWEEK=1
    where zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and (yzcountforday is null or yzcountforday=0)
       and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新长期医嘱中诊疗项目的单价等项目*/
  /*A.如果价格不允许修改时*/
  update yzsheet
    set xmprice=price,xmmoney=round(price*xmcount,2)
    from yzsheet,checkcode
    where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and yzflag=1
         and yzstopdate is null and yzsheet.deldate is null and xmprice<>price
         and unchangeprice=1 and case when subyzid is null then 0 else subyzid end=@subyzid

  /*B.如果价格允许修改时*/
  update yzsheet
    set xmprice=maxprice,xmmoney=round(maxprice*xmcount,2)
    from yzsheet,checkcode
    where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and yzflag=1
          and yzstopdate is null and yzsheet.deldate is null
          and xmprice>maxprice and standflag=1 and unchangeprice is null
          and case when subyzid is null then 0 else subyzid end=@subyzid

  /*C.更新组单价*/
  update yzsheet
    set checkgroupprice=groupprice
  from yzsheet,
    (select yzid,sum(xmprice*xmcount) as groupprice from yzsheet (nolock) where zynum=@zynum and xmflag=4 and yzflag=1 and zyyzid=@zyyzid and checkgroupcode is not null
        and case when subyzid is null then 0 else subyzid end=@subyzid and DelDate is null and YZSTOPDATE is null
      group by yzid) disp
  where yzsheet.yzid=disp.yzid and zynum=@zynum and zyyzid=@zyyzid and xmflag>=4 and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新长期医嘱中药品的单价等项目*/
  update yzsheet
    set xmprice=a08,xmmoney=round(a08*xmcount,2)
    from yzsheet,yfstore
    where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid and xmflag<4 and yzflag=1
         and yzstopdate is null and yzsheet.deldate is null and xmprice<>a08
         and case when subyzid is null then 0 else subyzid end=@subyzid

  /*修改附加记帐*/
  update yzfjcheck
    set checkprice=price,checkmoney=round(price*checkcount,2)
    from yzfjcheck,checkcode
    where checkno=code and checkprice<>price 
          and standflag=1 and unchangeprice=1
          and yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and yzstopdate is null and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid) 
 

  update yzfjcheck
    set checkprice=price,checkmoney=round(price*checkcount,2)
    from yzfjcheck,checkcode
    where checkno=code and checkprice<>price 
          and ((checkprice>maxprice and standflag=1) or (standflag is null and unchangeprice is not null))
          and yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and yzstopdate is null and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid) 


  update yzfjcheck
    set yscode=yzyscode,
        ysname=yzysname,
        yskscode=yzyskscode,
        checkmoney=round(CHECKPRICE*checkcount,2),--再重新计算一遍单价×数量
        ysksname=yzysksname
    from yzfjcheck,yzsheet 
    where zynum=@zynum and yzfjcheck.yzid=yzsheet.yzid and yzstopdate is null and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新附加记价组单价*/
  update yzfjcheck
    set yzfjcheck.groupprice=disp.groupprice
  from yzfjcheck,
    (select yzid,sum(checkprice*checkcount) as groupprice 
      from yzfjcheck 
      where groupcode is not null
        and yzfjcheck.yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzsheet.deldate is null and yzflag=1 and case when subyzid is null then 0 else subyzid end=@subyzid)
      group by yzid) disp
  where yzfjcheck.yzid=disp.yzid and yzfjcheck.yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzsheet.deldate is null and yzflag=1
       and case when subyzid is null then 0 else subyzid end=@subyzid) 

  update yzsheet
    set totcount=round(xmcount*(case when yzcountforday=0 or yzcountforday is null then 1 else yzcountforday end)+0.49,0)
    from yzsheet
    where zynum=@zynum and zyyzid=@zyyzid
          and xmflag<4 and (totcount is null or totcount=0)
          and case when subyzid is null then 0 else subyzid end=@subyzid


  /*---------静配最终时间判断----------*/
  declare @t_EndTime int  --静配截止时间（小时）
  declare @t_EndTime2 int  --静配截止时间（分钟）
  declare @t_unitno varchar(20)
  select @t_unitno=unitno from unitset (nolock)
  
  if @t_unitno='432105148' --红河州第一人民医院}
  begin
    set @t_EndTime=16
    set @t_EndTime2=30
  end
  else
  begin
    set @t_EndTime=14
    set @t_EndTime2=0
  end
  
  if exists(select zynum from yzsheet,yfstore (nolock)
              where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid
                and yzflag=1 and xmflag<4 and yzbegdate<=@nowdate and @yzflag=1
                and (datediff(dd,yzlastrundate,@nowdate)>=yzcountforweek
                     or yzlastrundate is null)
                and (yzstopdate is null or yzstopdate>@nowdate) and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null
                and drugdispense is not null and rtrim(drugdispense) <> '')
                and convert(int, datename(hour,@nowdate))>=@t_EndTime
                and CONVERT(int, DATENAME(MINUTE,@nowdate))>=@t_EndTime2
    return 6  --静配中心的药品提交时间必须在16点半前
  /*--------------------------------------------------------*/

  /********以下开始生成_ZYCFYPK_YZ临时表*******/
  /***Insert into _ZYCFYPK_YZ table***/
  delete _ZYCFYPK_YZ where userid=@userid

  if (@xmflag is null) or (@xmflag=1)
  begin
    if @yzflag=1  /*长期医嘱时*/
      insert _ZYCFYPK_YZ(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                      goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                      yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                      yzusedmethod,yppath,userid,procdate,yzflag,DrugDispense)
        select null,xmcode,totcount,a08,a07,
               round(a08*totcount,2),1,a02,a05,a06,yfcode,yfname,
               kmcode,kmname,yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,
               ypjl,ypjlunit,yzusedmethod,yppath,@userid,@nowdate,@yzflag,DrugDispense
          from yzsheet (nolock) left join yfstore (nolock) on xmcode=a01 and yfcode=a10
          where zynum=@zynum and zyyzid=@zyyzid
                and yzflag=1 and xmflag<4 and yzbegdate<=@nowdate
                and (datediff(dd,yzlastrundate,@nowdate)>=yzcountforweek
                     or yzlastrundate is null)
                and (yzstopdate is null or yzstopdate>@nowdate) and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null
          order by keyno
    else if @yzflag=2          /*临时医嘱时*/
      insert _ZYCFYPK_YZ(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                      goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                      yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                      yzusedmethod,yppath,userid,procdate,yzflag)
        select null,xmcode,totcount,a08,a07,
               round(a08*totcount,2),1,a02,a05,a06,yfcode,yfname,
               kmcode,kmname,yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,
               ypjl,ypjlunit,yzusedmethod,yppath,@userid,@nowdate,@yzflag
          from yzsheet (nolock) LEFT join yfstore (nolock) on XMCODE=A01 and YFCODE=A10
          where zynum=@zynum and zyyzid=@zyyzid
                and yzflag=2 and xmflag<4
           and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null
          order by keyno
  end


  /***********以下开始生成_ZYCHECK_YZ临时表************/
  delete _ZYCHECK_YZ where userid=@userid
  if (@xmflag is null) or (@xmflag=2)
  begin
    if @yzflag=1    /*长期医嘱时*/
      insert _ZYCHECK_YZ(checkno,checkprice,
                      checkcount,
                      checkmoney,
                      checkname,
                      kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                      fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                      groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,userid)
        select xmcode,xmprice,
               case when checkgroupcode is null then totcount else xmcount*totcount end,
               case when checkgroupcode is null then round(xmprice*totcount,2) else round(xmprice*xmcount*totcount,2) end,
               xmname,
               kmname,kmcode,yzyscode,yzysname,yzyskscode,yzysksname,yblb,yblbname,xmunit,
               fskscode,fsksname,checkgroupcode,checkgroupname,checkgroupprice,totcount,
               checkgroupkeyno,yzid,yzusedmethod,yjapplynum,@nowdate,@userid
          from yzsheet
          where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and (xmflag=4 or xmflag=5 or xmflag=7 or xmflag=8 or xmflag=9 or xmflag=10 or xmflag=11)
             and yzbegdate<=@nowdate
             and (datediff(dd,yzlastrundate,@nowdate)>=yzcountforweek
                  or yzlastrundate is null)
             and (yzstopdate is null or yzstopdate>@nowdate) and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid
            order by keyno
    else if @yzflag=2            /*临时医嘱时*/
      insert _ZYCHECK_YZ(checkno,checkprice,
                      checkcount,
                      checkmoney,
                      checkname,
                      kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                      fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                      groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,userid)
        select xmcode,xmprice,
               case when checkgroupcode is null then totcount else xmcount*totcount end,
               case when checkgroupcode is null then round(xmprice*totcount,2) else round(xmprice*xmcount*totcount,2) end,
               xmname,
               kmname,kmcode,yzyscode,yzysname,yzyskscode,yzysksname,yblb,yblbname,xmunit,
               fskscode,fsksname,checkgroupcode,checkgroupname,checkgroupprice,totcount,
               checkgroupkeyno,yzid,yzusedmethod,yjapplynum,@nowdate,@userid
          from yzsheet
          where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and (xmflag=4 or xmflag=5 or xmflag=7 or xmflag=8 or xmflag=9 or xmflag=10 or xmflag=11 or xmflag=12)
           and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid
          order by keyno
  end


  --将医嘱执行后直接记账的检查申请存入临时表中
  if @yzflag=2
  begin
    insert _ZYCHECK_YZ(checkno,checkprice,checkcount,checkmoney,checkname,
                    kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                    fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                    groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,applicationflag,userid)
      select checkno,checkprice,checkcount,patient_applicationcheckcode.checkmoney,checkname,
             kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
             patient_applicationcheckcode.fskscode,patient_applicationcheckcode.fsksname,groupcode,groupname,groupprice,groupcount,
             newgroupkeyno,yzid,null,patient_applicationsheet.applynum,getdate(),1,@userid
      from patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and patient_applicationcheckcode.zynum=@zynum and
            yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and xmflag=11 and yzbegdate<=@nowdate and yzlastrundate is null) 
            and case when subyzid is null then 0 else subyzid end=@subyzid and
            jzflag is null --医嘱执行后记账
  end

  /***将附加计价中的数据追加至_ZYCHECK_YZ表中***/
  insert _ZYCHECK_YZ(checkno,checkprice,checkcount,checkmoney,checkname,
                  kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,
                  unitname,fskscode,fsksname,groupcode,groupname,groupprice,groupcount,groupkeyno,yzid,userid,procdate)
    select checkno,checkprice,checkcount,checkmoney,checkname,
                  kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,
                  unitname,fskscode,fsksname,groupcode,groupname,groupprice,groupcount,groupkeyno,yzid,@userid,@nowdate
      from yzfjcheck
      where yzid in(select yzid from _ZYCFYPK_YZ where userid=@userid 
                    union all 
                    select yzid from _ZYCHECK_YZ where userid=@userid
                    union all
                    select yzid from yzsheet
                      where zynum=@zynum 
                      and zyyzid=@zyyzid and @yzflag=1 and yzflag=1 and (xmflag=5) and yzbegdate<=@nowdate
                      and yzlastrundate is null
                      and (yzstopdate is null or yzstopdate>@nowdate) and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid
                      and yzflag=@yzflag
                    union all
                    select yzid from yzsheet
                       where zynum=@zynum and zyyzid=@zyyzid and @yzflag=2 and (xmflag=5 or xmflag=6 or xmflag=11 or xmflag=12)
                         and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid
                         and yzflag=@yzflag)
      order by keyno


  /*将附加记价的材料追加至_ZYCFYPK_YZ表中*/
  insert _ZYCFYPK_YZ(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                    goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                    yscode,ysname,yskscode,ysksname,yzid,
                    clflag,userid,procdate,yzflag)
    select null,goodsno,ypcount,a08,a07,ROUND(a08*ypcount,2),1,
           A02,A05,A06,yfcode,yfname,kmcode,kmname,
           yscode,ysname,yskscode,ysksname,yzid,
           1,@userid,getdate(),@yzflag
      from yzfjcl (nolock),yfstore (nolock)
      where goodsno=a01 and YFCODE=a10 and 
            yzid in (select yzid from _ZYCFYPK_YZ where userid=@userid 
                     union all 
                     select yzid from _ZYCHECK_YZ where userid=@userid
                     union all
                     select yzid from yzsheet
                       where zynum=@zynum 
                       and zyyzid=@zyyzid and @yzflag=1 and yzflag=1 and (xmflag=5) and yzbegdate<=@nowdate
                       and yzlastrundate is null
                       and (yzstopdate is null or yzstopdate>@nowdate) and yzsheet.deldate is null and case when subyzid is null then 0 else subyzid end=@subyzid
                     union all
                     select yzid from yzsheet
                        where zynum=@zynum and zyyzid=@zyyzid and @yzflag=2 and yzflag=2 and (xmflag=5 or xmflag=6 or xmflag=11 or xmflag=12)
                          and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid)
    order by keyno
    
  /*执行临时处方时，有两种情况：1.长期  2.临时  特别注意：无论长期或临时仅执行一次*/
  /*在执行长期医嘱时执行临时处方。注意仅第一次执行，不需要对CFNUM重新赋值，所以AddZYYZ存储过程中更新处方号的语句中加入YZFlag<>4条件*/
  insert _ZYCFYPK_YZ(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                  goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                  yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                  yzusedmethod,yppath,userid,procdate,yzflag)
    select cfnum,xmcode,totcount,A08,a07,round(a08*totcount,2),case when cfcount is null then 1 else cfcount end,
           a02,a05,a06,yfcode,yfname,kmcode,kmname,
           yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,ypjl,ypjlunit,
           yzusedmethod,yppath,@userid,@nowdate,4
      from yzsheet,yfstore (nolock)
        where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid
              and yzflag=@yzflag and xmflag=6/*xmflag=6时表示临时处方*/
         and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null and yzstopdate is null and yzsheet.deldate is null
        order by keyno

  return 0
END
GO
