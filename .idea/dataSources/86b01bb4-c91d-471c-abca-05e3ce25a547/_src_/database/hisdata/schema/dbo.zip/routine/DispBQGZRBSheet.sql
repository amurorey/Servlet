/* 
@flag=2 显示入院病人明细
@flag=3 显示出院病人明细
@flag=4 显示转入院病人明细
@flag=5 显示转出院病人明细
@flag=6 显示留院病人明细
*/
CREATE      procedure [dbo].[DispBQGZRBSheet]
(@RBDate datetime,@kscode char(4),@flag int)
as
begin
  if @flag=2 
    select fp0,fp2,fp23,fp25 from ba_fpage (nolock)
      where fp25>=@RBDate and fp25<dateadd(day,1,@RBDate) and fp23=@kscode
      order by fp0
  else if @flag=3 
    select fp0,fp2,fp23,fp25,
      case when fp42='4' then '死亡' else '' end as fp42 from ba_fpage (nolock)
      where fp31>=@RBDate and fp31<dateadd(day,1,@RBDate) and fp29=@kscode
      order by fp0
  else if @flag=4
    select fp0,fp2,fromcode,fromname from turnmess,ba_fpage (nolock)
      where fp0=rtrim(convert(char(20),zynum)) and turndate>=@RBDate and turndate<dateadd(day,1,@RBDate) and turncode=@kscode
  else if @flag=5
    select fp0,fp2,turncode,turnname from turnmess,ba_fpage (nolock)
      where fp0=rtrim(convert(char(20),zynum)) and turndate>=@RBDate and turndate<dateadd(day,1,@RBDate) and fromcode=@kscode
  else if @flag=6
  begin
    declare @bqgzrbbegdate datetime  --病案病区工作日报起始时间
    select @bqgzrbbegdate=min(pcdate) from ba_bqgzrb (nolock)

    ----flag表示该记录是否是有转科
    select fp0,fp2,fp25,fp23,0 as flag,
      case when fp31 is not null then rtrim(convert(char(20),fp31,102))+'出院' end as mess
      from ba_fpage where fp23=@kscode and fp25<dateadd(day,1,@RBDate) and (fp31>=dateadd(day,1,@RBDate) or fp31 is null or fp31='') and (fp28 is null or fp28='')
    union all
    select zynum,fp2,turndate,turncode,1,'' as mess from
      (select rtrim(convert(char(20),turnmess.zynum)) as zynum,turnmess.turndate,turnmess.turncode from turnmess,
        (select turnmess.zynum,max(turnmess.keyno) as keyno from turnmess,preturnmess 
          where turnmess.zynum=preturnmess.zynum and turnmess.turndate<dateadd(day,1,@RBDate) and turnmess.turndate>=@bqgzrbbegdate
          group by turnmess.zynum) tab1
        where turnmess.keyno=tab1.keyno) tab2,
      ba_fpage
      where fp0=zynum and turndate<dateadd(day,1,@RBDate) and fp25<dateadd(day,1,@RBDate) and (fp31>=dateadd(day,1,@RBDate) or fp31 is null) and turncode=@kscode
    union all
    select zynum,fp2,turndate,fromcode,1,'' from
      (select rtrim(convert(char(20),turnmess.zynum)) as zynum,turnmess.turndate,turnmess.fromcode from turnmess,
        (select turnmess.zynum,min(turnmess.keyno) as keyno from turnmess,preturnmess
           where turnmess.zynum=preturnmess.zynum and turnmess.turndate>=@bqgzrbbegdate group by turnmess.zynum) tab1
        where turnmess.keyno=tab1.keyno) tab2,
      ba_fpage
      where fp0=zynum and turndate>=dateadd(day,1,@RBDate) and fp25<dateadd(day,1,@RBDate) and (fp31>=dateadd(day,1,@RBDate) or fp31 is null) and fromcode=@kscode
    order by fp0
  end
end
GO
