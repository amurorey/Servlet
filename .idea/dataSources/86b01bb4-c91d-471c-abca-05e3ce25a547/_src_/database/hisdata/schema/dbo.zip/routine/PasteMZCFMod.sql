CREATE PROCEDURE [dbo].[PasteMZCFMod]
(@modcode int,@CFNUM int,@userid numeric,@yfcode char(10))
AS
begin
  delete _mzcfypk where userid=@userid and cfnum=@cfnum

  declare @cfcount int
  select @cfcount=cfcount from _mzcfinf where userid=@userid and cfnum=@cfnum

  insert _mzcfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,goodsname,
                  procname,unitname,yfcode,yfname,kmcode,kmname,yscode,ysname,
                  yskscode,ysksname,userid,procdate)
    select @cfnum,goodsno,ypcount,a08,a07,round(a08*ypcount,2),@cfcount,goodsname,
           a05,unitname,a10,a11,'','','','',
           '','',@userid,getdate()
    from mzcfmodsheet,yfstore (nolock) where a01=goodsno and a10=@yfcode and modcode=@modcode

  declare @cfprice numeric(12,2)
  declare @cfmoney numeric(12,2)

  select @cfprice=sum(round(ypprice*ypcount,2)),@cfmoney=sum(round(ypprice*ypcount,2)*cfcount)
    from _mzcfypk where userid=@userid and cfnum=@cfnum

  update _mzcfinf
    set cfprice=case when @cfprice is null then 0 else @cfprice end,
        cfmoney=case when @cfmoney is null then 0 else @cfmoney end
  where cfnum=@cfnum and userid=@userid

  update _mzcfypk
    set kmcode=a22,kmname=a23,yblb=a24,yblbname=a25
    from _mzcfypk,goods
    where goodsno=a01 and cfnum=@cfnum and userid=@userid

  update _mzcfypk
    set yscode=_mzcfinf.yscode,ysname=_mzcfinf.ysname,
        yskscode=_mzcfinf.yskscode,ysksname=_mzcfinf.ysksname
    from _mzcfypk,_mzcfinf
    where _mzcfypk.cfnum=_mzcfinf.cfnum and _mzcfypk.userid=@userid and _mzcfypk.cfnum=@cfnum

end
GO
