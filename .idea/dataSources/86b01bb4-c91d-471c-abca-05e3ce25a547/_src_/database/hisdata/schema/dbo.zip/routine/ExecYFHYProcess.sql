/*药房换药处理：其执行步骤为：*/
/*      1、执行调药：将当前处方设为发药，并在YFSTORECHANGE表中添加与当前处方相同的药品（实际库存增加）*/
/*                  将ZYCFYPK中HYFLAG设为1*/
/*      2、取消调药：取消当前处方发药，并在YFSTORECHANGE表中添加与当前处方相同的负药品（实际库存减少）*/
/*                  将ZYCFYPK中HYFLAG设为NULL*/
CREATE PROCEDURE [dbo].[ExecYFHYProcess]
(@zynum int,@cfnum numeric(12,0),@sheetno char(10),@opername char(10),@note char(40),@hyflag int)
AS
begin
  /*药房库存数已不足*/
  if exists(select a01 from yfstore,zycfypk (nolock)
              where a01=goodsno and yfcode=a10 and cfnum=@cfnum and a09+ypcount<0)
    return -1  

  /*已出院*/
  if exists(select m01 from mbase (nolock) where m19 is not null and m01=@zynum)
    return -2  

  /*该处方中已有药品被发药*/
  if exists(select cfnum from zycfypk (nolock) where cfnum=@cfnum and fydate is not null and deldate is null and hyflag is null)
    return -3  

  /*该处方已执行换药处理不能再次执行*/
  if exists(select cfnum from zycfypk (nolock) where cfnum=@cfnum and hyflag is not null and @hyflag=1 and deldate is null)
    return -4

  /*该处方尚未发药，不能执行取消换药处理*/
  if exists(select cfnum from zycfypk (nolock) where cfnum=@cfnum and hyflag is null and @hyflag=0 and deldate is null)
    return -5

   
  declare @procdate datetime
  select @procdate=getdate()


  /*HYFLAG=1执行换药  HYFLAG=0取消换药*/
  if @hyflag=1
  begin
    /*先进行发药处理*/
    update zycfypk
      set fydate=@procdate,fyopername=@opername,hyflag=1
    where cfnum=@cfnum and deldate is null and fydate is null
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(ypcount*cfcount) as sumypcount 
      into #cfypcount
      from zycfypk
      where cfnum=@cfnum and deldate is null and fydate is null
      group by yfcode,cfnum,goodsno

    update yfstore
      set a16=a16-sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10


    /*以下进行库存调整处理*/
    insert yfstorechange(sheetno,goodsno,goodsname,unit,price1,price2,
                         ypcount,procdate,yfcode,yfname,opername,note,flag)      select @sheetno,goodsno,goodsname,unitname,ypprice,ypprice_1,ypcount*cfcount,@procdate,
             yfcode,yfname,@opername,@note,'换药处理'
      from zycfypk (nolock)
        where cfnum=@cfnum and deldate is null
      order by keyno

    update yfstore
      set a09=a09+ypcount
      from yfstore,zycfypk
      where a01=goodsno and a10=yfcode and cfnum=@cfnum

    /***update mzchangeprice if the price of yfstore is not a same price***/
    insert mzchangeprice       select goodsno,@procdate,ypprice,ypprice_1,a08,a07,ypcount*cfcount,(a08-ypprice)*(ypcount*cfcount),
              (a07-ypprice_1)*(ypcount*cfcount),@opername,
         '进行HY处理时药品价差',a10,a11        from yfstore,zycfypk
       where a01=goodsno and yfcode=a10 and (ypprice<>a08 or ypprice_1<>a07) and cfnum=@cfnum
  end else
  begin
    /*先进行取消发药处理*/
    update zycfypk
      set fydate=null,fyopername=null,hyflag=null
    where cfnum=@cfnum and deldate is null and fydate is not null
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(-ypcount*cfcount) as sumypcount 
      into #cfypcount2
      from zycfypk
      where cfnum=@cfnum and deldate is null and fydate is not null
      group by yfcode,cfnum,goodsno

    update yfstore
      set a16=a16-sumypcount
    from yfstore,#cfypcount2
    where #cfypcount2.goodsno=a01 and #cfypcount2.yfcode=a10


    /*以下进行取消库存调整处理*/
    insert yfstorechange(sheetno,goodsno,goodsname,unit,price1,price2,
                         ypcount,procdate,yfcode,yfname,opername,note,flag)      select @sheetno,goodsno,goodsname,unitname,ypprice,ypprice_1,-ypcount*cfcount,@procdate,
             yfcode,yfname,@opername,@note,'取消换药'
      from zycfypk (nolock)
        where cfnum=@cfnum and deldate is null
      order by keyno

    update yfstore
      set a09=a09+(-ypcount)
      from yfstore,zycfypk
      where a01=goodsno and a10=yfcode and cfnum=@cfnum

    /***update mzchangeprice if the price of yfstore is not a same price***/
    insert mzchangeprice       select goodsno,@procdate,ypprice,ypprice_1,a08,a07,-ypcount*cfcount,(a08-ypprice)*(-ypcount*cfcount),
              (a07-ypprice_1)*(-ypcount*cfcount),@opername,
         '进行HY处理时药品价差',a10,a11        from yfstore,zycfypk
       where a01=goodsno and yfcode=a10 and (ypprice<>a08 or ypprice_1<>a07) and cfnum=@cfnum
  end

  return 0
end
GO
