CREATE PROCEDURE [dbo].[DelZYFYProc]
(@cfnum int)
AS
begin
  if exists(select cfnum from zycfinf where cfnum=@cfnum) 
  begin
    if exists(select cfnum from zycfinf where cfnum=@cfnum and fydate is null)
      return 1
    update zycfinf
      set fydate=null,
          fyopername=null,
          checkdate=null,
          checkoper=null
    where cfnum=@cfnum
    update zycfypk
      set fydate=null
    where cfnum=@cfnum
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(ypcount*cfcount) as sumypcount 
      into #cfypcount
      from zycfypk
      where cfnum=@cfnum
      group by yfcode,cfnum,goodsno
    update yfstore
      set a16=a16+sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10
  end else
  begin
    if exists(select cfnum from zycfinfhis where cfnum=@cfnum and fydate is null)
      return 1
    update zycfinfhis
      set fydate=null,
          fyopername=null,
          checkdate=null,
          checkoper=null
    where cfnum=@cfnum
    update zycfypkhis
      set fydate=null
    where cfnum=@cfnum
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(ypcount*cfcount) as sumypcount 
      into #cfypcounthis
      from zycfypkhis
      where cfnum=@cfnum
      group by yfcode,cfnum,goodsno
    update yfstore
      set a16=a16+sumypcount
    from yfstore,#cfypcounthis
    where #cfypcounthis.goodsno=a01 and #cfypcounthis.yfcode=a10
  end
  
  return 0
end
GO
