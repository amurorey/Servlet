







CREATE VIEW dbo.UT_OFFICE
AS
SELECT CODE AS code, NAME AS name, PYM AS input_code
FROM dbo.KSCODE WITH (nolock)


GO
