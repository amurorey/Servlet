


CREATE VIEW MZALLCHECKVIEW AS
select mzcheck.fpnum,fpname,checkno,checkprice,checkcount,checkmoney,
       yscode,mzcheck.fpdate,mzcheck.deldate,checkname,kmname,
       kmcode,ysname,yskscode,ysksname,fskscode,fsksname,mzinvoice.jsdate
       from mzcheck,mzinvoice (nolock) 
       where mzcheck.deldate is null and mzcheck.fpnum=mzinvoice.fpnum
union all 
select mzcheckhis.fpnum,fpname,checkno,checkprice,checkcount,checkmoney,
       yscode,mzcheckhis.fpdate,mzcheckhis.deldate,checkname,kmname,
       kmcode,ysname,yskscode,ysksname,fskscode,fsksname,mzinvoicehis.jsdate
       from mzcheckhis,mzinvoicehis (nolock) 
       where mzcheckhis.deldate is null and mzcheckhis.fpnum=mzinvoicehis.fpnum


GO
