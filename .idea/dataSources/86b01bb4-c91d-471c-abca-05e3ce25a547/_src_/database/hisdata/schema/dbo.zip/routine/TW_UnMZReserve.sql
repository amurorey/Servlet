CREATE    PROCEDURE [dbo].[TW_UnMZReserve]
(@transno varchar(20),@retstr varchar(100) output)
AS
begin
  if rtrim(@transno)='' or @transno is null 
  begin
    select @retstr='预约流水号为空'
    return -1
  end

  if not exists(select transno from mzreserve (nolock) where transno=@transno)
  begin
    select @retstr='无此预约流水号对应的记录'
    return -1
  end

  if exists(select transno from mzreserve (nolock) where transno=@transno and commitdate is not null)
  begin
    select @retstr='预约流水号对应的记录已取号，不能取消预约'
    return -1
  end

  if exists(select transno from mzreserve (nolock) where transno=@transno and deldate is not null)
  begin
    select @retstr='预约流水号对应的记录已被取消预约，不能再次取消预约'
    return -1
  end

  update mzreserve
    set deldate=getdate(),delopername='自助挂号'
    where transno=@transno

  select @retstr='成功取消预约'
  return 0
end
GO
