CREATE     PROCEDURE [dbo].[DispZYInvoice] 
(@zynum int,@flag int=0)
AS
begin
  if @flag=0
    select kmcode,kmname,sum(kmmoney) as kmmoney
    from
    (select zynum,kmcode,kmname,ypmoney*cfcount as kmmoney
      from zycfypk (nolock)
      where zynum=@zynum and deldate is null
    union all
    select zynum,kmcode,kmname,ypmoney*cfcount as kmmoney
      from zycfypkhis (nolock)
      where zynum=@zynum and deldate is null
    union all
    select zynum,kmcode,kmname,checkmoney as kmmoney
      from zycheck (nolock)
      where zynum=@zynum and deldate is null
    union all 
    select zynum,kmcode,kmname,checkmoney as kmmoney
      from zycheckhis (nolock)
      where zynum=@zynum and deldate is null) disp1
    group by kmcode,kmname
    order by kmcode
  else
    select fskscode,fsksname,sum(fsmoney) as fsmoney
    from
    (select operkscode as fskscode,operksname as fsksname,ypmoney*cfcount as fsmoney
      from zycfypk (nolock)
      where zynum=@zynum and deldate is null
    union all
    select operkscode as fskscode,operksname as fsksname,ypmoney*cfcount as fsmoney
      from zycfypkhis (nolock)
      where zynum=@zynum and deldate is null
    union all
    select fskscode,fsksname,checkmoney
      from zycheck (nolock)
      where zynum=@zynum and deldate is null
    union all 
    select fskscode,fsksname,checkmoney
      from zycheckhis (nolock)
      where zynum=@zynum and deldate is null) disp1
    group by fskscode,fsksname
    order by fskscode
end
GO
