CREATE PROCEDURE [dbo].[Bank_MZRegist]
(@patientid varchar(20),@kscode varchar(10),@yscode varchar(10),@regcode varchar(10),
 @BankTranAmt varchar(30),@banktranno varchar(30),@bankPNo varchar(30),
 @banktrandate varchar(30),@banktrantime varchar(30),
 @transno varchar(20),@userid varchar(30),@bankcardno varchar(40),
 @mznum int output,@fpnum int output,@retstr varchar(255) output)
AS
begin
  declare @t_patientname varchar(20)
  declare @t_bankcardno varchar(40)
  declare @t_groupname varchar(50)
  declare @t_groupprice numeric(12,2)
  declare @t_ysname varchar(20)
  declare @t_ksname varchar(20)

  select @t_patientname=patientname from bank_regcard (nolock) where patientid=@patientid and deldate is null

  select @t_bankcardno=cardno from bank_regcard (nolock) where cardno=@bankcardno and patientid=@patientid and deldate is null

  select @t_groupname=groupname,@t_groupprice=groupprice from checkgroupcode (nolock) where groupcode=@regcode

  select @t_ysname=name from yscode (nolock) where code=@yscode

  select @t_ksname=name from kscode (nolock) where code=@kscode


  if @t_patientname is null
  begin
    select @retstr='无此PatientID对应的患者'
    return -1
  end

  if @t_bankcardno is null
  begin
    select @retstr='无此PatientID对应的银行卡，请先注册'
    return -1
  end

/*  if @t_bankcardno<>@bankcardno
  begin
    select @retstr='此PatientID注册的卡号与传入的卡号不一致'
    return -1
  end*/

  if @yscode<>'*' and @t_ysname is null
  begin
    select @retstr='无传入医师代码对应的医师'
    return -1
  end

  if @t_groupname is null
  begin
    select @retstr='无传入的挂号代码对应的挂号'
    return -1
  end

  if @yscode='*' 
  begin
    select @yscode=''
    select @t_ysname=''
  end


  declare @t_groupkeyno numeric(18)
  execute GetUniqueNo 14,@NewUniqueNo=@t_groupkeyno output

  execute GetUniqueNo 22,@NewUniqueNo=@mznum output
  execute GetUniqueNo 7,@NewUniqueNo=@fpnum output


  declare @t_currentdate datetime
  select @t_currentdate=getdate()

 
  declare @t_userid numeric(18)
  execute GetUniqueNo 0,@NewUniqueNo=@t_userid output

  delete _mzcheck where userid=@t_userid

  insert _mzcheck(checkno,checkname,unitname,checkprice,checkcount,checkmoney,yscode,
                  ysname,kmname,kmcode,yskscode,ysksname,userid,procdate,fskscode,fsksname,
                  checklb,checklbname,groupcode,groupname,groupprice,groupcount,groupkeyno)
    select checkcode,checkname,checkcode.unitname,checkprice,checkcount,checkmoney,@yscode,
           @t_ysname,checkcode.kmname,checkcode.kmcode,@kscode,@t_ksname,@t_userid,@t_currentdate,@kscode,@t_ksname,
           checklb,checklbname,@regcode,@t_groupname,@t_groupprice,1,@t_groupkeyno
      from checkgroupsheet (nolock),checkcode (nolock)
      where checkcode=code and groupcode=@regcode


  declare @t_ret int
  execute @t_ret=SaveMZFP @fpnum=@fpnum,
                   @userid=@t_userid,
                   @fpname=@t_patientname,
                   @fpmoney=@t_groupprice,
                   @opername='自助缴费',
                   @retval=@retstr output,
                   @currentdate=@t_currentdate,
                   @oldfpnum=null,
                   @ybflag=4,
                   @ybnum=null,
                   @jfcardid=null,
                   @roundflag=null,
                   @ybareacode=null,
                   @ybareaname=null,
                   @zfmoney1=@t_groupprice,
                   @zfmoney2=0,
                   @roundmoney=null,
                   @mznum=@mznum,
                   @yldyname='自费',
                   @fpnum_tmp=null,
                   @yberror=null,
                   @patientid=@patientid,
                   @transno=@transno,
                   @allownotPrnFP=1

  if @t_ret=5
  begin
    select @retstr='患者在12小时内同一科室只允许一次挂号'
    return -1
  end
  
  if @t_ret <> 0
  begin
    select @retstr='执行SaveMZFPStoredProc错误，错误代码为：'+ CONVERT(varchar(20), @t_ret)
    return -1
  end

  insert Bank_TransSheet(FPNum,MZNum,BankCardNo,BankTranAmt,BankTranNo,BankPNo,
                         BankTranDate,BankTranTime,AutoTranNo,UserID_Bank,OperDate_His,
                         TransFlag)
    values(@FPNum,@MZNum,@BankCardNo,@BankTranAmt,@BankTranNo,@BankPNo,
           @BankTranDate,@BankTranTime,@TransNo,@UserID,getdate(),
           1)
  return 0
end
GO
