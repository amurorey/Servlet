CREATE                     PROCEDURE [dbo].[AddMBase]
(@m01 int,@m02 char(20),@m03 char(20),@m04 char(20),@m04_1 char(5),
 @m05 char(4),@m06 datetime=null,@m07 float=null,@m08 varchar(20),@m09 varchar(15),
 @m10 varchar(100),@m11 datetime,@m12 char(4),@m13 char(20),@m14 datetime,
 @m15 char(10),@m16 char(4),@m17 char(20),@m18 char(20)=null,@m29 char(20),@m35 char(10)=null,
 @m39 char(20)=null,@m40 char(40)=null,@m43 char(10)=null,@m44 datetime=null,@m45 int=null,
 @m46 char(20)=null,@m47 numeric(12,2)=null,@m48 int=null,@m49 char(20)=null,@flag int=0,@m55 char(20)=null,@m58 char(20)=null,
 @m59 char(20)=null,@m60 char(10)=null,@patientid char(10)=null,@m07_Str varchar(20)=null,
 @m66 varchar(100)=null,@m67 varchar(100)=null)
AS
begin
  if @m06 is not null and (@m07 is null or @m07=0)
    select @m07=round(convert(numeric(8,2),datediff(day,@m06,@m11))/365,2)  --计算患者年龄
 
  if @flag=0 
  begin
    insert into mbase(m01,m02,m03,m04,m04_1,m05,m06,m07,m08,m09,
                      m10,m11,m12,m13,m14,m15,m16,m17,m18,m25,m26,
                      m27,m29,m33,m35,m39,m40,m43,m44,m45,m46,m47,m48,m49,m55,m58,m59,m60,patientid,m07_str,M66,M67)
      values(@m01,@m02,@m03,@m04,@m04_1,@m05,@m06,@m07,@m08,@m09,
             @m10,@m11,@m12,@m13,@m14,@m15,@m16,@m17,@m18,0,0,0,@m29,0,@m35,@m39,@m40,@m43,@m44,@m45,
             @m46,@m47,@m48,@m49,@m55,@m58,@m59,@m60,@patientid,@m07_str,@m66,@m67)
  end else
  begin
/*    declare @opername char(10)
    select @opername=m15 from mbase where m01=@m01
    if @opername <> @m15
      return 1*/
    if exists(select m01 from mbase (nolock) where m01=@m01 and m19 is not null)
      return -1  --已出院

    if exists(select zynum from zycfypk (nolock) where zynum=@m01 and jzdate<@m11
              union all
              select zynum from zycheck (nolock) where zynum=@m01 and jzdate<@m11
              union all
              select p01 from prepay (nolock) where p01=@m01 and p04<@m11)
      return -2  --入院日期大于第一笔费用日期
      
/*
    if exists(select fp0 from BA_FPage where FP0=CONVERT(varchar(20),@m01) and FP132 is not null)  --医师审核
      return -3  --病案首页已被医师审核

    if exists(select fp0 from BA_FPage where FP0=CONVERT(varchar(20),@m01) and FP121 is not null)  --病案室审核
      return -4  --病案首页已被病案室审核
*/


/*    declare @oldm11 datetime  --入院日期
    declare @m51 datetime     --入科日期
    select @oldm11=m11,@m51=m51 from mbase (nolock) where m01=@m01
    if not(datepart(year,@oldm11)=datepart(year,@m11) and 
       datepart(month,@oldm11)=datepart(month,@m11) and
       datepart(day,@oldm11)=datepart(day,@m11)) and
       @m51 is not null  --如果该病人已被科室接收并修改了入院日期
    begin
      exec ba_processbqgzrb @m12,@m13,@oldm11,1,-1,0
      
      exec ba_processbqgzrb @m12,@m13,@m11,1,1,0 
    end*/

    declare @t_oldm04 varchar(20)  --原姓名
    declare @t_oldm08 varchar(20)  --原身份证
    declare @t_oldm05 varchar(10)  --原性别
    declare @t_oldm06 datetime
    declare @t_changestr varchar(100)
    select @t_oldm04=m04,@t_oldm08=m08,@t_oldm05=m05,@t_oldm06=M06 from mbase (nolock) where m01=@m01
    select @t_changestr=''
    if @t_oldm04<>@m04 
      select @t_changestr=@t_changestr + '患者姓名已由“' + @t_oldm04 + '”改为“'+ rtrim(@m04) + '”'
    if @t_oldm08<>@m08 
      select @t_changestr=@t_changestr + '患者身份证号已由“' + @t_oldm04 + '”改为“'+ rtrim(@m08) + '”'
    if @t_oldm05<>@m05 
      select @t_changestr=@t_changestr + '患者性别已由“' + @t_oldm04 + '”改为“'+ rtrim(@m05) + '”'
    if convert(varchar(20),@t_oldm06,112)<>convert(varchar(20),@m06,112)
      select @t_changestr=@t_changestr + '患者出生日期“'+convert(varchar(20),@t_oldm06,112)+'” 已改为“'+convert(varchar(20),@m06,112) + '”'

    --如果没有发生转科可修改当前科室及当前床号
    if not exists(select zynum from turnmess (nolock) where zynum=@m01)
    begin
      update mbase
        set m02=@m02,
            m03=@m03,
            m04=@m04,
            m04_1=@m04_1,
            m05=@m05,
            m06=@m06,
            m07=@m07,
            m07_str=@m07_str,
            m08=@m08,
            m09=@m09,
            m10=@m10,
            m11=@m11,
            m12=@m12,
            m13=@m13,
            m16=@m16,
            m17=@m17,
            m18=case when rtrim(@m18)='' or @m18 is null then m18 else @m18 end,  --如变量为空则不修改原值
            m29=@m29,
            m35=case when rtrim(@m35)='' or @m35 is null then m35 else @m35 end,  --如变量为空则不修改原值
            m39=@m39,   
            m40=@m40,
            M66=@m66,
            M67=@m67
        where m01=@m01
    end else
    begin
      update mbase
        set m02=@m02,
            m03=@m03,
            m04=@m04,
            m04_1=@m04_1,
            m05=@m05,
            m06=@m06,
            m07=@m07,
            m07_str=@m07_str,
            m08=@m08,
            m09=@m09,
            m10=@m10,
            m11=@m11,
            m12=@m12,
            m13=@m13,
            m29=@m29,
            m35=case when rtrim(@m35)= '' or @m35 is null then m35 else @m35 end,
            m39=@m39,   
            m40=@m40,
            M66=@m66,
            M67=@m67
        where m01=@m01
    end

    if @m67 is null or rtrim(@m67)=''  --若单位地址为空则取现住址
      select @m67=@m10

    update ba_fpage
      set fp6=@m02,
          fp7=@m03,
          fp2=@m04,
          fp3=case when @m05='男' then '1' else '2' end,
          fp4=@m06,
          fp5=@m07,
          fp5_str=@m07_str,
          fp22=@m09,
          fp14=case when fp14 is null or rtrim(fp14)='' then @m67 else FP14 end,                  --单位地址
          FP17_YS=case when fp17_ys is null or rtrim(fp17_ys)='' then @m66 else FP17_YS end,      --户口地址
          FP137_YS=case when fp137_ys is null or rtrim(fp137_ys)='' then @m10 else FP137_YS end,  --现住址
          PersonNo=case when @m08 is null or RTRIM(@m08)='' then PersonNo else @m08 end
       where fp0=rtrim(convert(char(20),@m01)) and FP132 is null  --医师审核前允许修改
    if @t_changestr <> ''
    begin
      declare @t_opercode char(10)

      if @m15='系统维护员' 
        set @t_opercode='sa'
      else
        select @t_opercode=code from yscode (nolock) where name=@m15
      insert hislog(OperCode,OperName,OperDate,OperFlag,OperLog,note)
        values(@t_opercode,@m15,getdate(),3,@t_changestr,'由出入院处修改患者本次入院信息')
    end



--    update patientbase
--      set patientname=@m04
--      from patientbase,mbase
--      where mbase.patientid=patientbase.patientid and m01=@m01

  end
  return 0
end
GO
