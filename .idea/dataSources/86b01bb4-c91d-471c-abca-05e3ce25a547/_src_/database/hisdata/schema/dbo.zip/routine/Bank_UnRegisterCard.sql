CREATE   PROCEDURE [dbo].[Bank_UnRegisterCard]
(@patientid varchar(20),@cardno varchar(20),@userid varchar(20),@transno varchar(30))
AS
begin
  if not exists(select cardno from bank_regcard (nolock) where cardno=@cardno and patientid=@patientid and deldate is null)
    return -1 

/*  update patientbase
    set bankcardno=null,bindingdate_bank=null,userid_bank=@userid,transno_bank=@transno
    where patientid=@patientid and bankcardno=@cardno*/

  update bank_regcard
    set deldate=getdate(),
        del_userid=@userid,
        del_transno=@transno
    where cardno=@cardno and deldate is null

  return 0
end
GO
