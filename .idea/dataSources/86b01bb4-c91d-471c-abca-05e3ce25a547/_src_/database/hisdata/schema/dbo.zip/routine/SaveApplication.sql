--保存检查申请单存储过程
/*
说明：1、门诊申请单直接保存到Patient_ApplicationSheet及Patient_ApplicationCheckCode表中
      2、住院申请单先保存到_Patient_ApplicationSheet及_Patient_ApplicationCheckCode表中临时表中，
         待医嘱编辑确认后再保存到Patient_ApplicationSheet及Patient_ApplicationCheckCode表中。
*/
CREATE   PROCEDURE [dbo].[SaveApplication]
(@mznum int=null, @zynum int=null,@patientid int=null,@emergency_flag int, @diagnose varchar(128),@userid numeric(18))
AS
begin
  declare @ret int
  select @ret = 0

  /*自动过滤申请单中组套中的重复项目*/ 
  declare @t_appcode int
  declare @t_checkcount numeric(12,2)
  declare @t_checkno varchar(20)
  declare @t_checkprice numeric(12,2)
  declare @t_groupprice1 numeric(12,2)
  declare @t_maxcount numeric(12,2)
  declare @t_maxgroupprice numeric(12,2)
  declare @t_keyno1 numeric(18)
  declare @t_delflag int
  declare @t_count int

  DECLARE _mzcheck1_cursor CURSOR FOR
  select keyno,_mzcheck.applicationcode,checkno,checkprice,checkcount
    from _mzcheck (nolock),applicationsheet (nolock)
    where _mzcheck.applicationcode=applicationsheet.applicationcode and applicationsheet.deldate is null and TreeLevel=0 and filterflag=1 and
          userid=@userid and groupcode is not null
    order by _mzcheck.applicationcode,groupkeyno
  OPEN _mzcheck1_cursor
  FETCH NEXT FROM _mzcheck1_cursor into @t_keyno1,@t_appcode,@t_checkno,@t_checkprice,@t_checkcount
  WHILE @@FETCH_STATUS = 0
  BEGIN
    select @t_maxcount=max(checkcount),@t_count=count(*),@t_maxgroupprice=max(groupprice) 
      from _mzcheck (nolock)
      where userid=@userid and checkno=@t_checkno and groupcode is not null and applicationcode=@t_appcode

    select @t_delflag=case when userid<0 then 1 else 0 end,@t_groupprice1=groupprice 
      from _mzcheck (nolock)
      where userid=@userid and keyno=@t_keyno1  and applicationcode=@t_appcode

    if @t_delflag=0 and @t_maxcount>0 and @t_count>1
    begin
      if @t_checkcount=@t_maxcount
        if @t_groupprice1=@t_maxgroupprice
          update _mzcheck
            set userid=-userid
            where userid=@userid and keyno<>@t_keyno1 and checkno=@t_checkno and groupcode is not null  and applicationcode=@t_appcode
        else
          update _mzcheck 
            set userid=-userid
            where userid=@userid and keyno=@t_keyno1 and checkno=@t_checkno and groupcode is not null and applicationcode=@t_appcode
      else
        update _mzcheck 
          set userid=-userid
          where userid=@userid and keyno=@t_keyno1 and checkno=@t_checkno and groupcode is not null and applicationcode=@t_appcode
    end
    

    FETCH NEXT FROM _mzcheck1_cursor into @t_keyno1,@t_appcode,@t_checkno,@t_checkprice,@t_checkcount
  END
  CLOSE _mzcheck1_cursor
  DEALLOCATE _mzcheck1_cursor
  delete _mzcheck where userid=-@userid
  /*--------------------------------------------------------*/


  --更新_mzcheck表中的字段
  update _mzcheck
    set groupprice=disp.groupprice
    from _mzcheck (nolock),
        (select groupkeyno,sum(checkprice*checkcount) as groupprice
          from _mzcheck (nolock) where userid=@userid and groupcode is not null
          group by groupkeyno) disp
    where _mzcheck.groupkeyno=disp.groupkeyno and userid=@userid
  if @@error <> 0 
  begin
    select @ret = -1
    goto bott
  end


  update _mzcheck
    set checkmoney=case when groupcode = '' or groupcode is null then checkcount*checkprice
                        else checkcount*checkprice*groupcount end,
        checkcount=case when groupcode = '' or groupcode is null then checkcount
                        else checkcount*groupcount end
    where userid=@userid
  if @@error <> 0 
  begin
    select @ret = -1
    goto bott
  end


  --更新_mzhcek表中的GroupKeyNo
  declare @t_groupkeyno numeric(18)
  declare @t_newgroupkeyno numeric(18)

  DECLARE _mzcheck_cursor CURSOR FOR
  select groupkeyno
    from _mzcheck (nolock)
  where userid=@userid
    group by applicationcode,groupkeyno
  OPEN _mzcheck_cursor
  FETCH NEXT FROM _mzcheck_cursor into @t_groupkeyno
  WHILE @@FETCH_STATUS = 0
  BEGIN
    begin transaction  --开始事务--
      execute GetUniqueNo 14,@NewUniqueNo=@t_newgroupkeyno output  --生成新的GroupKeyNo
    commit transaction --结束事务--
    update _mzcheck
      set newgroupkeyno=@t_newgroupkeyno
      where userid=@userid and groupkeyno=@t_groupkeyno

    FETCH NEXT FROM _mzcheck_cursor into @t_groupkeyno
  END
  CLOSE _mzcheck_cursor
  DEALLOCATE _mzcheck_cursor

  --1、门诊申请
  if @mznum is not null
  begin
    if exists(select applynum from patient_applicationsheet (nolock)
                where  applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum) and jzdate is not null)
      select @ret = 1  --已记账，不能被修改

    --开始事务--
    begin transaction
    delete Patient_ApplicationCheckCode where applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum)
    if @@error <> 0 
    begin
      rollback
      select @ret = -1
      goto bott
    end

    insert Patient_ApplicationCheckCode(MZNUM,ZYNum,PATIENTID,APPLYNUM,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,
                                        CHECKCOUNT,CHECKMONEY,KMNAME,KMCODE,FSKSCODE,FSKSNAME,
                                        CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,
                                        GROUPKEYNO,NewGroupKeyNo,YBNO,YBKMCODE,ApplicationCode,ApplicationName,checkname2,samplecode,sampletype,emergency_flag,xmkeyno,
                                        hivcode,hivname,TubeColor)
      select @MZNUM,@ZYNum,@PATIENTID,YJAPPLYNUM,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,
             CHECKCOUNT,CHECKMONEY,KMNAME,KMCODE,FSKSCODE,FSKSNAME,
             CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,
             GROUPKEYNO,NewGroupKeyNo,YBNO,YBKMCODE,ApplicationCode,ApplicationName,checkname2,samplecode,sampletype,@emergency_flag,xmkeyno,
             hivcode,hivname,TubeColor
        from _mzcheck (nolock)
        where userid=@userid
    if @@error <> 0 
    begin
      rollback
      select @ret = -1
      goto bott
    end


    delete Patient_ApplicationSheet where applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum)
    if @@error <> 0 
    begin
      rollback
      select @ret = -1
      goto bott
    end
    
    declare @t_patientname varchar(20)
    select @t_patientname=patientname from MZRegisterSheet (nolock) where MZNum=@mznum
    
    insert Patient_ApplicationSheet(patientname,APPLYNUM,MZNUM,ZYNUM,PATIENTID,CHECKMONEY,FSKSCODE,FSKSNAME,
                                    YSCODE,YSNAME,YSKSCODE,YSKSNAME,APPLYDATE,
                                    ApplicationCode,ApplicationName,ApplicationType,note,diagnose,emergency_flag,priceflag,XMLDoc)
      select @t_patientname,yjapplynum,@mznum,@ZYNum,@patientid,sum(checkmoney),fskscode,fsksname,
             yscode,ysname,yskscode,ysksname,getdate(),
             applicationcode,applicationname,ApplicationType,note,@diagnose,@emergency_flag,case when CHECKNO is null then 1 else null end as pricerflag,XMLDoc
      from _mzcheck (nolock)
      where userid=@userid
      group by yjapplynum,fskscode,fsksname,yscode,ysname,yskscode,ysksname,
               applicationcode,applicationname,Applicationtype,note,case when CHECKNO is null then 1 else null end,XMLDoc
      order by yjapplynum
    if @@error <> 0 
    begin
      rollback
      select @ret = -1
      goto bott
    end
    
 
    commit transaction
    --结束事务--
  end else if @zynum is not null
  begin
    if exists(select applynum from patient_applicationsheet (nolock)
                where  applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum) and yzrundate is not null)
      select @ret = 2  --临时医嘱（检查申请后生成的医嘱）已执行，不能被修改申请单

    declare @t_oldyzid int
    select @t_oldyzid=_yzsheet.yzid from _yzsheet (nolock),_patient_applicationsheet (nolock)
      where _yzsheet.yzid=_patient_applicationsheet.yzid and _yzsheet.userid=@userid 
        and applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum)

    delete _yzsheet
      where userid=@userid and yzid=@t_oldyzid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    delete _Patient_ApplicationCheckCode 
      where applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum)
            and userid=@userid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    insert _Patient_ApplicationCheckCode(ZYNum,PATIENTID,APPLYNUM,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,
                                         CHECKCOUNT,CHECKMONEY,KMNAME,KMCODE,FSKSCODE,FSKSNAME,
                                         CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,
                                         GROUPKEYNO,NewGroupKeyNo,YBNO,YBKMCODE,ApplicationCode,
                                         ApplicationName,checkname2,samplecode,sampletype,emergency_flag,procdate,XMKeyNo,hivcode,hivname,userid,TubeColor)
    select @ZYNum,@PATIENTID,YJAPPLYNUM,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,
           CHECKCOUNT,CHECKMONEY,KMNAME,KMCODE,FSKSCODE,FSKSNAME,
           CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,
           GROUPKEYNO,NewGroupKeyNo,YBNO,YBKMCODE,ApplicationCode,
           ApplicationName,checkname2,samplecode,sampletype,@emergency_flag,getdate(),XMKeyNO,hivcode,hivname,@userid,TubeColor
      from _mzcheck (nolock)
      where userid=@userid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    delete _Patient_ApplicationSheet 
      where applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid group by yjapplynum)
        and userid=@userid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    insert _Patient_ApplicationSheet(APPLYNUM,MZNUM,ZYNUM,PATIENTID,CHECKMONEY,FSKSCODE,FSKSNAME,
                                    YSCODE,YSNAME,YSKSCODE,YSKSNAME,APPLYDATE,
                                    ApplicationCode,ApplicationName,ApplicationType,note,diagnose,emergency_flag,procdate,XMLDoc,userid)
      select yjapplynum,@mznum,@ZYNum,@patientid,sum(checkmoney),fskscode,fsksname,
             yscode,ysname,yskscode,ysksname,getdate(),
             applicationcode,applicationname,ApplicationType,note,@diagnose,@emergency_flag,getdate(),XMLDoc,@userid
      from _mzcheck (nolock)
      where userid=@userid
      group by yjapplynum,fskscode,fsksname,yscode,ysname,yskscode,ysksname,
               applicationcode,applicationname,Applicationtype,note,XMLDoc
      order by yjapplynum
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    update _patient_applicationsheet
      set patientname=m04,bedno=m18,lykscode=m16,lyksname=m17,yldyname=m02
      from _patient_applicationsheet (nolock),mbase (nolock)
      where userid=@userid and zynum=m01
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end

    update _patient_applicationsheet
      set jzflag=applicationsheet.jzflag
      from _patient_applicationsheet (nolock),applicationsheet (nolock)
      where _patient_applicationsheet.applicationcode=applicationsheet.applicationcode and userid=@userid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end
     
    declare @t_yzid int
    declare @t_fskscode char(4)
    declare @t_fskscode2 char(4)
    declare @t_fsksname char(20)
    declare @t_fsksname2 char(20)

    declare @t_applicationcode int
    declare @t_applicationcode2 int
    declare @t_XMName nvarchar(200)
    declare @t_xmname2 nvarchar(200)
    declare @t_applynum int
    declare @t_applynum2 int
    declare @t_keyno numeric(18)
    DECLARE _mzcheck_cursor CURSOR FOR
      select applicationcode,checkname2,fskscode,fsksname,yjapplynum,min(keyno) as keyno
        from _mzcheck (nolock)
        where userid=@userid and groupcode is null
        group by applicationcode,checkname2,fskscode,fsksname,yjapplynum
      union all
      select applicationcode,groupname,fskscode,fsksname,yjapplynum,min(keyno)
        from _mzcheck (nolock)
        where userid=@userid and groupcode is not null
        group by applicationcode,groupname,fskscode,fsksname,yjapplynum
      order by applicationcode,keyno

    OPEN _mzcheck_cursor
    FETCH NEXT FROM _mzcheck_cursor into @t_applicationcode,@t_xmname,@t_fskscode,@t_fsksname,@t_applynum,@t_keyno
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @t_xmname2=/*rtrim(@t_fsksname)+*/case when @emergency_flag=1 then '(急诊):' else '' end
      select @t_applicationcode2=@t_applicationcode,@t_fskscode2=@t_fskscode,@t_fsksname2=@t_fsksname,@t_applynum2=@t_applynum
      while @@FETCH_STATUS = 0 and @t_applicationcode=@t_applicationcode2
      begin
        select @t_xmname2=@t_xmname2+rtrim(@t_xmname)

        FETCH NEXT FROM _mzcheck_cursor into @t_applicationcode,@t_xmname,@t_fskscode,@t_fsksname,@t_applynum,@t_keyno

        if (@@FETCH_STATUS = 0) and @t_applicationcode=@t_applicationcode2
          select @t_xmname2=@t_xmname2+'、'
      end

      if @t_oldyzid is null
      begin
        begin transaction    --开始事务--
          execute GetUniqueNo 15,@NewUniqueNo=@t_yzid output
        commit transaction   --结束事务
      end else
      begin
        set @t_yzid=@t_oldyzid
      end

      insert _yzsheet(yzid,yzflag,xmname,xmflag,yzcountforday,yzcountforweek,
                      fskscode,fsksname,userid)
        values(@t_yzid,2,@t_xmname2,11,1,1,
               @t_fskscode2,@t_fsksname2,-@userid)
      if @@error <> 0 
      begin
        select @ret = -1
        goto bott
      end

      update _patient_applicationsheet
        set yzid=@t_yzid
        where userid=@userid and applynum=@t_applynum2
      if @@error <> 0 
      begin
        select @ret = -1
        goto bott
      end
    END
    CLOSE _mzcheck_cursor
    DEALLOCATE _mzcheck_cursor

    update _yzsheet
      set userid=@userid
      where userid=-@userid
    if @@error <> 0 
    begin
      select @ret = -1
      goto bott
    end
  end

  bott:
  delete _mzcheck where userid=@userid
  if @ret = -1 
  begin
    delete _patient_applicationcheckcode where userid=@userid and applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid)
    delete _patient_applicationsheet where userid=@userid and applynum in(select yjapplynum from _mzcheck (nolock) where userid=@userid)
    delete _yzsheet where userid=-@userid
  end

  return @ret
end
GO
