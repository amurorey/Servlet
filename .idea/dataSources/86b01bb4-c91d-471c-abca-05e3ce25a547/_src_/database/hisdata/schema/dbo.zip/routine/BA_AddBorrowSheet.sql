CREATE    PROCEDURE [dbo].[BA_AddBorrowSheet]
(@yscode char(4),@note char(40),@opername char(10),@userid numeric(18),@borrowreson int=5,@borrowresontext varchar(128),@commitdate datetime,@errmess char(40) output)
AS
begin
  select @errmess=null
  select @errmess=rtrim(convert(char(20),fp0))+'  '+fp2+'已被借阅' from ba_fpage,_ba_borrowsheet (nolock) where fp0=zynum and ba_fpage.borrowdate is not null and userid=@userid
  if @errmess is not null
    return -1
  
  select @errmess=null
  select @errmess=rtrim(convert(char(20),fp0))+'  '+fp2+'尚未归档' from ba_fpage,_ba_borrowsheet (nolock) where fp0=zynum and ba_fpage.fp125 is null and userid=@userid
  if @errmess is not null
    return -2

  declare @borrowdate datetime
  select @borrowdate=getdate()

  declare @ysname char(20)
  declare @yskscode char(4)
  declare @ysksname char(20)
  select @ysname=[name],@yskscode=kscode,@ysksname=ksname
    from yscode (nolock) 
    where [code]=@yscode

  insert ba_borrowsheet(zynum,borrowdate,borrowysname,borrowkscode,borrowksname,borrowopername,note,borrowreson,borrowresontext,commitdate)
    select zynum,@borrowdate,@ysname,@yskscode,@ysksname,@opername,@note,@borrowreson,@borrowresontext,@commitdate
      from _ba_borrowsheet (nolock)
      where userid=@userid

  update ba_fpage
    set borrowdate=@borrowdate,borrowysname=@ysname
    from ba_fpage,_ba_borrowsheet
    where fp0=zynum and userid=@userid

  delete _ba_borrowsheet where userid=@userid

  return 0
end
GO
