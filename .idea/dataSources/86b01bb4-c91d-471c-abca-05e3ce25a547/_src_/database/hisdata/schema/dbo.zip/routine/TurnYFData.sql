CREATE PROCEDURE [dbo].[TurnYFData]
(@yfcode char(2),@turndate datetime,@turnyear int,@opername char(10))
AS
begin
  if exists(select * from yfturnset where yfcode=@yfcode and turnyear=@turnyear)
    return 1

  insert yfturndata
    select a01,a02,a09,a07,a08,@yfcode,@turndate,@turnyear,@opername from yfstore
      where a10=@yfcode and a09<>0

  update yfturnset
    set enddate=@turndate where enddate is null and yfcode=@yfcode

  insert yfturnset
    values(@yfcode,@turnyear,@turndate,null,@opername)

  
end
GO
