CREATE    PROCEDURE [dbo].[SaveMZFP_Tmp]
(@userid numeric,@fpname char(20),@opername char(10),@oldfpnum int=0,@retval varchar(1024)="" output)
AS
begin
    /***库存不足判断***/
    if exists (select goodsno from _mzcfypgroupview,yfstore (nolock)
                 where _mzcfypgroupview.goodsno=yfstore.a01
                 and _mzcfypgroupview.yfcode=yfstore.a10 
                 and yfstore.a09<(_mzcfypgroupview.sumypcount)
                 and _mzcfypgroupview.userid=@userid)
    begin
      declare @t_disptext char(100)
      DECLARE checkyfstore_cursor CURSOR FOR
        select rtrim(yfstore.a11)+'"'+rtrim(yfstore.a02)+'"的库存为'+rtrim(convert(char(10),yfstore.a09))+'已不足' as disptext
          from _mzcfypgroupview,yfstore (nolock)
                 where _mzcfypgroupview.goodsno=yfstore.a01
                 and _mzcfypgroupview.yfcode=yfstore.a10 
                 and yfstore.a09<(_mzcfypgroupview.sumypcount)
                 and _mzcfypgroupview.userid=@userid
      OPEN checkyfstore_cursor
      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
      WHILE @@FETCH_STATUS = 0
      BEGIN
        select @retval=@retval+@t_disptext+char(13)

        FETCH NEXT FROM checkyfstore_cursor into @t_disptext
      END
      CLOSE checkyfstore_cursor
      DEALLOCATE checkyfstore_cursor

      return 1
    end

  declare @t_currentdate datetime
  select @t_currentdate=getdate()

 
  declare @t_fpnum_tmp int
  if @oldfpnum=0
  begin
    execute GetUniqueNo 6,@NewUniqueNo=@t_fpnum_tmp output  --用CFNUM代替FPNUM_Tmp临时用
  end else
  begin
    select @t_fpnum_tmp=@oldfpnum
    select @fpname=fpname from mzinvoice_tmp where fpnum_tmp=@oldfpnum
  end

  delete mzcfinf_tmp where fpnum_tmp=@oldfpnum
  delete mzcfypk_tmp where fpnum_tmp=@oldfpnum
  delete mzcheck_tmp where fpnum_tmp=@oldfpnum
  delete mzinvoice_tmp where fpnum_tmp=@oldfpnum

  /***Insert into mzcfinf_tmp table***/
  insert mzcfinf_tmp(CFNUM,FPNUM_TMP,CFFLAG,CFPRICE,CFCOUNT,CFMONEY,YFCODE,YFNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,OPERDATE)
    select cfnum,@t_fpnum_tmp,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,yscode,ysname,yskscode,ysksname,@t_currentdate
      from _mzcfinf
      where userid=@userid and cfmoney<>0
      order by cfnum

  /***Insert into mzcfypk_tmp table***/
  insert mzcfypk_tmp(FPNUM_TMP,CFNUM,GOODSNO,YPCOUNT,YPPRICE,YPPRICE_1,YPMONEY,CFCOUNT,
                     GOODSNAME,PROCNAME,UNITNAME,YFCODE,YFNAME,KMCODE,KMNAME,OPERDATE,
                     YSCODE,YSNAME,YSKSCODE,YSKSNAME,YBLB,YBLBNAME,YBNO,YBKMCODE,clflag)
    select @t_fpnum_tmp,CFNUM,GOODSNO,YPCOUNT,YPPRICE,YPPRICE_1,YPMONEY,CFCOUNT,
           GOODSNAME,PROCNAME,UNITNAME,YFCODE,YFNAME,KMCODE,KMNAME,@t_currentdate,
           YSCODE,YSName,YSKSCODE,YSKSNAME,YBLB,YBLBNAME,YBNO,YBKMCODE,CLFlag
      from _mzcfypk 
      where userid=@userid
      order by keyno

  /***Insert into mzcheck_tmp table***/
  insert mzcheck_tmp(FPNUM_TMP,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,CHECKCOUNT,
                     CHECKMONEY,KMCODE,KMNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
                     FSKSCODE,FSKSNAME,CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,
                     GROUPCOUNT,GROUPKEYNO,YBNO,YBKMCODE,YJApplyNum,OPERDATE)
    select @t_fpnum_tmp,CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,CHECKCOUNT,
           CHECKMONEY,KMCODE,KMNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
           FSKSCODE,FSKSNAME,CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,
           GROUPCOUNT,GROUPKEYNO,YBNO,YBKMCODE,YJApplyNum,@t_currentdate
    from _mzcheck
    where userid=@userid
    order by keyno

  declare @t_totmoney numeric(12,2)
  select @t_totmoney=sum(xmmoney) from
    (select sum(ypmoney*cfcount) as xmmoney from _mzcfypk where userid=@userid
     union all
     select sum(checkmoney) as xmmoney from _mzcheck where userid=@userid) dispview

  /***Insert into mzinvoice_tmp table***/
  insert mzinvoice_tmp(FPNUM_TMP,FPNAME,FPMONEY,OPERDATE,OPERNAME)
    values(@t_fpnum_tmp,@FPNAME,@t_totmoney,@t_currentdate,@opername)

end
GO
