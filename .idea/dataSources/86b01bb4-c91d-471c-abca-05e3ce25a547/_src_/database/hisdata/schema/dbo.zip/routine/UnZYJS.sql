CREATE    procedure [dbo].[UnZYJS]
(@zynum int,@fpnum int,@opercode char(10),@opername char(20))
as
begin
declare @jsdate datetime
declare @jsoper char(20)

select @jsdate=jsdate,@jsoper=jsoper from zyinvoicebase where zynum=@zynum and fpnum=@fpnum

begin transaction

--------------------------------------------------------------
/*以下为将HIS数据重新复制到非HIS表中*/
--------------------------------------------------------------
insert prepay(p01,p02,p03,p04,p05,p06,p07,p08,p09,p10,fpnum)
  select p01,p02,p03,p04,p05,p06,p07,p08,p09,p10,fpnum
    from prepayhis
    where fpnum in(select fpnum from zyinvoicebase where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum)
if @@error <> 0 
begin
  rollback
  return -1
end

delete prepayhis where fpnum in(select fpnum from zyinvoicebase where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum)
if @@error <> 0 
begin
  rollback
  return -1
end

insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                  cfcount,goodsname,procname,unitname,yfcode,jzdate,jzoper,
                  jsdate,fpdate,fydate,fyopername,deldate,deloper,kmcode,kmname,lykscode,
                  lyksname,yscode,ysname,yskscode,ysksname,yjfpnum,yplb,yplbname,xjsjnum,
                  percount,ypjl,ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,
                  tycfnum,tycount,tyid,ybno,ybkmcode,ybtransflag,hyflag,hzylflag,clflag,zgysname,jbypflag,printedjdcard)
  select zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                  cfcount,goodsname,procname,unitname,yfcode,jzdate,jzoper,
                  jsdate,fpdate,fydate,fyopername,deldate,deloper,kmcode,kmname,lykscode,
                  lyksname,yscode,ysname,yskscode,ysksname,yjfpnum,yplb,yplbname,xjsjnum,
                  percount,ypjl,ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,
                  tycfnum,tycount,tyid,ybno,ybkmcode,ybtransflag,hyflag,hzylflag,clflag,zgysname,jbypflag,printedjdcard
    from zycfypkhis
    where jsdate=@jsdate and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

delete zycfypkhis where jsdate=@jsdate and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end



insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzdate,jzoper,jsdate,fpdate,
                  deldate,deloper,checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                  yskscode,ysksname,yjfpnum,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,
                  hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,cdcfnum,tfid,jzkscode,
                  groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,ybtransflag,
                  hzylflag,checkoper,checkdate,yjapplynum,tfkeyno,ybjyid,zgysname)
  select zynum,checkno,checkprice,checkcount,checkmoney,jzdate,jzoper,jsdate,fpdate,
         deldate,deloper,checkname,kmname,kmcode,lykscode,lyksname,yscode,
         ysname,yskscode,ysksname,yjfpnum,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,
         hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,cdcfnum,tfid,jzkscode,
         groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,ybtransflag,
         hzylflag,checkoper,checkdate,yjapplynum,tfkeyno,ybjyid,zgysname
    from zycheckhis
    where jsdate=@jsdate and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

delete zycheckhis where jsdate=@jsdate and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end


  update mbase
    set m31=null
    where m30 is not null and m31 =@jsdate and m32=@jsoper and m01=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end
  
  update prepay
    set p09=null
    where p09 =@jsdate and p05=@jsoper and p01=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

/*  update prepayhis
    set p09=null
    where p09 =@jsdate and p05=@jsoper*/

  update zycheck
    set jsdate=null
    from zycheck,zyinvoicebase
    where zycheck.yjfpnum=zyinvoicebase.fpnum
      and zyinvoicebase.jsdate =@jsdate and fpoper=@jsoper and zycheck.zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

  update zycfypk
    set jsdate=null
    from zycfypk,zyinvoicebase
    where zycfypk.yjfpnum=zyinvoicebase.fpnum
      and zyinvoicebase.jsdate =@jsdate and fpoper=@jsoper and zycfypk.zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

  update zyinvoicebase
    set jsdate=null,jsoper=null   
    where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

  update zyinvoice
    set jsdate=null,jsoper=null
    where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

  update yb_zyinvoice
    set jsdate=null,jsoper=null
    where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

  update yj_applysheet
    set jsdate=zyinvoicebase.jsdate
    from yj_applysheet,zyinvoicebase
    where yj_applysheet.fpnum=zyinvoicebase.fpnum and yj_applysheet.jsdate =@jsdate and zynum=@zynum
          and patientkind=2 and zyinvoicebase.jsoper=@jsoper
if @@error <> 0 
begin
  rollback
  return -1
end

  /*东软医保数据表结算*/
  update dryb_invoicebase
    set jsdate=null
    where jsdate =@jsdate and fpoper=@jsoper and patientstate=2 and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

/*新农合数据表结算*/
update xnh_invoicebase
  set jsdate=null
  where jsdate =@jsdate and fpopername=@jsoper and patientstate=2 and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end

/*银海医保数据表结算*/
update yhyb_invoicebase
  set jsdate=null
  where jsdate =@jsdate and fpoper=@jsoper and zynum=@zynum
if @@error <> 0 
begin
  rollback
  return -1
end


insert hislog(opercode,opername,operdate,operflag,operlog)
  values(@opercode,@opername,getdate(),2,'取消发票号为"'+convert(varchar(20),@fpnum)+'"的日结数据，原日结日期为:'+convert(varchar(50),@jsdate,121))

commit transaction
return 0

end
GO
