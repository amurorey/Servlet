





CREATE VIEW dbo.UT_LIS_MODULE_KIND
AS
SELECT Code AS Kind_Code, Name AS Kind_Name, '0' AS Flag_Sex
FROM dbo.SampleType


GO
