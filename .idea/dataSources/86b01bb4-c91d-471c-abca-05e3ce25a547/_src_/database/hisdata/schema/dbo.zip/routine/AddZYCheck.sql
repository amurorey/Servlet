--YJApplyNumVal不为空，则表示申请单必须由医技科室划价后录入
CREATE     PROCEDURE [dbo].[AddZYCheck] 
(@zynum int,@opername char(10),@operdate datetime,@userid numeric,@xjsjnum char(10),@qfsetflag int,
 @operkscode char(4),@operksname char(10),@yzflag int=2,@YJRunFlag int=0,@SubYZID int=null,@yjapplynum int=null,@scale int=null)
AS
begin
  if exists(select m01 from mbase where m01=@zynum and m19 is not null) 
    return 1
  declare @currentkscode char(4),@currentksname char(20),@qfmoney float
  if exists(select m01 from mbase where m01=@zynum)
    select @currentkscode=m16,@currentksname=m17,@qfmoney=m25-m27-case when m50 is null then 0 else m50 end from mbase where m01=@zynum
  else
    return 2

  if (@xjsjnum is null) and @qfsetflag=0 and @qfmoney>0 /*禁止欠费*/
    return 3

  declare @sumcheckmoney numeric(12,2)
  select @sumcheckmoney=sum(checkmoney) from _zycheck
    where userid=@userid

  if (@xjsjnum is null) and @qfsetflag>=0 and @qfsetflag<(@qfmoney+@sumcheckmoney) /*大于允许欠费额度*/
    return 4

  if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
    return 5  --已取消入院

  if exists(select zynum from Patient_ApplicationSheet where ZYNUM=@zynum and APPLYNUM=@yjapplynum and JZDATE is not null)
    return 6  --已记账

  /*寻找床位对应的护士*/
  declare @hscode char(4),@hsname char(10),@zgysname char(10)
  select @hscode=hscode,@hsname=hsname,@zgysname=ysname from mbase,kscwset (nolock)
    where kscode=m16 and cwname=m18 and m01=@zynum


  /*******更新_ZYCHECK中的有关医保属性的字段*******/

  /*如果医保接口已运行则进行下列更新*/
  if exists(select YB_HOSPNO from unitset where YB_HOSPNO is not null)
  begin
    /**更新_zycheck对应的医保代码（如果有）**/
    update _zycheck
      set ybno=ybcheckcode
      from _zycheck,checkcode
      where checkno=code and userid=@userid

    /**更新_zycheck对应的医保科目**/
    update _zycheck
      set ybkmcode=yb_checkcode.kmcode,
          checklb=case when yblb='1' or yblb='2' or yblb='3' or yblb='4' then yblb else '3' end,
          checklbname=case 
                        when yblb='1' then '甲类' 
                        when yblb='2' then '乙类' 
                        when yblb='3' then '丙类'
                        when yblb='4' then '特检特治'
                        else '丙类' 
                      end
      from _zycheck,yb_checkcode
      where _zycheck.ybno=yb_checkcode.checkno and userid=@userid and yb_checkcode.flag=0
    /**如果没有医保对应关系做如下操作**/
    update _zycheck
      set ybno='9999999999',checklb='3',checklbname='丙类'
      where userid=@userid and (ybno is null or ybno='')
    update _zycheck
      set ybkmcode=kmcode.ybkmcode
      from _zycheck,kmcode
      where kmcode=code and ybno='9999999999' and userid=@userid
  end
  /***********************************************/

  /*更新合作医疗标志*/
  update _zycheck
    set hzylflag=case when checkcode.hzylflag='1' then '允许' else null end
    from _zycheck,checkcode
    where checkno=code and userid=@userid

  declare @t_cfnum int
  execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output


  /**生成医技申请单号**/
  if @yjapplynum is null
  begin
    declare @t_yjapplynum int
    declare @t_groupkeyno numeric(18)
    DECLARE _zycheck_cursor CURSOR FOR
      select groupkeyno
        from _zycheck,kscode
        where fskscode=code and ksattrib=5 and userid=@userid
        group by groupkeyno
    OPEN _zycheck_cursor
    FETCH NEXT FROM _zycheck_cursor into @t_groupkeyno
    WHILE @@FETCH_STATUS = 0
    BEGIN
      execute GetUniqueNo 20,@NewUniqueNo=@t_yjapplynum output

      update _zycheck
        set yjapplynum=@t_yjapplynum,ApplicationFlag=null
        where groupkeyno=@t_groupkeyno and userid=@userid

      FETCH NEXT FROM _zycheck_cursor into @t_groupkeyno
    END
    CLOSE _zycheck_cursor
    DEALLOCATE _zycheck_cursor
  end else
  begin
    declare @t_yzid int
    select @t_yzid=YZID from Patient_ApplicationSheet where APPLYNUM=@yjapplynum
    
    update _ZYCHECK
      set YJApplyNum=@yjapplynum,ApplicationFlag=1,YZID=@t_yzid
      where USERID=@userid
  end

  insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzoper,jzdate,
                 checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,yskscode,
                 ysksname,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,
                 hsflag,hscode,hsname,yzflag,cfnum,jzkscode,groupcode,groupname,
                 groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,zgysname,
                 applicationflag,yjcheckdate,yjcheckoper,SubYZID,YZID,Scale)
    select @zynum,checkno,checkprice,checkcount,checkmoney,@opername,@operdate,checkname,
           kmname,kmcode,@currentkscode,@currentksname,yscode,ysname,yskscode,ysksname,
           checklb,checklbname,unitname,@xjsjnum,fskscode,fsksname,
           hsflag,@hscode,@hsname,@yzflag,@t_cfnum,@operkscode,groupcode,groupname,
           groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,@zgysname,
           ApplicationFlag,case when @YJRunFlag=1 then @operdate else null end,case when @YJRunFlag=1 then @opername else null end,
           @subyzid,YZID,@scale
    from _zycheck
    where userid=@userid
    order by groupkeyno,keyno

  --如果applicatoinflag=1表示是从医技科室录入，但applicationflag还是必须赋null值

  /***医技申请单***/
  declare @t_patientname char(20)
  select @t_patientname=m04 from mbase (nolock) where m01=@zynum
  insert yj_applysheet(ApplyNum,PatientName,PatientKind,PatientNum,patientinnum,ItemCode,ItemName,ItemPrice,ItemCount,ItemMoney,
                       ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,ApplyDate,jzopername,jzdate,yjcheckopername,yjcheckdate)
    select yjapplynum,@t_patientname,2,@zynum,@zynum,checkno,checkname,checkprice,checkcount,checkmoney,
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@Operdate,@operName,@operdate,
           case when @yjrunflag=1 then @opername else null end,
           case when @yjrunflag=1 then @operdate else null end
      from _zycheck
      where userid=@userid and yjapplynum is not null and groupcode is null
    union all
    select yjapplynum,@t_patientname,2,@zynum,@zynum,groupcode,groupname,groupprice,groupcount,sum(checkmoney),
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@Operdate,@operName,@operdate,
           case when @yjrunflag=1 then @opername else null end,
           case when @yjrunflag=1 then @operdate else null end
      from _zycheck
      where userid=@userid and yjapplynum is not null and groupcode is not  null
      group by groupcode,groupname,groupprice,groupcount,yjapplynum,fskscode,fsksname,yscode,ysname,yskscode,ysksname

  update mbase
    set m25=m25+@sumcheckmoney
    where m01=@zynum and @sumcheckmoney is not null
    
  --直接标记审核
  if @yjapplynum is not null
  begin
    update patient_applicationsheet
      set yjcheckdate=getdate(),yjcheckoper=@opername,jzdate=getdate(),jzoper=@opername,CHECKMONEY=@sumcheckmoney
      where zynum=@zynum and applynum=@yjapplynum and yjcheckdate is null

    update patient_applicationcheckcode
      set yjcheckdate=getdate(),yjcheckoper=@opername
      where zynum=@zynum and applynum=@yjapplynum and yjcheckdate is null

    update yj_applysheet
      set yjcheckdate=getdate(),yjcheckopername=@opername
      where PatientInNum=@zynum and applynum=@yjapplynum and yjcheckdate is null

    update yj_applysheethis
      set yjcheckdate=getdate(),yjcheckopername=@opername
      where PatientInNum=@zynum and applynum=@yjapplynum and yjcheckdate is null
  end
    
    
  return 0  
end
GO
