CREATE PROCEDURE [dbo].[ExecChangePrice] 
(@opername char(10),@userid int,@storecode char(3),@storename char(10))
AS
begin
declare @datetemp datetime
select @datetemp=getdate()
/***insert into price table***/
insert price(p02,p03,p04,p05,p06,p07,p08,p11,p12,p13,p14,p15,p16,p17)
  select p01,p02,p03,p04,p05,p06,p07,@opername,@datetemp,p08,@storecode,@storename,yfcode,yfname
    from _price
    where userid=@userid
 
/***insert into mzchangeprice if the price of yfstore is not a same price***/
insert mzchangeprice
  select p01,@datetemp,
    a08,a07,p07_1,p06_1 ,
    a09,a09*(p07_1-a08),a09*(p06_1-a07),
    @opername,'药品调价，文号：'+p03,a10,a11
  from _price,yfstore
  where p01=a01 and userid=@userid and (p07<>a08 or p06<>a07) and a09<>0 and a10=yfcode
/***update the price of yfstore to a new value***/
update yfstore
  set a07=p06_1,a08=p07_1
  from _price,yfstore
  where a01=p01 and a10=yfcode and userid=@userid 
return 0
end
GO
