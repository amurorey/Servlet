CREATE     PROCEDURE [dbo].[ZRBRUnIn]
(@zynum int,@opername char(10))
AS
begin
  if exists(select m01 from mbase where m19 is not null and m01=@zynum)
    return 1  --已出院
  if exists(select * from mbase where m01=@zynum and m25<>0)
    return 2  --费用合计不为0
  if exists(select * from mbase where m01=@zynum and m27<>0)
    return 3  --预交金合计不为0
  if exists(select * from mbase where m01=@zynum and m51 is not null)
    return 4  --科室已接收

  update mbase
    set m56=getdate(),
        m57=@opername
    where m01=@zynum
  return 0
end
GO
