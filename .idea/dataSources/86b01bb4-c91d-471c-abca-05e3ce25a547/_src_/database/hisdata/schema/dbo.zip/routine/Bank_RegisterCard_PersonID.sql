Create       PROCEDURE [dbo].[Bank_RegisterCard_PersonID]
(@patientname varchar(20),@sex varchar(10),@birthday datetime,
 @personid varchar(20),@tel varchar(20),@address varchar(80),@userid_bank varchar(20),@transno_bank varchar(20),
 @registerdate datetime,@patientid_ret varchar(20) output)
AS
begin
  if exists(select personid from patientbase (nolock) where personid=@personid and bindingdate_bank is not null)
    return -1 --患者的信息已绑定


  declare @t_patientid varchar(20)
  set @t_patientid=null
  select @t_patientid=patientid from patientbase (nolock) where personid=@personid and patientname=@patientname and sex=@sex and bindingdate is not null
  
  if @t_patientid is null
    select @t_patientid=patientid from patientbase (nolock) where personid=@personid and patientname=@patientname and sex=@sex


  --若满足以下条件则不生成新的patientid，直接注册
  if exists(select patientid from patientbase (nolock) where patientid=@t_patientid)
  begin
    update patientbase
      set addressofpersonid=@address,
          birthday=@birthday,
          bindingdate_bank=@registerdate,
          userid_bank=@userid_bank,
          TransNo_bank=@transno_bank
    where patientid=@t_patientid

    select @patientid_ret=@t_patientid
  end else   --新增患者ID
  begin
    execute GetUniqueNo 26,@NewUniqueNo=@t_patientid output
    

    insert patientbase(patientid,patientname,pym,sex,birthday,address,
                       tel,personid,opername,operdate,
                       createdate,createoper,bindingdate,bindingopername,
                       bindingdate_bank,userid_bank,transno_bank)
        values(convert(varchar(20),@t_patientid),@patientname,'PYM',@sex,@birthday,@address,
               @tel,@personid,'银医',getdate(),
               @registerdate,'银医',getdate(),'银医',
               @registerdate,@userid_bank,@transno_bank)

    select @patientid_ret=@t_patientid
  end

  return 0  
end
GO
