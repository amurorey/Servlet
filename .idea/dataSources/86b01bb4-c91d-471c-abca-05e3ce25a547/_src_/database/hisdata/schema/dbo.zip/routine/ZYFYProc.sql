CREATE   PROCEDURE [dbo].[ZYFYProc]
(@cfnum int,@opername char(10)='')
AS
begin
  declare @currentdate datetime
  select @currentdate=getdate()
  declare @cfmoney1 numeric(12,2)
  declare @cfmoney2 numeric(12,2)

  declare @t_fyno int
  execute GetUniqueNo 32,@NewUniqueNo=@t_fyno output

  if exists(select cfnum from zycfypk where cfnum=@cfnum) 
  begin
    select @cfmoney1=sum(ypmoney*cfcount) from zycfypk 
      where cfnum=@cfnum and deldate is null

    select @cfmoney2=sum(ypmoney*cfcount) from zycfypk 
      where cfnum=@cfnum and deldate is null and fydate is null

    /*整张处方已被发药*/
    if (@cfmoney2=0) or (@cfmoney2 is null)
      return -1

    update zycfypk
      set fydate=@currentdate,fyopername=@opername,fyno=@t_fyno
    where cfnum=@cfnum and deldate is null and fydate is null
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(ypcount*cfcount) as sumypcount 
      into #cfypcount
      from zycfypk
      where cfnum=@cfnum and deldate is null and fydate is null
      group by yfcode,cfnum,goodsno
    update yfstore
      set a16=a16-sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10

    if @cfmoney1<>@cfmoney2 
      return 1
    else
      return 0      end else
  begin    
    select @cfmoney1=sum(ypmoney*cfcount) from zycfypkhis
      where cfnum=@cfnum and deldate is null

    select @cfmoney2=sum(ypmoney*cfcount) from zycfypkhis
      where cfnum=@cfnum and deldate is null and fydate is null

    /*整张处方已被发药*/
    if (@cfmoney2=0) or (@cfmoney2 is null)
      return -1

    update zycfypkhis
      set fydate=@currentdate,fyopername=@opername,fyno=@t_fyno
    where cfnum=@cfnum and deldate is null and fydate is null
    /***Compute the count of this CF***/
    select yfcode,cfnum,goodsno,sum(ypcount*cfcount) as sumypcount 
      into #cfypcounthis
      from zycfypkhis
      where cfnum=@cfnum and deldate is null and fydate is null
      group by yfcode,cfnum,goodsno
    update yfstore
      set a16=a16-sumypcount      from yfstore,#cfypcounthis
      where #cfypcounthis.goodsno=a01 and #cfypcounthis.yfcode=a10

    if @cfmoney1<>@cfmoney2 
      return 1
    else
      return 0      
  end
end
GO
