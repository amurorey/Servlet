CREATE          PROCEDURE [dbo].[SaveZYInvoiceToBAFpage] 
(@zynum int)
AS
begin
  --老的分类方式
  update ba_fpage
  set fp109=disp2.fp109,
      fp110=disp2.fp110,
      fp111=disp2.fp111,
      FP112=disp2.FP112,
      fp99=disp2.fp99,
      fp100=disp2.fp100,
      fp101=disp2.fp101,
      fp102=disp2.fp102,
      fp103=disp2.fp103,
      fp104=disp2.fp104,
      fp105=disp2.fp105,
      fp106=disp2.fp106,
      fp107=disp2.fp107,
      fp108=disp2.fp108,
      fp126=disp2.fp126,
      fp127=disp2.fp127,
      fp128=disp2.fp128,
      fp113=disp2.fp113
  from ba_fpage,
      (select rtrim(convert(char(20),zynum)) as zynum,
        sum(case when kmcode='01' then kmmoney else 0 end) as fp109, 
        sum(case when kmcode='02' then kmmoney else 0 end) as fp110, 
        sum(case when kmcode='03' then kmmoney else 0 end) as fp111, 
        sum(case when kmcode='F' then kmmoney else 0 end) as fp112,
        sum(case when kmcode='B' then kmmoney else 0 end) as fp99, 
        sum(case when kmcode='D' then kmmoney else 0 end) as fp100, 
        sum(case when kmcode='E' then kmmoney else 0 end) as fp101,
        sum(case when kmcode='X' or kmcode='Y' then kmmoney else 0 end) as fp102,
        sum(case when kmcode='G' then kmmoney else 0 end) as fp103,
        sum(case when kmcode='H' then kmmoney else 0 end) as fp104,
        0 as fp105,
        0 as fp106,
        0 as fp107,
        sum(case when kmcode='K' or kmcode='DJ' or kmcode='EJ' or kmcode='GJ' then kmmoney else 0 end) as fp108,
        sum(case when kmcode='C' then kmmoney  else 0 end) as fp126,
        sum(0) as fp127,
        sum(0) as fp128,
        sum(kmmoney) as fp113
        from
        (select zynum,kmcode,kmname,ypmoney*cfcount as kmmoney
          from zycfypk (nolock)
          where zynum=@zynum and deldate is null
        union all
        select zynum,kmcode,kmname,checkmoney as kmmoney
          from zycheck (nolock)
          where zynum=@zynum and deldate is null
        union all
        select zynum,kmcode,kmname,ypmoney*cfcount as kmmoney
          from zycfypkhis (nolock)
          where zynum=@zynum and deldate is null
        union all
        select zynum,kmcode,kmname,checkmoney as kmmoney
          from zycheckhis (nolock)
          where zynum=@zynum and deldate is null) disp1
        group by zynum) disp2

      where ba_fpage.fp0=convert(varchar(20),disp2.zynum)


  --新分类方式
  delete ba_invoice where zynum=convert(varchar(20),@zynum)

  insert ba_invoice(zynum,totmoney,f1,f2,f3,f4,f5,f6,f7,f8,f9,f9_1,f10,f10_1,f10_2,f11,f12,f13,f13_1,f14,f15,f16,f17,f18,f19,f20,f21,f22,f23)
    select convert(varchar(20),zynum),
           sum(checkmoney) as totmoney,
           sum(case when flag=0 and substring(checkno,1,2)='11' and substring(checkno,1,4) not in('1106','1107','1108') then checkmoney else 0 end) as F1,
           sum(case when flag=0 and substring(checkno,1,2)='12' and substring(checkno,1,4)<>'1201' and checkno<>'120400006D' then checkmoney else 0 end) as F2,
           sum(case when flag=0 and substring(checkno,1,4)='1201' then checkmoney else 0 end) as F3,
           sum(case when flag=0 and (substring(checkno,1,4) in('1106','1107','1108') or substring(checkno,1,2) in('13','14')) then checkmoney else 0 end) as F4,
           sum(case when flag=0 and substring(checkno,1,2)='27' then checkmoney else 0 end) as F5,
           sum(case when flag=0 and substring(checkno,1,2)='25' then checkmoney else 0 end) as F6,
           sum(case when flag=0 and substring(checkno,1,2) in('21','22','23','24') then checkmoney else 0 end) as F7,
           sum(case when flag=0 and substring(checkno,1,2)='31' and kmcode='D' then checkmoney else 0 end) as F8,	
           sum(case when flag=0 and substring(checkno,1,2) in ('31','32','34') and substring(checkno,1,4) <> '3402'and kmcode='E' then checkmoney else 0 end) as F9,
           sum(case when flag=0 and substring(checkno,1,4)='3401' then checkmoney else 0 end) as F9_1,
           sum(case when flag=0 and substring(checkno,1,2)='33' then checkmoney else 0 end) as F10,
           sum(case when flag=0 and substring(checkno,1,4)='3301' then checkmoney else 0 end) as F10_1,
           sum(case when flag=0 and substring(checkno,1,2)='33' and substring(checkno,1,4)<>'3301' then checkmoney else 0 end) as F10_2,
           sum(case when flag=0 and substring(checkno,1,4)='3402' then checkmoney else 0 end) as F11,
           sum(case when flag=0 and substring(checkno,1,2)>='41' and substring(checkno,1,2)<='48' then checkmoney else 0 end) as F12,
           sum(case when kmcode='01' and a48 is null then checkmoney else 0 end) as F13,
           sum(case when a40 is not null and kmcode='01'and a48 is null then checkmoney else 0 end) as f13_1,
           sum(case when kmcode='02' and a48 is null then checkmoney else 0 end) as F14,
           sum(case when kmcode='03' and a48 is null then checkmoney else 0 end) as F15,
           sum(case when checkno='120400006D' then checkmoney else 0 end) as F16,
           sum(case when flag=1 and a48=1 then checkmoney else 0 end) as F17,
           sum(case when flag=1 and a48=2 then checkmoney else 0 end) as F18,
           sum(case when flag=1 and a48=3 then checkmoney else 0 end) as F19,
           sum(case when flag=1 and a48=4 then checkmoney else 0 end) as F20,
           sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='DJ' and a48 is null) or (flag=1 and kmcode='DJ') then checkmoney else 0 end) as F21,
           sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='EJ' and a48 is null) or (flag=1 and kmcode='EJ') then checkmoney else 0 end) as F22,
           sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='GJ' and a48 is null) or (flag=1 and kmcode='GJ') then checkmoney else 0 end) as F23
      from
      (
      select zynum,checkno,checkmoney,kmcode,kmname,0 as flag,null as a40,null as a48 from zycheck (nolock)
        where zynum=@zynum and deldate is null
      union all
      select zynum,goodsno,ypmoney*cfcount,kmcode,kmname,1 as flag,a40,a48 from zycfypk (nolock),goods (nolock)
        where goodsno=a01 and zynum=@zynum and deldate is null
      union all
      select zynum,checkno,checkmoney,kmcode,kmname,0 as flag,null as a40,null as a48 from zycheckhis (nolock)
        where zynum=@zynum and deldate is null
      union all
      select zynum,goodsno,ypmoney*cfcount,kmcode,kmname,1 as flag,a40,a48 from zycfypkhis (nolock),goods (nolock)
        where goodsno=a01 and zynum=@zynum and deldate is null
        ) disp
      group by zynum

  update ba_invoice
    set f24=totmoney-(f1+f2+f3+f4+f5+f6+f7+f8+f9+f10+f11+f12+f13+f14+f15+f16+f17+f18+f19+f20+f21+f22+f23),
        selfmoney=case when m25 is null then 0 else m25 end- case when m50 is null then 0 else m50 end
  from ba_invoice,mbase
    where zynum=convert(varchar(20),m01) and zynum=convert(varchar(20),@zynum)


  --中医病案分类
  if exists(select ZYBAFlag from unitset where ZYBAFlag=1) or exists(select unitname from unitset where unitname='武定县中医院')
  begin
    delete ba_invoice_ZY where zynum=convert(varchar(20),@zynum)

                      
    insert ba_invoice_ZY(ZYNum,TotMoney,F1,F1_1,F1_2,F2,F3,F4,F5,F6,F7,F8,F9,F9_1,F10,F10_1,F10_2,F11,F12,F13,F13_1,F13_2,F13_3,F13_4,F13_5,F13_6,F14,F14_1,F14_2,F15,F15_1,F16,F16_1,F17,F18,F19,F20,F21,F22,F23,F24,F25)
      select convert(varchar(20),zynum),
             sum(checkmoney) as totmoney,
             sum(case when flag=0 and (substring(checkno,1,2)='11' and substring(checkno,1,4) not in('1106','1107','1108')) or checkno='480000006D' then checkmoney else 0 end) as F1,
             sum(case when flag=0 and checkno='480000006D' then checkmoney else 0 end) as F1_1,
             0 as F1_2,
             sum(case when flag=0 and substring(checkno,1,2)='12' and substring(checkno,1,4)<>'1201' and checkno<>'120400006D' then checkmoney else 0 end) as F2,
             sum(case when flag=0 and substring(checkno,1,4)='1201' then checkmoney else 0 end) as F3,
             sum(case when flag=0 and (substring(checkno,1,4) in('1106','1107','1108') or substring(checkno,1,2) in('13','14')) then checkmoney else 0 end) as F4,
             sum(case when flag=0 and substring(checkno,1,2)='27' then checkmoney else 0 end) as F5,
             sum(case when flag=0 and substring(checkno,1,2)='25' then checkmoney else 0 end) as F6,
             sum(case when flag=0 and substring(checkno,1,2) in('21','22','23','24') then checkmoney else 0 end) as F7,
             sum(case when flag=0 and substring(checkno,1,2)='31' and kmcode='D' then checkmoney else 0 end) as F8,	
             sum(case when flag=0 and substring(checkno,1,2) in ('31','32','34') and substring(checkno,1,4) <> '3402'and kmcode='E' then checkmoney else 0 end) as F9,
             sum(case when flag=0 and substring(checkno,1,4)='3401' then checkmoney else 0 end) as F9_1,
             sum(case when flag=0 and substring(checkno,1,2)='33' then checkmoney else 0 end) as F10,
             sum(case when flag=0 and substring(checkno,1,4)='3301' then checkmoney else 0 end) as F10_1,
             sum(case when flag=0 and substring(checkno,1,2)='33' and substring(checkno,1,4)<>'3301' then checkmoney else 0 end) as F10_2,
             sum(case when flag=0 and substring(checkno,1,4)='3402' then checkmoney else 0 end) as F11,
             0 as F12,
             sum(case when flag=0 and substring(checkno,1,2)>='41' and substring(checkno,1,2)<='48' then checkmoney else 0 end) as F13,
             sum(case when flag=0 and substring(checkno,1,2)='41' then checkmoney else 0 end) as F13_1,
             sum(case when flag=0 and substring(checkno,1,2)='42' then checkmoney else 0 end) as F13_2,
             sum(case when flag=0 and (substring(checkno,1,2)='43' or substring(checkno,1,2)='44') then checkmoney else 0 end) as F13_3,
             sum(case when flag=0 and substring(checkno,1,2)='45' then checkmoney else 0 end) as F13_4,
             sum(case when flag=0 and substring(checkno,1,2)='46' then checkmoney else 0 end) as F13_5,
             sum(case when flag=0 and substring(checkno,1,2)='47' then checkmoney else 0 end) as F13_6,
             sum(case when flag=0 and substring(checkno,1,2)='48' and checkno<>'480000006D' then checkmoney else 0 end) as F14,
             sum(case when flag=0 and checkno='480000003' then checkmoney else 0 end) as F14_1,
             0 as F14_2,
             sum(case when kmcode='01' and a48 is null then checkmoney else 0 end) as F15,
             sum(case when a40 is not null and kmcode='01'and a48 is null then checkmoney else 0 end) as f15_1,
             sum(case when kmcode='02' and a48 is null then checkmoney else 0 end) as F16,
             0 as F16_1,
             sum(case when kmcode='03' and a48 is null then checkmoney else 0 end) as F17,
             sum(case when checkno='120400006D' then checkmoney else 0 end) as F18,
             sum(case when flag=1 and a48=1 then checkmoney else 0 end) as F19,
             sum(case when flag=1 and a48=2 then checkmoney else 0 end) as F20,
             sum(case when flag=1 and a48=3 then checkmoney else 0 end) as F21,
             sum(case when flag=1 and a48=4 then checkmoney else 0 end) as F22,
             sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='DJ' and a48 is null) or (flag=1 and kmcode='DJ') then checkmoney else 0 end) as F23,
             sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='EJ' and a48 is null) or (flag=1 and kmcode='EJ') then checkmoney else 0 end) as F24,
             sum(case when (flag=0 and substring(checkno,1,1)='Z' and kmcode='GJ' and a48 is null) or (flag=1 and kmcode='GJ') then checkmoney else 0 end) as F25
        from
        (
        select zynum,checkno,checkmoney,kmcode,kmname,0 as flag,null as a40,null as a48 from zycheck (nolock)
          where zynum=@zynum and deldate is null
        union all
        select zynum,goodsno,ypmoney*cfcount,kmcode,kmname,1 as flag,a40,a48 from zycfypk (nolock),goods (nolock)
          where goodsno=a01 and zynum=@zynum and deldate is null) disp
        group by zynum

    update ba_invoice_zy
      set f26=totmoney-(f1+f2+f3+f4+f5+f6+f7+f8+f9+f10+f11+f12+f13+f14+f15+f16+f17+f18+f19+f20+f21+f22+f23+f24+f25),
          selfmoney=case when m25 is null then 0 else m25 end- case when m50 is null then 0 else m50 end
    from ba_invoice_zy,mbase
      where zynum=convert(varchar(20),m01) and zynum=convert(varchar(20),@zynum)
  end

end
GO
