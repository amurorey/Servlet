CREATE       PROCEDURE [dbo].[Bank_RegisterCard]
(@cardno varchar(30),@patientid varchar(10),@patientname varchar(20),@sex varchar(10),@birthday datetime,
 @personid varchar(20),@tel varchar(20),@address varchar(80),@userid_bank varchar(20),@transno_bank varchar(20),
 @registerdate datetime,@patientid_ret varchar(20) output)
AS
begin
  if exists(select cardno from bank_regcard (nolock) where cardno=@cardno and deldate is null)
  begin
    select @patientid_ret=patientid from bank_regcard where cardno=@cardno and deldate is null
    return -1  --此银行卡已存在
  end

  if (rtrim(@patientid)='') or (@patientid is null)
    select @patientid=patientid from patientbase (nolock)
      where patientname=@patientname and sex=@sex and personid=@personid and personid is not null


  --若满足以下条件则不生成新的patientid，直接注册
  if exists(select patientid from patientbase (nolock) where patientid=@patientid and patientname=@patientname and sex=@sex and personid=@personid)
  begin
    update patientbase
      set addressofpersonid=@address,
          birthday=@birthday,
          bankcardno=@cardno,
          bindingdate_bank=@registerdate,
          userid_bank=@userid_bank,
          TransNo_bank=@transno_bank
    where patientid=@patientid

    select @patientid_ret=@patientid
  end else   --新增患者ID
  begin
    declare @t_patientid int
    execute GetUniqueNo 26,@NewUniqueNo=@t_patientid output
    

    insert patientbase(patientid,patientname,pym,sex,birthday,address,
                       tel,personid,opername,operdate,
                       createdate,createoper,bindingdate,bindingopername,
                       bankcardno,bindingdate_bank,userid_bank,transno_bank)
        values(convert(varchar(20),@t_patientid),@patientname,'PYM',@sex,@birthday,@address,
               @tel,@personid,'自助机注册',getdate(),
               @registerdate,'自助机注册',getdate(),'自助机注册',
               @cardno,@registerdate,@userid_bank,@transno_bank)

    select @patientid_ret=@t_patientid
  end

  insert Bank_RegCard(cardno,patientid,patientname,personid,regdate,userid,transno)
    values(@cardno,@patientid_ret,@patientname,@personid,getdate(),@userid_bank,@transno_bank)

  return 0  
end
GO
