CREATE PROCEDURE [dbo].[UpdateNewKM]  AS
begin
  update zycheck
    set kmcode=code,kmname=name
    from zycheck,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update zycheckhis
    set kmcode=code,kmname=name
    from zycheckhis,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update zyinvoice
    set kmcode=code,kmname=name
    from zyinvoice,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'


  update mzcheck
    set kmcode=code,kmname=name
    from mzcheck,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update mzcheckhis
    set kmcode=code,kmname=name
    from mzcheckhis,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'


  update goods 
    set a22='DJ',a23='检查类材料费'
    where a22<>'01' and a22<>'02' and a22<>'03'


  update zycfypk
    set kmcode=code,kmname=name
    from zycfypk,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update zycfypkhis
    set kmcode=code,kmname=name
    from zycfypkhis,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update mzcfypk
    set kmcode=code,kmname=name
    from mzcfypk,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'

  update mzcfypkhis
    set kmcode=code,kmname=name
    from mzcfypkhis,kmcodeold,kmcode
    where kmcode=oldcode and newcode=code and kmcode<>'01' and kmcode<>'02' and kmcode<>'03'
end
GO
