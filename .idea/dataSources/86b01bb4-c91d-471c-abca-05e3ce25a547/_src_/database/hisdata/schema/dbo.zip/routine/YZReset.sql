/*xmflag:  7:术后医嘱   8:产后医嘱  9:重整医嘱  10：转科后医嘱(在接收转科后处理）*/
CREATE                       PROCEDURE [dbo].[YZReset]
(@zynum int,@zyyzid int,@yzid int,@opercode char(10),@opername char(20),@currentkscode char(10),@currentksname char(20),@xmflag int,@subyzid int=0)
AS
begin
  if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
    return 1  --已取消入院

  if exists(select m01 from mbase (nolock) where m01=@zynum and m53 is not null)
    return 2  --已出室

  declare @t_MaxKeyNo1 numeric(18)
  select @t_MaxKeyNo1=max(keyno) from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid  and yzflag=1 and (xmflag>=7 and xmflag<10)  --不包括专科医嘱
  declare @t_MaxKeyNo2 numeric(18)
  select @t_MaxKeyNo2=max(keyno) from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid  and yzflag=1
  if @t_MaxKeyNo1=@t_MaxKeyNo2 
    return 3  --重整医嘱、术后医嘱、产后医嘱后尚未有新的医嘱，不能再次进行以上操作

  declare @t_currentdate datetime
  declare @t_currentdate2 datetime
  select @t_currentdate=getdate()

  --术后、产后、重整医嘱区分主医嘱和子医嘱，转科后医嘱不区分
  if @xmflag>=7 and @xmflag<=9
  begin  
    update yzsheet
      set yzstopdate=@t_currentdate,
--          yzstophscode=@opercode,
--          yzstophsname=@opername,
          yzstopyscode=@opercode,
          yzstopysname=@opername
      where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzflag=1
        and (not (xmflag>=7 and xmflag<=10)) and case when subyzid is null then 0 else subyzid end=@subyzid
  end else if @xmflag=10
  begin
    update yzsheet
      set yzstopdate=@t_currentdate,
--          yzstophscode=@opercode,
--          yzstophsname=@opername,
          yzstopyscode=@opercode,
          yzstopysname=@opername
      where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzflag=1
        and (not (xmflag>=7 and xmflag<=10))
  end

  declare @t_xmname char(20)
  if @xmflag=7
  begin
    select @t_xmname='术后医嘱'
  end else if @xmflag=8
  begin
    select @t_xmname='产后医嘱'
  end else if @xmflag=9
  begin
    select @t_xmname='重整医嘱'
  end else if @xmflag=10
  begin
    select @t_xmname='转科后医嘱'
  end

  select @t_currentdate2=convert(datetime,convert(char(16),getdate(),120))  --只保留到分
  insert yzsheet(zynum,zyyzid,YZID,yzbegdate,XMNAME,yzcountforday,yzcountforweek,yzflag,xmflag,yzyscode,yzysname,yzyskscode,yzysksname,lykscode,lyksname,subyzid)
      values(@zynum,@zyyzid,@yzid,@t_currentdate2,@t_xmname,1,1,1,@xmflag,@opercode,@opername,@currentkscode,@currentksname,@currentkscode,@currentksname,case when @subyzid=0 then null else @subyzid end)


  --重整医嘱的开嘱时间取原未停止的医嘱的开嘱时间（石林除外，石林取当前时间)
  if @xmflag=9  --重整医嘱必须将尚未停止的医嘱追加到“重整医嘱”后
  begin
    declare @t_unitno varchar(20)
    select @t_unitno=unitno from unitset (nolock)
   
    insert yzsheet(ZYNUM,ZYYZID,YZID,YZFLAG,yzbegdate,XMCODE,XMNAME,KMCODE,KMNAME,XMUNIT,XMPRICE,XMCOUNT,XMMONEY,
                   XMFLAG,YPJL,YPJLUNIT,YZUSEDMETHOD,YZCOUNTFORDAY,YZCOUNTFORWEEK,YPPATH,DSPERMIN,YFCODE,YFNAME,
                   YZYSCODE,YZYSNAME,YZYSKSCODE,YZYSKSNAME,YZCHECKHSCODE,YZCHECKHSNAME,YBLB,YBLBNAME, LYKSCODE,LYKSNAME,
                   CHECKGROUPCODE,CHECKGROUPNAME,CHECKGROUPPRICE,CHECKGROUPCOUNT,CHECKGROUPKEYNO,
                   YJApplyNum,FSKSCode,FSKSName,HZYLFlag,XMDescription,totcount,subyzid,yzcreatedate,yzcreateopername,yzcreatebyhsorys,
                   yzlastrundate,yzrunhscode,YZRUNHSNAME,Note)
    select ZYNUM,ZYYZID,YZID,YZFLAG,case when @t_unitno='431450636' then @t_currentdate2 else yzbegdate end,XMCODE,XMNAME,KMCODE,KMNAME,XMUNIT,XMPRICE,XMCOUNT,XMMONEY,
           XMFLAG,YPJL,YPJLUNIT,YZUSEDMETHOD,YZCOUNTFORDAY,YZCOUNTFORWEEK,YPPATH,DSPERMIN,YFCODE,YFNAME,
           @OperCODE,@OperNAME,@CURRENTKSCODE,@CURRENTKSNAME,YZCHECKHSCODE,YZCHECKHSNAME,YBLB,YBLBNAME, LYKSCODE,LYKSNAME,
           CHECKGROUPCODE,CHECKGROUPNAME,CHECKGROUPPRICE,CHECKGROUPCOUNT,CHECKGROUPKEYNO,
           YJApplyNum,FSKSCode,FSKSName,HZYLFlag,XMDescription,totcount,case when @subyzid=0 then null else @subyzid end,getdate(),@opername,1,
           yzlastrundate,yzrunhscode,yzrunhsname,Note
      from yzsheet (nolock)
        where zynum=@zynum and zyyzid=@zyyzid and yzstopdate=@t_currentdate and yzflag=1 and DelDate is null
          and (not (xmflag>=7 and xmflag<=10)) and case when subyzid is null then 0 else subyzid end=@subyzid
      order by sortid

    --重新生成新的YZID
    declare @t_yzid int
    declare @t_newyzid int
    DECLARE yzsheet_cursor CURSOR FOR
      select yzid
        from yzsheet (nolock)
          where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzflag=1
             and (not (xmflag>=7 and xmflag<=10)) and case when subyzid is null then 0 else subyzid end=@subyzid
        group by yzid


    OPEN yzsheet_cursor
    FETCH NEXT FROM yzsheet_cursor into @t_yzid
    WHILE @@FETCH_STATUS = 0
    BEGIN
      --得到新YZID
      execute GetUniqueNo 15,@NewUniqueNo=@t_newyzid output
      update yzsheet
        set yzid=@t_newyzid
        where @zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and yzid=@t_yzid and yzstopdate is null 
          and case when subyzid is null then 0 else subyzid end=@subyzid

      FETCH NEXT FROM yzsheet_cursor into @t_yzid
    END
    CLOSE yzsheet_cursor
    DEALLOCATE yzsheet_cursor
  end

  return 0
end
GO
