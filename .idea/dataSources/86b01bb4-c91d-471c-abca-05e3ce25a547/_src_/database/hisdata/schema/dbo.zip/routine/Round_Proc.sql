CREATE  PROCEDURE [dbo].[Round_Proc]
(@inputval numeric(12,4),@decval int,@retval numeric(12,4)=0 output)
AS
  select @retval=round(@inputval,@decval)
GO
