CREATE         PROCEDURE [dbo].[Bank_MZReserveCommit]
(@bankcardno varchar(40),@banktranamt varchar(30),@banktranno varchar(30),@bankpno varchar(30),
 @banktrandate varchar(30),@banktrantime varchar(30),@userid varchar(30),
 @transno varchar(50),@autotransno varchar(50),@retstr varchar(100) output,@mznum varchar(10) output,@fpnum varchar(10) output)
AS
begin
  if rtrim(@transno)='' or @transno is null
  begin
    select @retstr='预约流水号为空'
    return -1
  end

  if not exists(select transno from mzreserve (nolock) where transno=@transno)
  begin
    select @retstr='无此预约流水号对应的记录'
     return -1
  end

  if exists(select transno from mzreserve (nolock) where transno=@transno and deldate is not null)
  begin
    select @retstr='此预约流水号对应的记录已被取消预约'
    return -1
  end


  if exists(select transno from mzreserve (nolock) where transno=@transno and commitdate is not null)
  begin
    select @retstr='此预约流水号对应的记录已被取号，不能再次取号'
    return -1
  end

  declare @t_patientname varchar(20)
  declare @t_patientid varchar(10)
  declare @t_groupcode varchar(10)
  declare @t_groupname varchar(50)
  declare @t_groupprice numeric(12,2)
  declare @t_yscode varchar(10)
  declare @t_ysname varchar(20)
  declare @t_kscode varchar(10)
  declare @t_ksname varchar(10)
  select @t_patientname=patientname,@t_patientid=patientid,@t_groupcode=checkgroupcode,
         @t_groupname=checkgroupname,@t_groupprice=checkmoney,
         @t_yscode=yscode,@t_ysname=ysname,@t_kscode=kscode,@t_ksname=ksname
    from mzreserve (nolock)
    where transno=@transno


  declare @t_userid numeric(18)
  execute GetUniqueNo 0,@NewUniqueNo=@t_userid output
  if @@error <> 0 
  begin
    select @retstr='生成UserID时错误'
    return -1
  end

  declare @t_groupkeyno numeric(18)
  execute GetUniqueNo 14,@NewUniqueNo=@t_groupkeyno output
  if @@error <> 0 
  begin
    select @retstr='生成GroupKeyNo时错误'
    return -1
  end

  declare @t_mznum int
  execute GetUniqueNo 22,@NewUniqueNo=@t_mznum output
  if @@error <> 0 
  begin
    select @retstr='生成门诊号时错误'
    return -1
  end

  declare @t_fpnum int
  execute GetUniqueNo 7,@NewUniqueNo=@t_fpnum output
  if @@error <> 0 
  begin
    select @retstr='生成发票号时错误'
    return -1
  end

  declare @t_currentdate datetime
  select @t_currentdate=getdate()

 
  delete _mzcheck where userid=@t_userid

  insert _mzcheck(checkno,checkname,unitname,checkprice,checkcount,checkmoney,yscode,
                  ysname,kmname,kmcode,yskscode,ysksname,userid,procdate,fskscode,fsksname,
                  checklb,checklbname,groupcode,groupname,groupprice,groupcount,groupkeyno)
    select checkcode,checkname,checkcode.unitname,checkprice,checkcount,checkmoney,@t_yscode,
           @t_ysname,checkcode.kmname,checkcode.kmcode,@t_kscode,@t_ksname,@t_userid,@t_currentdate,@t_kscode,@t_ksname,
           checklb,checklbname,@t_groupcode,@t_groupname,@t_groupprice,1,@t_groupkeyno
      from checkgroupsheet (nolock),checkcode (nolock)
      where checkcode=code and groupcode=@t_groupcode
  if @@error <> 0 
  begin
    select @retstr='写入临时表时错误'
    return -1
  end

  declare @t_ret int
  execute @t_ret=SaveMZFP @fpnum=@t_fpnum,
                   @userid=@t_userid,
                   @fpname=@t_patientname,
                   @fpmoney=@t_groupprice,
                   @opername='自助缴费',
                   @retval=@retstr output,
                   @currentdate=@t_currentdate,
                   @oldfpnum=null,
                   @ybflag=4,
                   @ybnum=null,
                   @jfcardid=null,
                   @roundflag=null,
                   @ybareacode=null,
                   @ybareaname=null,
                   @zfmoney1=@t_groupprice,
                   @zfmoney2=0,
                   @roundmoney=null,
                   @mznum=@t_mznum,
                   @yldyname='自费',
                   @fpnum_tmp=null,
                   @yberror=null,
                   @patientid=@t_patientid,
                   @transno=@autotransno
  if @@error <> 0 
  begin
    select @retstr='保存发票时错误'
    return -1
  end


  delete _mzcheck where userid=@t_userid

  if @t_ret=5
  begin
    select @retstr='患者在12小时内同一科室只允许一次挂号'
    return -1
  end


  update mzreserve
    set commitdate=@t_currentdate,commitopername='自助缴费'
    where transno=@transno
  if @@error <> 0 
  begin
    select @retstr='更新mzreserve表时错误'
    return -1
  end

  insert Bank_TransSheet(FPNum,MZNum,BankCardNo,BankTranAmt,BankTranNo,BankPNo,
                         BankTranDate,BankTranTime,AutoTranNo,UserID_Bank,OperDate_His,
                         TransFlag)
    values(@t_FPNum,@t_MZNum,@BankCardNo,@BankTranAmt,@BankTranNo,@BankPNo,
           @BankTranDate,@BankTranTime,@AutoTransNo,@UserID,getdate(),
           3)

  select @retstr='取号成功'
  select @mznum=convert(varchar(10),@t_mznum),@fpnum=convert(varchar(10),@t_fpnum)
  return 0
end
GO
