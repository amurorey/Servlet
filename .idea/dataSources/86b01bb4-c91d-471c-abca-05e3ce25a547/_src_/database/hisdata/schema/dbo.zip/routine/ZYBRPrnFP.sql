/*@allownotprnFP:允许不打印发票，1：允许*/
CREATE PROCEDURE [dbo].[ZYBRPrnFP]
(@p01 int,@p03 char(20),@p04 datetime,@p05 char(10),@fpnum int,@m26 numeric(12,2),@m25 numeric(12,2),@m27 numeric(12,2),@jsflag int = 0,@userid numeric(18),
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null,@allownotPrnFP int=null)
AS
begin
  /*判断是否已打印了发票*/
  if exists(select m01 from mbase (nolock) where m30 is not null and m01=@p01) 
    return 1

  /*判断是否已强制出院*/
  if exists(select m01 from mbase (nolock) where m01=@p01 and m28=1)
    return 2
  declare @totzymoney numeric(12,2),@totyjmoney numeric(12,2)
  select @totzymoney=m25,@totyjmoney=m27 from mbase (nolock) where m01=@p01

  /*判断住院费合计是否修改*/
  if @m25<>@totzymoney or @m27<>@totyjmoney
    return 3

  /*判断是否已出院*/
  if exists(select m01 from mbase (nolock) where m01=@p01 and m19 is null)
    return 4

  /*其它支付金额*/
  declare @otherzfmoney numeric(12,2)
  select @otherzfmoney=sum(zfmoney) from _zyfpotherzf where userid=@userid and zynum=@p01
  select @otherzfmoney=case when @otherzfmoney is not null then @otherzfmoney else 0 end

  /*住院费用合计*/
  declare @moneytemp numeric(12,2)
  select @moneytemp=sum(kmmoney) from nowzykmview where zynum=@p01 and yjfpnum is null
  if (@moneytemp is null) 
  begin
    select @moneytemp=0
  end

  /*重新计算交退款*/
  declare @yjmoneytemp numeric(12,2),@jtmoneytemp numeric(12,2)
  select @yjmoneytemp=case when m27 is not null then m27 else 0 end+case when m50 is not null then m50 else 0 end-case when m33 is not null then m33 else 0 end
    from mbase where m01=@p01
  select @jtmoneytemp=-(@yjmoneytemp+@otherzfmoney-@moneytemp)

  /*交退款不一致*/
  if @m26 <> @jtmoneytemp
    return 5

  declare @t_curnum int
  if @InvoiceNum is not null
  begin
    select @t_curnum=isnull(curnum+1,BegNum) from Invoice_Operator where invoiceoperid=@InvoiceOperID and backflag is null and [TYPE]=1
    if convert(int,@InvoiceNum) <> @t_curnum
      return 6  --保存时发现当前号已被使用
    if @t_curnum is null 
      return 7  --发票号异常
  end
  
  if @allownotPrnFP is null and exists(select InvoiceMangFlag from unitset where InvoiceMangFlag=1 or InvoiceMangFlag=2) and (@InvoiceNum is null or RTRIM(@InvoiceNum)='' or @InvoiceOperID is null or @InvoiceOperID=0)
    return 8 --启用发票管理后发票号不能空且批次号不能空

  
  --将当前发票号写入表中Curnum字段
  if @InvoiceNum is not null
  begin
    update invoice_operator
      set curnum=@t_curnum
      where invoiceoperid=@InvoiceOperID
  end

  update zycfinf
    set yjfpnum=@fpnum,fpdate=@p04
    where zynum=@p01 and yjfpnum is null and deldate is null
  update zycfypk
    set yjfpnum=@fpnum,fpdate=@p04
    where zynum=@p01 and yjfpnum is null and deldate is null
  update zycheck
    set yjfpnum=@fpnum,fpdate=@p04    where zynum=@p01 and yjfpnum is null and deldate is null
  update prepay
    set fpnum=@fpnum,InvoiceNum_FP=@InvoiceNum,InvoiceOperID_FP=@InvoiceOperID
    where p01=@p01 and fpnum is null

  declare @jttemp char(20)
  if @jsflag=0
    select @jttemp='现金'
  else
    select @jttemp='欠费'
  /*现金补退款*/
  insert prepay(p01,p02,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
    values(@p01,'1',@p03,@p04,@p05,'出院交(退)款',@m26,@jttemp,1,@fpnum,@InvoiceNum,@InvoiceOperID)

  /*其它补退款*/
  insert prepay(p01,p02,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
    select @p01,'1',@p03,@p04,@p05,'出院时其它方式支付款',zfmoney,zffs,1,@fpnum,@InvoiceNum,@InvoiceOperID
      from _zyfpotherzf where userid=@userid and zynum=@p01
  select kmcode,kmname,sum(kmmoney) as kmmoney 
    into #zyfpinvoice
    from nowzykmview
    where zynum=@p01 and yjfpnum=@fpnum
    group by kmcode,kmname
  declare @cydatetemp datetime
  select @cydatetemp=m19 from mbase where m01=@p01
  insert zyinvoice(zynum,zyname,kmcode,kmname,kmmoney,fpdate,fpoper,fpnum,outflag,enddate)
    select @p01,@p03,kmcode,kmname,kmmoney,@p04,@p05,@fpnum,1,@cydatetemp
      from #zyfpinvoice

  declare @t_zydays int
  select @t_zydays=DATEDIFF(day,m11,@cydatetemp) from MBASE (nolock) where M01=@p01
  if @t_zydays=0 
    select @t_zydays=1

  insert zyinvoicebase(FPNUM,ZYNUM,FPDATE,ENDDATE,FPOPER,FPMONEY,OUTFLAG,DELDATE,PREMONEY,JTMONEY,JSDATE,JSOPER,DELOPER,JTFLAG,OTHERZFMONEY,YLDYName,InvoiceNum,InvoiceOperID,zydays)
    select @fpnum,@p01,@p04,@cydatetemp,@p05,@moneytemp,case when @jsflag=0 then 1 else 2 end,null,@yjmoneytemp,@jtmoneytemp,null,null,null,@jttemp,@otherzfmoney,m02,case when @allownotPrnFP=1 then '未打印' else @InvoiceNum end/*允许不打印发票时该值为"未打印"*/,@InvoiceOperID,@t_zydays
      from mbase
      where m01=@p01

  update mbase 
    set m30=@p04,m26=@m26,m28=@jsflag,m32=@p05,m33=m33+@moneytemp,m50=case when m50 is not null then m50 else 0 end + @otherzfmoney
  where m01=@p01

  update yj_applysheet
    set fpnum=@fpnum,fpdate=@p04
    where patientinnum=@p01
    
  /*将费用保存到病案首页中*/
  exec SaveZYInvoiceToBAFpage @p01


  return 0
end
GO
