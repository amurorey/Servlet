











CREATE     VIEW dbo.UT_COST_CODE
AS
/*SELECT code AS cost_code, name AS cost_name, price AS cost, NULL AS cost_office
  FROM checkcode(nolock),kscheckcode (nolock)
  WHERE code=checkcode and kscode = '3001' and deldate is null 
        and code not in(select checkcode from applicationcheckcode (nolock) where deldate is null and kscode='3001')
UNION ALL
SELECT groupcode, groupname, groupprice, NULL
  FROM checkgroupcode(nolock),kscheckcode (nolock)
  WHERE groupcode=checkcode and kscode='3001'
union all*/
SELECT checkcode AS cost_code, '*'+checkname AS cost_name, checkprice AS cost, NULL AS cost_office
  FROM applicationcheckcode (nolock) where kscode='3001' and groupcode is null and deldate is null
union all
SELECT groupcode AS code, '*'+groupname AS name, groupprice AS cost, NULL AS cost_office
  FROM applicationcheckcode (nolock) where kscode='3001' and groupcode is not null and deldate is null
  group by groupcode,groupname,groupprice


GO
