--科华后台处理存储过程
--OperName 操作员名
--Flag=1  护士已接收标本（适用于住院）
--Flag=2  检验科确认（适用于门诊及住院）
--Flag=3  报告已出（适用于门诊及住院）
--Flag=4  检验科取消确认（适用于门诊及住院）

--RETURN 返回值
-- -2:非通过检验申请的患者，直接退出，该存储过程不作任何处理
-- -1:数据保存时错误，并取消事务
--  0：正常
--  1：患者已出院,不能再做任何操作
--  2：护士已确认，不能再次确认
--  3：检验科已确认，不能再次确认
CREATE                PROCEDURE [dbo].[KH_LIS_Process]
(@orderno varchar(30),@ord_item_no numeric(8,0),@opername char(20),@flag int)
AS
begin

  declare @t_zynum int  --如果非Null则为住院患者
  declare @t_mznum int  --如果非Null则为门诊患者
  select @t_zynum=null,@t_mznum=null
  select @t_zynum=zynum,@t_mznum=mznum from patient_applicationcheckcode 
    where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no

  declare @t_fskscode varchar(10)
  select @t_fskscode=fskscode from patient_applicationsheet where applynum=convert(numeric(18),rtrim(@orderno))

  if @t_zynum is null and @t_mznum is null
  begin
    select -2
    return -2
  end


  --若为住院患者则患者出院后不能再做任何操作(财务出院或取消入院）
  if exists(select m01 from mbase where m01=@t_zynum and (m19 is not null or m56 is not null))
  begin
    select 1
    return 1
  end

  if @flag=1   --仅适用于住院患者，此操作在LIS护士工作站
  begin
    if exists(select zynum from patient_applicationcheckcode 
      where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no and hscheckdate is not null)
    begin
      select 2
      return 2
    end

    update patient_applicationcheckcode
      set hscheckdate=getdate(),hscheckoper=@opername
      where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no
  end else if @flag=2
  begin
    if exists(select applynum from patient_applicationcheckcode 
                where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no and yjcheckdate is not null)
    begin
      select 3
      return 3
    end

    begin transaction  --开始事务

    update patient_applicationsheet
      set yjcheckdate=getdate(),yjcheckoper=@opername,jzdate=getdate(),jzoper=@opername
      where applynum=convert(numeric(18),rtrim(@orderno)) and jzflag=1

    if @@error <> 0 
    begin
      rollback
      return -1
    end

    update patient_applicationcheckcode
      set yjcheckdate=getdate(),yjcheckoper=@opername
      where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no
    if @@error <> 0 
    begin
      rollback
      return -1
    end

    update yj_applysheet
      set yjcheckdate=getdate(),yjcheckopername=@opername
      where applynum=convert(numeric(18),rtrim(@orderno))

    if @@error <> 0 
    begin
      rollback
      return -1
    end
   
    --先将数据复制到临时表中
    declare @t_userid int
    execute GetUserID @NewUserID=@t_UserID output
    if @@error <> 0 
    begin
      rollback
      return -1
    end

    declare @t_zgysname char(20)
    select @t_zgysname=m35 from mbase where m01=@t_zynum

    insert _zycheck(checkno,checkprice,checkcount,checkmoney,
                    checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                    yskscode,ysksname,checklb,checklbname,unitname,fskscode,
                    fsksname,hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,
                    groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,yjapplynum,procdate,userid)
      select checkno,checkprice,checkcount,patient_applicationcheckcode.checkmoney,
             checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
             yskscode,ysksname,checklb,checklbname,unitname,patient_applicationcheckcode.fskscode,
             patient_applicationcheckcode.fsksname,null,null,null,yzid,null,2,
             groupcode,groupname,groupprice,groupcount,newgroupkeyno,ybno,ybkmcode,patient_applicationsheet.applynum,getdate(),@t_userid
      from patient_applicationcheckcode,patient_applicationsheet
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and 
            patient_applicationcheckcode.applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no and jzflag=1/*必须满足医技科室确认后记账的记录*/
    if @@error <> 0 
    begin
      rollback
      select -1
      return -1

    end

    --更新合作医疗标志
    update _zycheck
      set hzylflag=case when checkcode.hzylflag='1' then '允许' else null end,
          ybno=ybcheckcode,checklb=checkcode.checklb,checklbname=checkcode.checklbname
      from _zycheck,checkcode
      where checkno=code and userid=@t_userid
    if @@error <> 0 
    begin
      rollback
      select -1
      return -1
    end

    --------如果为住院患者-------
    if @t_zynum is not null 
    begin
      /***Get CFNUM***/
      declare @t_checkcfnum int
      execute GetUniqueNo 6,@NewUniqueNo=@t_checkcfnum output
      
      declare @t_subyzid int
      select @t_subyzid=subyzid from Patient_ApplicationSheet where applynum=convert(numeric(18),rtrim(@orderno))

      insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzoper,jzdate,
                     checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                     yskscode,ysksname,checklb,checklbname,unitname,xjsjnum,fskscode,
                     fsksname,hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,jzkscode,
                     groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,zgysname,subyzid)
        select @t_zynum,checkno,checkprice,checkcount,checkmoney,@opername,getdate(),
               checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
               yskscode,ysksname,checklb,checklbname,unitname,null,fskscode,
               fsksname,hsflag,null,null,yzid,yzusedmethod,2,@t_checkcfnum,fskscode,
               groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,@t_zgysname,@t_subyzid
        from _zycheck
        where checkprice is not null and userid=@t_userid
        order by groupkeyno
      if @@error <> 0 
      begin
        rollback
        select -1
        return -1
      end
    end
    ----------------------------------------

    declare @t_sumcheckmoney numeric(12,2)
    select @t_sumcheckmoney=sum(case when checkmoney is null then 0 else checkmoney end) from _zycheck
      where checkprice is not null and userid=@t_userid

    update mbase
      set m25=m25+case when @t_sumcheckmoney is null then 0 else @t_sumcheckmoney end
      where m01=@t_zynum

    if @@error <> 0 
    begin
      rollback
      select -1
      return -1
    end

    --删除临时表中数据
    delete _zycheck where userid=@t_userid
    if @@error <> 0 
    begin
      rollback
      select -1
      return -1
    end

    commit transaction  --提交事务

  end else if @flag=3
  begin
    update patient_applicationcheckcode
      set ReportOver=1
      where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no
  end else if @flag=4
  begin
    begin transaction  --开始事务

    update patient_applicationcheckcode
      set yjcheckdate=null,yjcheckoper=null
      where applynum=convert(numeric(18),rtrim(@orderno)) and newgroupkeyno=@ord_item_no

    --如果为住院患者
    if @t_zynum is not null 
    begin
      declare @t_keyno int
      select @t_keyno=keyno from zycheck where groupkeyno=@ord_item_no
      exec TFZYCheck @t_zynum,@t_keyno,@ord_item_no,@opername,@t_fskscode,1
    end

    commit transaction  --提交事务
  end
  select 0
  return 0
end
GO
