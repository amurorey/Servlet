CREATE PROCEDURE [dbo].[UpdateZYCFYPK] AS
begin
update zycfypk
  set yzflag=case when zycfinf.cfflag=3 then 1 else 2 end,
      yfname=zycfinf.yfname,
      operksname=zycfinf.operksname,
      operkscode=zycfinf.operkscode,
      fyopername=zycfinf.fyopername
  from zycfypk,zycfinf
  where zycfypk.cfnum=zycfinf.cfnum

update zycfypkhis
  set yzflag=case when zycfinfhis.cfflag=3 then 1 else 2 end,
      yfname=zycfinfhis.yfname,
      operksname=zycfinfhis.operksname,
      operkscode=zycfinfhis.operkscode,
      fyopername=zycfinfhis.fyopername
  from zycfypkhis,zycfinfhis
  where zycfypkhis.cfnum=zycfinfhis.cfnum
end
GO
