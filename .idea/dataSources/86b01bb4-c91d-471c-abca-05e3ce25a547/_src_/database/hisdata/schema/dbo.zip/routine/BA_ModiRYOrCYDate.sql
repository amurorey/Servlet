--修改医疗入院及出院时间（入科或出科时间）
--@flag=1 修改入院时间
--@flag=2 修改出院时间
CREATE          PROCEDURE [dbo].[BA_ModiRYOrCYDate] 
(@zynum int,@newdate datetime,@flag int)
AS
begin
  declare @fp121 char(20)  --病案室审核人
  declare @fp131 char(20)  --审核医师

  declare @m11 datetime  --财务入院日期
  declare @m19 datetime  --财务出院日期
  declare @minfydate datetime  --初次费用时间
  declare @maxfydate datetime  --末次费用时间

  select @minfydate=min(minjzdate),@maxfydate=max(maxjzdate) from
  (select goodsno,min(jzdate) as minjzdate,max(jzdate) as maxjzdate from zycfypk (nolock) where zynum=@zynum and deldate is null
    group by goodsno
    having sum(ypmoney*cfcount)>0
  union all
  select checkno,min(jzdate) as minjzdate,max(jzdate) as maxjzdate from zycheck (nolock) where zynum=@zynum and deldate is null
    group by checkno
    having sum(checkmoney)>0) disp

  select @m11=m11,@m19=m19 from mbase (nolock) where m01=@zynum

  if @flag=1
  begin
    declare @oldrydate datetime
    declare @rykscode char(10)
    declare @ryksname char(20)
    select @oldrydate=fp25,@rykscode=fp23,@ryksname=fp23_name,@fp121=fp121,@fp131=fp131 from ba_fpage where fp0=rtrim(convert(char(20),@zynum))


    if @oldrydate is null
      return 101  --尚未入院（入科）

    if @fp131 is not null
      return 102  --首页已被医师审核

    if @fp121 is not null
      return 103  --首页已被病案室审核

    if @newdate<@m11
      return 104  --入科时间小于财务入院时间

    if @minfydate is not null and @newdate>@minfydate
      return 105  --入科时间大于首次记账日期

    if @newdate>getdate()
      return 106  --入科时间大于当前时间
    

    exec ba_processbqgzrb @rykscode,@ryksname,@oldrydate,1,-1,0    --在病区工作日报中原入院日期中入院人数减1
    exec ba_processbqgzrb @rykscode,@ryksname,@newdate,1,1,0                --在病区工作日报当前日期中入院人数加1

    update ba_fpage
      set fp25=@newdate
      where fp0=rtrim(convert(char(20),@zynum)) and fp25 is not null
    
    update ba_fpage
      set fp33=case when datediff(day,@newdate,fp31)<1 then 1 else datediff(day,@newdate,fp31) end
      where fp0= rtrim(convert(char(20),@zynum)) and fp25 is not null and fp31 is not null

    update mbase
      set m51=@newdate
    where m01=@zynum and m51 is not null
  end else
  begin
    declare @fp25 datetime
    declare @oldcydate datetime
    declare @cykscode char(10)
    declare @cyksname char(20)
    declare @swflag int
    select @fp25=fp25,@oldcydate=fp31,@cykscode=fp29,@cyksname=fp29_name,@fp121=fp121,@fp131=fp131,
           @swflag=case when fp42='4' then 1 else 0 end
      from ba_fpage where fp0=rtrim(convert(char(20),@zynum))

    if @oldcydate is null
      return 201  --尚未出院（出室）

    if @fp131 is not null
      return 202  --首页已被医师审核

    if @fp121 is not null
      return 203  --首页已被病案室审核

/*    if @m19 is not null and @newdate>@m19
      return 204  --出科时间大于财务出院日期*/

    if (convert(datetime,convert(char(10),@newdate,101))  /*仅保留年、月、日*/ > @m19) and @m19 is not null
      return 204

    if @newdate>getdate()
      return 205  --出科时间大于当前时间

/*    if @newdate<@maxfydate
      return 206  --出科时间小于最末记账时间*/

    if @newdate<@fp25
      return 207

    update ba_fpage
      set fp31=@newdate,fp33=case when datediff(day,fp25,@newdate)<1 then 1 else datediff(day,fp25,@newdate) end
      where fp0=rtrim(convert(char(20),@zynum)) and fp31 is not null

    update mbase
      set m53=@newdate
      where m01=@zynum and m53 is not null

    exec ba_processbqgzrb @cykscode,@cyksname,@oldcydate,2,-1,@swflag    --在病区工作日报中原出院日期中出院人数减1
    exec ba_processbqgzrb @cykscode,@cyksname,@newdate,2,1,@swflag       --在病区工作日报当前日期中出院人数加1
  end

end
GO
