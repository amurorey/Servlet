








CREATE  VIEW dbo.UT_DOCTOR_NURSE
AS
SELECT CODE AS code, NAME AS name, KSNAME AS office, KSNAME AS ward_code, 
      CASE WHEN kscode='3001' then '1'
           when kscode<>'3001' and yhflag =1 THEN '3' 
           WHEN kscode<>'3001' and (yhflag = 2 OR yhflag = 3 OR yhflag = 5) THEN '2' 
           else '非医疗' END AS code_flag
FROM dbo.YSCODE WITH (nolock) where yhflag in(1,2,3,5)


GO
