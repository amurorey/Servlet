CREATE PROCEDURE [dbo].[ZYSheetFYProc]
(@yfcode char(2),@userid numeric(18,0),@opername char(10)='')
AS
begin
  declare @currentdate datetime
  select @currentdate=getdate()
  if not exists(select cfnum from _zyfysheet where userid=@userid)
    return 1

  update zycfinf
    set fydate=@currentdate,fyopername=@opername
    from zycfinf,_zyfysheet
    where zycfinf.cfnum=_zyfysheet.cfnum and _zyfysheet.userid=@userid 
          and zycfinf.fydate is null and deldate is null and zycfinf.yfcode=@yfcode
  
  /***Compute the count of this sheet***/
  select yfcode,goodsno,sum(ypcount*cfcount) as sumypcount 
    into #cfypcount
    from zycfypk
    where zycfypk.cfnum in(select cfnum from _zyfysheet where userid=@userid)
          and fydate is null and deldate is null and yfcode=@yfcode
    group by yfcode,goodsno
  update yfstore
    set a16=a16-sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10

  update zycfypk
    set fydate=@currentdate
    from zycfypk
    where zycfypk.cfnum in(select cfnum from _zyfysheet where userid=@userid)
          and fydate is null and deldate is null and yfcode=@yfcode

  delete _zyfysheet where userid=@userid
  return 0
end
GO
