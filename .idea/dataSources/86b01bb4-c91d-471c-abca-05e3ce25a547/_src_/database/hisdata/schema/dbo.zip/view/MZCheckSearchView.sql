


CREATE view MZCheckSearchView
as
select fpnum,'O'+convert(char(20),keyno) as keyno,checkno,checkname,checkprice,fpdate
  from mzcheck,checkcode (nolock)
  WHERE checkno=code and standflag=1
union all
select fpnum,'I'+convert(char(20),keyno),checkno,checkname,checkprice,fpdate
  from mzcheckhis,checkcode (nolock)
  WHERE checkno=code and standflag=1


GO
