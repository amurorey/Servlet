CREATE  PROCEDURE [dbo].[DispZYBRSheet]
(@zynum int,@begdate datetime,@enddate datetime,@groupflag int,@KSTypeFlag int=0,@SubYZIDFlag varchar(2)='0') with recompile
AS
begin
  declare @t_sql varchar(4096)

  declare @t_database1 varchar(256)
  declare @t_database2 varchar(256)
  if @groupflag=0
  begin
    if exists(select zynum from ZYCHECK (nolock) where ZYNUM=@zynum
              union all
              select zynum from ZYCFYPK (nolock) where ZYNUM=@zynum)
    begin
      select @t_database1=' zycfypk a (nolock),mbase (nolock),goods (nolock)'
      select @t_database2='zycheck a (nolock),mbase (nolock),checkcode (nolock)'
    end else
    begin
      select @t_database1=' zycfypkhis a (nolock),mbase (nolock),goods (nolock)'
      select @t_database2='zycheckhis a (nolock),mbase (nolock),checkcode (nolock)'
    end
  
    select @t_sql=
      ' select case when not(kmcode=''DJ'' or kmcode=''EJ'' or kmcode=''GJ'') then 0 else 2 end as flag,' +
      '       m01,m04,m11,m13,m16,m17,m18,jzdate,goodsno as xmcode,' +
      '       goodsname as xmname,a03 as jx,unitname,cfcount*ypcount*1.0 as quantity,'+
      '       ypprice as price,ypmoney*cfcount as xmmoney,yplbname as xmlbname,'+
      '       yplb as xmlbcode,ysksname as fsksname,null as maxprice,jzoper,'+
      '       null as groupcode,null as groupname,null as groupprice,null as groupcount,null as groupkeyno,a32 as hzylflag,a33 as hzylpercent,kmname,a08 as producer'+
      '  from ' +@t_database1+
      '  where zynum=m01 and goodsno=a01 and'+
      '        zynum='+convert(varchar(20),@zynum)+' and jzdate>='''+convert(varchar(20),@begdate,101)+''' and jzdate<'''+convert(varchar(20),@enddate,101)+''' and deldate is null'+
      ' union all '+
      ' select case when not(a.kmcode=''DJ'' or a.kmcode=''EJ'' or a.kmcode=''GJ'') then 1 else 3 end as flag,'+
      '       m01,m04,m11,m13,m16,m17,m18,jzdate,checkno,'+
      '       checkname,null,a.unitname,checkcount,'+
      '       checkprice,checkmoney,'+
      '       case when substring(checkno,1,4)=''1109'' then ''定额'' else a.checklbname end,'+
      '       case when substring(checkno,1,4)=''1109'' then ''9'' else a.checklb end,'+
      '       fsksname,maxprice,jzoper,'+
      '       groupcode,groupname,groupprice,groupcount,groupkeyno,checkcode.hzylflag,checkcode.hzylpercent,a.kmname,null as producer'+
      '  from '+@t_database2+
      '  where zynum=m01 and checkno=code and'+
      '        zynum='+convert(varchar(20),@zynum)+' and jzdate>='''+convert(varchar(20),@begdate,101)+''' and jzdate<'''+convert(varchar(20),@enddate,101)+''' and a.deldate is null'+
      ' order by jzdate,groupkeyno'
  end else
  begin   
    declare @t_ksstr1 varchar(256)
    declare @t_ksstr2 varchar(256)
    if @KSTypeFlag=0
    begin 
      select @t_ksstr1='lykscode,lyksname'
      select @t_ksstr2='lykscode,lyksname'
    end else if @KSTypeFlag=1
    begin
      select @t_ksstr1='yskscode as lykscode,ysksname as lyksname'
      select @t_ksstr2='yskscode as lykscode,ysksname as lyksname'
    end else
    begin
      select @t_ksstr1='operkscode as lykscode,operksname as lyksname'
      select @t_ksstr2='fskscode as lykscode,fsksname as lyksname'
    end
    
    declare @t_SubCase varchar(256)
    select @t_SubCase = ''
    if @SubYZIDFlag <> '%'
      select @t_SubCase = ' and case when SubYZID IS NULL or SubYZID=0 then 0 else 1 end='+@SubYZIDFlag
    
    if exists(select zynum from ZYCHECK (nolock) where ZYNUM=@zynum
              union all
              select zynum from ZYCFYPK (nolock) where ZYNUM=@zynum)
    begin
      select @t_database1=' zycfypk a (nolock),goods b (nolock)'
      select @t_database2='zycheck a (nolock),checkcode b (nolock)'
    end else
    begin
      select @t_database1=' zycfypkhis a (nolock),goods b (nolock)'
      select @t_database2='zycheckhis a (nolock),checkcode b (nolock)'
    end
    select @t_sql=
          'select flag,lyksname,hzylflag,hzylpercent,xmlbcode,xmlbname,xmcode,xmname,jx,unitname,price,maxprice,sum(quantity) as quantity, sum(xmmoney) as xmmoney,kmname,producer'+
          '  from '+
          ' (select zynum,'+@t_ksstr1+',case when not(a.kmcode=''DJ'' or a.kmcode=''EJ'' or a.kmcode=''GJ'') then 0 else 2 end as flag,'+
          '        jzdate,goodsno as xmcode,goodsname as xmname,a03 as jx,unitname,cfcount*ypcount*1.0 as quantity,ypprice as price,ypmoney*cfcount as xmmoney,yplbname as xmlbname,yplb as xmlbcode,null as maxprice,'+
          '        case when a32=''1'' then ''允许'' else '''' end as hzylflag,a33 as hzylpercent,kmname,a08 as producer'+
          '   from '+@t_database1+
          '   where goodsno=a01 and'+
          '         zynum='+convert(varchar(20),@zynum)+' and jzdate>='''+convert(varchar(20),@begdate,101)+''' and jzdate<'''+convert(varchar(20),@enddate,101)+''' and a.deldate is null'+
          @t_SubCase+
          ' union all'+
          ' select zynum,'+@t_ksstr2+',case when not(a.kmcode=''DJ'' or a.kmcode=''EJ'' or a.kmcode=''GJ'') then 1 else 3 end as flag,'+
          '        jzdate,checkno,checkname,'''',a.unitname,checkcount,checkprice,checkmoney,'+
          '        case when substring(checkno,1,4)=''1109'' then ''定额'' else a.checklbname end,'+
          '        case when substring(checkno,1,4)=''1109'' then ''9'' else a.checklb end,'+
          '        maxprice,'+
          '        case when b.hzylflag=''1'' then ''允许'' else '''' end,b.hzylpercent,a.kmname,null as producer'+
          '   from '+@t_database2+
          '   where checkno=code and'+
          '         zynum='+convert(varchar(20),@zynum)+' and jzdate>='''+convert(varchar(20),@begdate,101)+''' and jzdate<'''+convert(varchar(20),@enddate,101)+''' and a.deldate is null'+
          @t_SubCase+') disp'+
          '      group by lykscode,flag,lyksname,hzylflag,hzylpercent,xmlbcode,xmlbname,xmcode,xmname,jx,unitname,price,maxprice,kmname,producer'+
          '      order by lykscode,flag,xmlbcode,xmlbname,xmcode,xmname,jx,unitname,price'
  end
  exec(@t_sql)
end
GO
