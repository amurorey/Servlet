/*yzsheet表中YZFlag的描述
YZFlag=1  长期医嘱
YZFlag=2  临时医嘱
YZFlag=2 and xmflag=6  临时处方（其中西药处方CFCount=null 草药处方CFCount非null)


YZSheet表中XMFLAG的描述
XMFlag=1  西药医嘱
XMFlag=2  西药组医嘱
XMFlag=3  中成药医嘱（指向中药房，非草药处方）
XMFlag=4  诊疗医嘱
XMFlag=5  非记账医嘱
XMFlag=6  临时处方（包括西药处方及草药处方）

xmflag=7  术后医嘱
XMFlag=8  产后医嘱
XMFlag=9  重整医嘱  
XMFlag=10 转科后医嘱(在接收转科后处理）

XMFlag=11 检查申请
XMFlag=12 会诊申请
*/

CREATE PROCEDURE [dbo].[AddZYYZ]
(@zynum int,@zyyzid int,@userid numeric,@opercode char(4),@opername char(10),
 @retval varchar(1024)='' output,@operkscode char(4),@operksname char(20),
 @qfsetflag int,@yzflag int,@xmflag int=null,@subyzid int=0,@nowdate datetime)
AS
begin
  /*判断在同一药房、同一医师的为同一处方*/
  declare @t_yfcode char(2)
  declare @t_yscode char(4)
  declare @t_cfnum int
  DECLARE yfcodegroup_cursor CURSOR FOR
    SELECT yfcode,yscode FROM _ZYCFYPK_YZ (nolock) where userid=@userid and YZFlag<>4 group by yfcode,yscode  --临时处方处方号不需要重新赋值
  OPEN yfcodegroup_cursor
  FETCH NEXT FROM yfcodegroup_cursor into @t_yfcode,@t_yscode
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output

    update _ZYCFYPK_YZ
      set cfnum=@t_cfnum      
        where yfcode=@t_yfcode and yscode=@t_yscode and YZFlag <> 4 and userid=@userid  --临时处方处方号不需要重新赋值

    FETCH NEXT FROM yfcodegroup_cursor into @t_yfcode,@t_yscode
  END
  CLOSE yfcodegroup_cursor
  DEALLOCATE yfcodegroup_cursor
  /***********************************************************************/ 



  /*合作医疗*/
  update _ZYCFYPK_YZ 
    set hzylflag=case when a32='1' then '允许' else null end 
    from _ZYCFYPK_YZ,goods
    where goodsno=a01 and userid=@userid

  update _ZYCFYPK_YZ
    set yskscode=kscode,ysksname=ksname
    from _ZYCFYPK_YZ,yscode
    where yscode=code and userid=@userid

  if exists(select YB_HOSPNO from unitset (nolock) where YB_HOSPNO is not null)
  begin
    /*得到医保对应的编码（如果有）*/
    update _ZYCFYPK_YZ
      set ybno=a30
      from _ZYCFYPK_YZ,goods
      where goodsno=a01 and userid=@userid

    /*得到医保科目*/
    update _ZYCFYPK_YZ
      set ybkmcode=yb_goods.kmcode,
          yplb=case when yblb='1' or yblb='2' then yblb else '0' end,
          yplbname=case when yblb='1' then '甲类' when yblb='2' then '乙类' else '非甲非乙' end
      from _ZYCFYPK_YZ,yb_goods
      where _ZYCFYPK_YZ.ybno=yb_goods.goodsno and userid=@userid and yb_goods.flag=0

    /*将没有对应的医保编码设置为十个9*/
    update _ZYCFYPK_YZ
      set ybno='9999999999',yplb='0',yplbname='非甲非乙'
      where userid=@userid and (ybno is null or ybno='')

    /*将没有对应关系的编码的科目设为原科目*/
    update _ZYCFYPK_YZ
      set ybkmcode=kmcode.ybkmcode
      from _ZYCFYPK_YZ,kmcode (nolock)
      where kmcode=code and userid=@userid and ybno='9999999999'
  end
  /********************************************/

  /***重新对Groupkeyno赋值***/
  update _ZYCHECK_YZ
    set groupkeyno=-keyno
    where groupkeyno is null and userid=@userid

  declare @t_oldgroupkeyno numeric(18,0)
  declare @t_ksattrib int

  declare @t_newgroupkeyno numeric(18,0)
  declare @t_newyjapplynum numeric(18,0)
  declare @t_applicationflag int
  DECLARE checkgroup_cursor CURSOR FOR
    SELECT groupkeyno,ksattrib,applicationflag FROM _ZYCHECK_YZ (nolock) left join kscode (nolock) on fskscode=code 
      where userid=@userid
      group by groupkeyno,ksattrib,applicationflag
  OPEN checkgroup_cursor
  FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_ksattrib,@t_applicationflag
  WHILE @@FETCH_STATUS = 0
  BEGIN
    /*如果是医技科室则生成YJApplyNum,如果是电子申请单则无须更新*/
    if (@t_ksattrib=5) and (@t_applicationflag is null)
    begin
      execute GetUniqueNo 20,@NewUniqueNo=@t_NewYJApplyNum output
      update _ZYCHECK_YZ
        set yjapplynum=@t_NewYJApplyNum
        where groupkeyno=@t_oldgroupkeyno and applicationflag is null
    end


    execute GetUniqueNo 14,@NewUniqueNo=@t_newgroupkeyno output

    update _ZYCHECK_YZ
      set groupkeyno=@t_newgroupkeyno
      where groupkeyno=@t_oldgroupkeyno and userid=@userid

    FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_ksattrib,@t_applicationflag
  END
  CLOSE checkgroup_cursor
  DEALLOCATE checkgroup_cursor

  /*********************重新更新医保属性************************/
  if exists(select YB_HOSPNO from unitset (nolock) where YB_HOSPNO is not null)
  begin
    /**更新_ZYCHECK_YZ对应的医保代码（如果有）**/
    update _ZYCHECK_YZ
      set ybno=ybcheckcode
      from _ZYCHECK_YZ,checkcode
      where checkno=code and userid=@userid

    /**更新_ZYCHECK_YZ对应的医保科目**/
    update _ZYCHECK_YZ
      set ybkmcode=yb_checkcode.kmcode,
          checklb=case when yblb='1' or yblb='2' or yblb='3' or yblb='4' then yblb else '3' end,
          checklbname=case
                        when yblb='1' then '甲类'
                        when yblb='2' then '乙类'
                        when yblb='3' then '丙类'
                        when yblb='4' then '特检特治'
                        else '丙类'
                      end
      from _ZYCHECK_YZ,yb_checkcode
      where _ZYCHECK_YZ.ybno=yb_checkcode.checkno and userid=@userid and yb_checkcode.flag=0

    /**如果没有医保对应关系做如下操作**/
    update _ZYCHECK_YZ
      set ybno='9999999999',checklb='3',checklbname='丙类'
      where userid=@userid and (ybno is null or ybno='')
    update _ZYCHECK_YZ
      set ybkmcode=kmcode.ybkmcode
      from _ZYCHECK_YZ,kmcode
      where kmcode=code and ybno='9999999999' and userid=@userid
  end
  /***********************************************/

  /*更新合作医疗标志*/
  update _ZYCHECK_YZ
    set hzylflag=case when checkcode.hzylflag='1' then '允许' else null end
    from _ZYCHECK_YZ,checkcode
    where checkno=code and userid=@userid




  /*************************合法性判断***************************/
  /***判断是否有需要执行的医嘱***/
  if not exists(select yzid from _ZYCFYPK_YZ (nolock) where userid=@userid
                union all
                select yzid from _ZYCHECK_YZ (nolock) where userid=@userid
                union all
                select yzid from yzsheet 
                  where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzflag=@yzflag
                     and deldate is null and ((yzstopdate is not null and yzstophscode is null) or (yzlastrundate is null and notjzflag is not null)))
                     
    return -2



  /***判断是否有足够库存量***/
  SELECT YFCODE, YFNAME, USERID, GOODSNAME, GOODSNO, 
        SUM(YPCOUNT * CFCOUNT) AS sumypcount
  into #zycfypgroupview
  FROM _ZYCFYPK_YZ
  where userid=@userid
  GROUP BY YFCODE, YFNAME, USERID, GOODSNO, GOODSNAME

  if exists (select goodsno from #zycfypgroupview,yfstore
               where #zycfypgroupview.goodsno=yfstore.a01
               and #zycfypgroupview.yfcode=yfstore.a10
               and yfstore.a09<(#zycfypgroupview.sumypcount))
  begin
    declare @t_disptext char(100)
    DECLARE checkyfstore_cursor CURSOR FOR
      select rtrim(yfstore.a11)+'"'+rtrim(goodsname)+'"的库存为'+
             rtrim(convert(char(10),yfstore.a09))+'已不足' as disptext
        from #zycfypgroupview,yfstore
         where #zycfypgroupview.goodsno=yfstore.a01
               and #zycfypgroupview.yfcode=yfstore.a10
               and yfstore.a09<(#zycfypgroupview.sumypcount)
    OPEN checkyfstore_cursor
    FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+rtrim(@t_disptext)+char(13)

      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    END
    CLOSE checkyfstore_cursor
    DEALLOCATE checkyfstore_cursor
    delete _ZYCFYPK_YZ where userid=@userid
    delete _ZYCHECK_YZ where userid=@userid
    return 1
  end


  /***有无库存判断***/
  if exists (select goodsno from #zycfypgroupview where userid=@userid and
             goodsno not in(select a01 from yfstore,#zycfypgroupview (nolock)
                              where goodsno=a01 and yfcode=a10))
  begin
    declare @t_disptext2 char(100)
    DECLARE checkyfstore2_cursor CURSOR FOR
      select '"'+rtrim(a07)+'"在'+rtrim(yfname)+'药房没有库存'
        from #zycfypgroupview,goods
        where goodsno=a01 and goodsno not in(select a01 from yfstore,#zycfypgroupview (nolock) where goodsno=a01 and yfcode=a10)

    OPEN checkyfstore2_cursor
    FETCH NEXT FROM checkyfstore2_cursor into @t_disptext2
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext2+char(13)


      FETCH NEXT FROM checkyfstore2_cursor into @t_disptext2
    END
    CLOSE checkyfstore2_cursor
    DEALLOCATE checkyfstore2_cursor

    delete _ZYCFYPK_YZ where userid=@userid
    delete _ZYCHECK_YZ where userid=@userid
    return 1
  end



  declare @currentkscode char(4),@currentksname char(20),@qfmoney float
  /***判断是否出院***/
  if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is null)
  begin
    select @currentkscode=m16,@currentksname=m17,@qfmoney=m25-m27
      from mbase (nolock) where m01=@zynum
  end else
  begin
    delete _ZYCFYPK_YZ where userid=@userid
    delete _ZYCHECK_YZ where userid=@userid
    return 2
  end

  declare @sumcfmoney numeric(12,2)  
  declare @sumcheckmoney numeric(12,2)  
  declare @summoney numeric(12,2)  
  select @sumcfmoney=0,@sumcheckmoney=0,@summoney=0  
  select @sumcfmoney=sum(ypmoney*cfcount) from _ZYCFYPK_YZ (nolock) where userid=@userid
  select @sumcheckmoney=sum(checkmoney) from _ZYCHECK_YZ (nolock) where userid=@userid 
  select @summoney=case when @sumcfmoney is null then 0 else @sumcfmoney end +
                   case when @sumcheckmoney is null then 0 else @sumcheckmoney end

  if @qfsetflag=0 and @qfmoney>0 and @summoney>0  /*禁止欠费输入*/
  begin
    delete _ZYCFYPK_YZ where userid=@userid
    delete _ZYCHECK_YZ where userid=@userid
    return 3
  end


  if @qfsetflag>=0 and @qfsetflag<@qfmoney+@summoney  /*大于允许欠费额度*/
  begin
    delete _ZYCFYPK_YZ where userid=@userid
    delete _ZYCHECK_YZ where userid=@userid
    return 4
  end
  

  /**********************以下开始追加到表zycfypk和zycfinf******************/
  /*寻找床位对应的护士*/
  declare @hscode char(4),@hsname char(10),@zgysname char(10)
  select @hscode=hscode,@hsname=hsname ,@zgysname=ysname
    from mbase (nolock),kscwset (nolock)
    where kscode=m16 and cwname=m18 and m01=@zynum

  /***Insert into zycfypk table***/
  insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                 cfcount,goodsname,procname,unitname,yfcode,jzdate,
                 jzoper,kmcode,kmname,lykscode,lyksname,yscode,ysname,
                 yskscode,ysksname,yplb,yplbname,xjsjnum,percount,ypjl,ypjlunit,
                 yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,ybno,ybkmcode,hzylflag,clflag,zgysname,jbypflag,SubYZID,drugdispense)
    select @zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
           cfcount,goodsname,procname,unitname,yfcode,@nowdate,@opername,kmcode,
           kmname,@currentkscode,@currentksname,yscode,ysname,yskscode,ysksname,
           goods.a24,goods.a25,null,percount,ypjl,ypjlunit,yzusedmethod,yppath,
           yzid,yzflag,yfname,@operksname,@operkscode,ybno,ybkmcode,hzylflag,clflag,@zgysname,a37,case when @SubYZID=0 then null else @subyzid end,drugdispense
      from _ZYCFYPK_YZ (nolock),goods (nolock)
        where a01=goodsno and userid=@userid
        order by keyno


  /***Update YFSTORE table***/
  update yfstore
    set a09=a09-sumypcount,a15=a15+sumypcount,a16=a16+sumypcount
    from yfstore,#zycfypgroupview
    where a01=goodsno and a10=yfcode

  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice 
    select _ZYCFYPK_YZ.goodsno,@nowdate,ypprice,ypprice_1,a08,a07,-ypcount,
        (a08-ypprice)*(-ypcount)*cfcount,(a07-ypprice_1)*(-ypcount)*cfcount,            
         @opername,'划价时价差',yfcode,yfname
     from yfstore,_ZYCFYPK_YZ
     where a01=_ZYCFYPK_YZ.goodsno and yfcode=a10
           and (_ZYCFYPK_YZ.ypprice<>a08 or _ZYCFYPK_YZ.ypprice_1<>a07) 
          and _ZYCFYPK_YZ.userid=@userid  
  /********************以下开始追加到表zycheck*********************/ 
  /*更新_ZYCHECK_YZ表中的需要字段*/

  /***Get CFNUM***/
  declare @t_checkcfnum int
  execute GetUniqueNo 6,@NewUniqueNo=@t_checkcfnum output

  insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzoper,jzdate,
                 checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                 yskscode,ysksname,checklb,checklbname,unitname,xjsjnum,fskscode,
                 fsksname,hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,jzkscode,
                 groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,zgysname,applicationflag,SubYZID)
    select @zynum,checkno,checkprice,checkcount,checkmoney,@opername,@nowdate,
           checkname,kmname,kmcode,@currentkscode,@currentksname,yscode,ysname,
           yskscode,ysksname,checklb,checklbname,unitname,null,fskscode,
           fsksname,hsflag,@hscode,@hsname,yzid,yzusedmethod,@yzflag,@t_checkcfnum,@operkscode,
           groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,@zgysname,applicationflag,case when @subyzid=0 then null else @subyzid end
    from _ZYCHECK_YZ (nolock)
    where checkprice is not null and CHECKNO is not null and RTRIM(checkno)<>'' and userid=@userid
    order by groupkeyno

  /***医技申请单***/
  declare @t_patientname char(20)
  select @t_patientname=m04 from mbase (nolock) where m01=@zynum
  insert yj_applysheet(ApplyNum,PatientName,PatientKind,PatientNum,patientinnum,ItemCode,ItemName,ItemPrice,ItemCount,ItemMoney,
                       ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,ApplyDate,jzopername,jzdate)
    select yjapplynum,@t_patientname,2,@zynum,@zynum,groupcode,groupname,groupprice,groupcount,sum(checkmoney),
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@nowdate,@operName,@nowdate
      from _ZYCHECK_YZ (nolock)
      where userid=@userid and yjapplynum is not null and groupcode is not null and checkmoney is not null
      group by groupcode,groupname,groupprice,groupcount,yjapplynum,fskscode,fsksname,yscode,ysname,yskscode,ysksname
    union all
    select yjapplynum,@t_patientname,2,@zynum,@zynum,checkno,checkname,checkprice,checkcount,checkmoney,
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@nowdate,@operName,@nowdate
      from _ZYCHECK_YZ (nolock)
      where userid=@userid and yjapplynum is not null and groupcode is null and checkmoney is not null


  /********最后更新 MBASE table********/
  update mbase
    set m25=case when m25 is null then 0 else m25 end + @summoney
  where m01=@zynum


  if @yzflag=2
  begin
    --更新医嘱执行标志,如为医嘱执行后记账则更新jzoper及jzdate字段
    update patient_applicationsheet
      set jzoper=case when jzflag is null then @opername else null end,jzdate=case when jzflag is null then @nowdate else null end,
          yzrundate=@nowdate,yzrunoper=@opername
      where zynum=@zynum and yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and xmflag=11 and yzbegdate<=@nowdate and yzlastrundate is null
          and case when subyzid is null then 0 else subyzid end=@subyzid)
  end

  --更新会诊申请单中的医嘱执行时间
  update consultationsheet
    set yzrundate=@nowdate
    where zynum=@zynum and yzid in(select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and xmflag=12 and yzbegdate<=@nowdate and yzlastrundate is null
        and case when subyzid is null then 0 else subyzid end=@subyzid)

  /********更新YZSheet表中的YZLastRunDate字段********/
  update yzsheet
    set yzlastrundate=@nowdate,
        yzrundate=@nowdate,   --此字段用于打印临时医嘱的执行时间，可修改
        yzcheckhscode=case when yzcheckhscode is null or rtrim(yzcheckhscode)='' then @opercode else yzcheckhscode end,  --第一次审核后姓名不变
        yzcheckhsname=case when yzcheckhsname is null or rtrim(yzcheckhsname)='' then @opername else yzcheckhsname end,  --第一次审核后姓名不变
        yzrunhscode=@opercode,
        yzrunhsname=@opername
    where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid
      and yzid in(select yzid from _ZYCFYPK_YZ (nolock) where userid=@userid
                  union all
                  select yzid from _ZYCHECK_YZ (nolock) where userid=@userid
                  union all  --不记账临时处方
                  select yzid from yzsheet where zynum=@zynum and zyyzid=@zyyzid
                    and yzflag=@yzflag and xmflag=6/*xmflag=6时表示临时处方*/
                    and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is not null)
                    and yzflag=@yzflag

  /*更新停嘱后的执行人及执行时间*/
  if @yzflag=1
    update yzsheet
      set yzlastrundate=@nowdate,
          yzstophscode=@opercode,
          yzstophsname=@opername
      where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzstopdate is not null and (yzstophscode is null or rtrim(yzstophscode)='') and yzflag=1 and deldate is null

  /*判断患者是否为危重病人*/
  declare @t_Critical int
  select @t_Critical=zynum from YZSHEET (nolock)
    where zynum=@zynum and zyyzid=@zyyzid and YZFLAG=1 and xmflag=5 and notjzyzflag=4 and deldate is null and yzlastrundate is not null and yzstopdate is null
  select @t_Critical=case when @t_Critical is not null then 1 else null end
  
  update mbase
    set m65=@t_Critical
    where m01=@zynum


  delete _ZYCFYPK_YZ where userid=@userid
  delete _ZYCHECK_YZ where userid=@userid
  return 0
end
GO
