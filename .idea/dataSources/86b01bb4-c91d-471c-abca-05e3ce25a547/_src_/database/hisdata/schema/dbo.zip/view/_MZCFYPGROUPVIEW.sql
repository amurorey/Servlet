


CREATE VIEW _MZCFYPGROUPVIEW AS
select yfcode,_mzcfypk.userid,goodsno,sum(ypcount*cfcount) as sumypcount 
  from _mzcfypk
  group by yfcode,_mzcfypk.userid,goodsno


GO
