CREATE    PROCEDURE [dbo].[SaveMZFP_DRYB]
(@yldyname char(20),@jsid char(20),@userid numeric,@fpnum int,@fpname char(20),@ybnum char(20),@jfcardid char(10)=null,
 @ybcardnum char(20),@ybareacode char(10),@ybareaname char(20),@rylbname char(20),@ybattrib char(20),@sex char(4),
 @personno char(20),@unitcode char(20),@unitname char(40),@fpdate datetime,@fpoper char(10),
 @leftzhmoney numeric(12,2),@fpmoney numeric(12,2),@TCZFMoney numeric(12,2),@ZHZFMoney numeric(12,2),
 @XJZFMoney numeric(12,2),@DBLPMoney numeric(12,2),@ZGBZMoney numeric(12,2),@GWYBZMoney numeric(12,2),
 @JFQRYMoney numeric(12,2),@QFXMoney numeric(12,2),@SYQFXMoney numeric(12,2),@roundflag int=null,
 @oldfpnumval int=null,@YBMoney numeric(12,2),@yberror numeric(12,2)=null,@retval char(1024) output,
 @mznum int=null,@patientid nvarchar(10)=null,@QZFYPMoney numeric(12,2),@QZFCheckMoney numeric(12,2),@QZFCLMoney numeric(12,2),
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  declare @ret int
  declare @ybzf numeric(12,2)
  select @ybzf=@ybmoney-@xjzfmoney

  execute @ret=SaveMZFP @fpnum=@fpnum,
                        @userid=@userid,
                        @fpname=@fpname,
                        @fpmoney=@fpmoney,
                        @opername=@fpoper,
                        @retval=@retval output,
                        @currentdate=@fpdate,
                        @oldfpnum=@oldfpnumval,
                        @ybflag=1,
                        @ybnum=@ybnum,
                        @jfcardid=@jfcardid,
                        @roundflag=null,
                        @ybareacode=@ybareacode,
                        @ybareaname=@ybareaname,
                        @zfmoney1=@ybzf,
                        @zfmoney2=@XJZFMoney,
                        @roundmoney=null,
                        @mznum=@mznum,
                        @yldyname=@yldyname,
                        @fpnum_tmp=null,
                        @yberror=@yberror,
                        @patientid=@patientID,
                        @InvoiceNum=@InvoiceNum,
                        @InvoiceOperID=@InvoiceOperID,
                        @sex=@sex
                        

/*  exec @ret=SaveMZFP @fpnum,@userid,@fpname,@fpmoney,@fpoper,@retval output,@fpdate,
       @oldfpnumval,1,@ybnum,@jfcardid,null,@ybareacode,@ybareaname,@ybzf,@xjzfmoney,
       null,@mznum,@yldyname,null,@yberror,@patientid*/
  if @ret <> 0 
    return @ret

  insert dryb_invoicebase(FPNum,PatientState,JSID,FPName,YBNum,YBCardNum,YBAreaCode,
                          YBAreaName,RYLBName,YBAttrib,Sex,PersonNo,UnitCode,UnitName,MZNum,
                          FPDate,FPOper,LeftZHMoney,FPMoney,
                          TCZFMoney,ZHZFMoney,XJZFMoney,DBLPMoney,ZGBZMoney,GWYBZMoney,
                          JFQRYMoney,QFXMoney,SYQFXMoney,QZFYPMoney,QZFCheckMoney,QZFCLMoney)
    values(@FPNum,1,@JSID,@FPName,@YBNum,@YBCardNum,@YBAreaCode,
           @YBAreaName,@RYLBName,@YBAttrib,@Sex,@PersonNo,@UnitCode,@UnitName,@FPNum,
           @FPDate,@FPOper,@LeftZHMoney,@YBMoney,
           @TCZFMoney,@ZHZFMoney,@XJZFMoney,@DBLPMoney,@ZGBZMoney,@GWYBZMoney,
           @JFQRYMoney,@QFXMoney,@SYQFXMoney,@QZFYPMoney,@QZFCheckMoney,@QZFCLMoney)

--  update patientbase
--    set treatmentnum=@ybnum,personid=@personno
--    where patientid=@patientid

  return 0
end
GO
