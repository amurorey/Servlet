CREATE   PROCEDURE [dbo].[DispZYCFYPK] 
(@cfnum int) with recompile
AS
begin  
  if exists(select cfnum from zycfypk where cfnum=@cfnum)
    select goodsno,
           case when jbypflag='1' then '*' else '' end +goodsname as goodsname,
           case when ypmoney>=0 and fydate is not null then '√'+rtrim(convert(char(20),fydate,2))+rtrim(fyopername)+'发药'
                when fydate is null and deldate is not null then '╳'+rtrim(convert(char(20),deldate,2))+rtrim(deloper)+'删除'
                when ypmoney<0 then '√'+rtrim(convert(char(20),fydate,2))+rtrim(fyopername)+'退药'
           end as note,*,
           case when a32='1' then '允许' else '' end as hzyl
      from zycfypk,goods (nolock) 
      where goodsno=a01 and cfnum=@cfnum and clflag is null
      order by keyno
  else
    select goodsno,
           case when jbypflag='1' then '*' else '' end +goodsname as goodsname,
           case when ypmoney>=0 and fydate is not null then '√'+rtrim(convert(char(20),fydate,2))+rtrim(fyopername)+'发药'
                when fydate is null and deldate is not null then '╳'+rtrim(convert(char(20),deldate,2))+rtrim(deloper)+'删除'
                when ypmoney<0 then '√'+rtrim(convert(char(20),fydate,2))+rtrim(fyopername)+'退药'
           end as note,*,
           case when a32='1' then '允许' else '' end as hzyl
      from zycfypkhis,goods (nolock) 
      where goodsno=a01 and cfnum=@cfnum and clflag is null
      order by keyno
end
GO
