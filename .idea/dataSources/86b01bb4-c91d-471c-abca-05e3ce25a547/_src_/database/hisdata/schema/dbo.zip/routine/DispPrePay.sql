CREATE  PROCEDURE [dbo].[DispPrePay] 
(@zynum int) with recompile
AS
begin
  if exists(select p01 from prepay where p01=@zynum)
    select P01,P03,P04,P05,P06,P07,P08,P09,P10,FPNUM,InvoiceNum,InvoiceNum_FP,
           case when p10 is null then p02 else '' end as p02
      from prepay (nolock) where p01=@zynum order by keyno
  else
    select P01,P03,P04,P05,P06,P07,P08,P09,P10,FPNUM,InvoiceNum,InvoiceNum_FP,
           case when p10 is null then p02 else '' end as p02
      from prepayhis (nolock) where p01=@zynum order by keyno
end
GO
