CREATE  PROCEDURE [dbo].[DispMZInvoice] 
(@fpnum int) with recompile
AS
begin
  select zfmoney1+case when zfmoney2 is null then 0 else zfmoney2 end as ssfpmoney,
         roundmoney as fbmoney,
     * from mzinvoice (nolock) where fpnum=@fpnum 
  union all
  select zfmoney1+case when zfmoney2 is null then 0 else zfmoney2 end as ssfpmoney,
         roundmoney as fbmoney,
     * from mzinvoicehis (nolock) where fpnum=@fpnum 
end
GO
