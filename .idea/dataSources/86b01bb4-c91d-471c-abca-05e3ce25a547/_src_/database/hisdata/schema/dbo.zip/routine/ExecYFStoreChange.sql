CREATE PROCEDURE [dbo].[ExecYFStoreChange]
(@sheetno char(10),@procdate datetime,@userid numeric(18,0),@opername char(10),@retval char(255) output)
AS
begin
  if exists(select a01 from yfstore,_yfstorechange 
              where a01=goodsno and userid=@userid and yfcode=a10 and a09+ypcount<0)
  begin
    declare @t_disptext char(255)
    DECLARE checkyfstore_cursor CURSOR FOR
      select rtrim(yfstore.a11)+'"'+rtrim(yfstore.a02)+'"的库存'+rtrim(convert(char(10),yfstore.a09))+'与调整数'+rtrim(convert(char(10),_yfstorechange.ypcount))+'之和不能小于零!' as disptext 
        from yfstore,_yfstorechange 
              where a01=goodsno and userid=@userid and yfcode=a10 and a09+ypcount<0    OPEN checkyfstore_cursor
    FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext+char(13)

      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    END
    CLOSE checkyfstore_cursor
    DEALLOCATE checkyfstore_cursor

    return -1
  end

  insert yfstorechange(sheetno,goodsno,goodsname,unit,price1,price2,
                       ypcount,procdate,yfcode,yfname,opername,note,flag)
    select @sheetno,goodsno,goodsname,unit,price1,price2,ypcount,@procdate,
           yfcode,yfname,@opername,note,flag
    from _yfstorechange 
    where userid=@userid

  update yfstore
    set a09=a09+ypcount
    from yfstore,_yfstorechange
    where a01=goodsno and a10=yfcode and userid=@userid

  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice
     select goodsno,@procdate,price2,price1,a08,a07,ypcount,(a08-price2)*(ypcount),
            (a07-price1)*(ypcount),@opername,
       '调整药房库存时价差',a10,a11 
     from yfstore,_yfstorechange
     where a01=goodsno and yfcode=a10 and (price2<>a08 or price1<>a07) and userid=@userid

  return 0
end
GO
