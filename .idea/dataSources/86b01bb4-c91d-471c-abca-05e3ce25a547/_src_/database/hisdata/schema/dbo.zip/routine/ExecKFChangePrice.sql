CREATE  PROCEDURE [dbo].[ExecKFChangePrice]
(@sheetno char(10),@userid float)
AS
begin
  insert kfchangeprice(sheetno,goodsid,goodsno,goodsname,unitname,addpercent,goodsstore,oldpjprice1,oldpjprice2,
                       oldljprice1,oldljprice2,afterpjprice1,afterpjprice2,afterljprice1,afterljprice2,yypjmoney,
                       yyljmoney,operdate,opername,storecode,storename,note)
    select @sheetno,goodsid,goodsno,goodsname,unitname,addpercent,goodsstore,oldpjprice1,oldpjprice2,
           oldljprice1,oldljprice2,afterpjprice1,afterpjprice2,afterljprice1,afterljprice2,yypjmoney,
           yyljmoney,getdate(),opername,storecode,storename,note 
    from _kfchangeprice
    where userid=@userid

  update store
    set e08=afterpjprice1,e08_1=afterpjprice2,e09=afterljprice1,e09_1=afterljprice2
    from store,_kfchangeprice
    where store.goodsid=_kfchangeprice.goodsid and e12=storecode and userid=@userid

  return 0
end
GO
