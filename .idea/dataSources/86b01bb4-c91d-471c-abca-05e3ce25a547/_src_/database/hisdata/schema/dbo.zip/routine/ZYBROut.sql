CREATE            PROCEDURE [dbo].[ZYBROut]
(@m01 int,@m19 datetime,@m20 char(4),@m21 char(10),
 @m22 float,@m23 char(10),@m24 datetime,@m28 int,@cyflag int=0,@m46 char(20)=null)
AS
begin
  /*如果病人已出院则退出*/
  if exists(select m01 from mbase (nolock) where m01=@m01 and m19 is not null)
    return 1

  if exists(select currentzynum from kscwset (nolock) where currentzynum=@m01)
    return 2

  declare @bqrunflag int
  select @bqrunflag=bqrunflag from unitset (nolock)
  if exists(select m01 from mbase (nolock) where m01=@m01 and m51 is not null and m53 is null) and @bqrunflag=1
    return 3

  update mbase
    set m19=@m19,m20=@m20,m21=@m21,m22=case when datediff(day,m11,@m19)<1 then 1 else datediff(day,m11,@m19) end,
        m23=@m23,m24=@m24,m28=@m28,m46=case when @m46 is null then m46 else @m46 end
    where m01=@m01

  delete from longcfypk where zynum=@m01
  delete from longzycheck where zynum=@m01

  /*将费用保存到病案首页中*/
--  exec SaveZYInvoiceToBAFpage @m01

  return 0
end
GO
