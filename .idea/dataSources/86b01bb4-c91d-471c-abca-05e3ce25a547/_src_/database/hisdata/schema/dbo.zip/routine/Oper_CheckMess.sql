CREATE    PROCEDURE [dbo].[Oper_CheckMess]
(@zynum int,@applynum int,@userid numeric(18,0))
AS
begin
  delete _BLErrorMess where userid=@userid

  declare @t_flag int

  select @t_flag=null
  select @t_flag=flag from oper_tab0 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉术前访视及风险评估单》已完成！',0,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉术前访视及风险评估单》尚未完成！',0,-2,getdate(),@userid)

  select @t_flag=null
  select @t_flag=flag from oper_tab1 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉计划书》已完成！',1,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉计划书》尚未完成！',1,-2,getdate(),@userid)

  select @t_flag=null
  select @t_flag=flag from oper_tab2 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉知情及术后镇痛、有创操作同意书》已完成！',2,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉知情及术后镇痛、有创操作同意书》尚未完成！',2,-2,getdate(),@userid)

  select @t_flag=null
  select @t_flag=flag from oper_tab3 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《手术安全核查表》已完成！',3,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《手术安全核查表》尚未完成！',3,-2,getdate(),@userid)

  select @t_flag=null
  select @t_flag=flag from oper_tab4 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《手术护理记录单》已完成！',4,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《手术护理记录单》尚未完成！',4,-2,getdate(),@userid)

  select @t_flag=null
  select @t_flag=flag from oper_tab5 (nolock) where zynum=@zynum and applynum=@applynum
  if (@t_flag=1)
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉小结》已完成！',5,0,getdate(),@userid)
  else
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('《麻醉小结》尚未完成！',5,-2,getdate(),@userid)

  declare @t_zynum int
  declare @t_zyyzid int
  declare @t_subyzid int

  select @t_zyyzid=zyyzid,@t_subyzid=subyzid from operationapply (nolock) where zynum=@zynum and applynum=@applynum

  select @t_zynum=null
  select @t_zynum=zynum
    from yzsheet (nolock) 
    where zynum=@zynum and zyyzid=@t_zyyzid and subyzid=@t_subyzid
  if @t_zynum is null
  begin
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('当前患者无“术中临时医嘱”',6,-1,getdate(),@userid)
  end else
  begin
    select @t_zynum=null
    select @t_zynum=zynum
      from yzsheet (nolock) 
      where zynum=@zynum and zyyzid=@t_zyyzid and subyzid=@t_subyzid and yzlastrundate is null
    if @t_zynum is not null
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('有尚未执行的“术中临时医嘱”',6,-2,getdate(),@userid)
    else
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('“术中临时医嘱”已执行完毕',6,0,getdate(),@userid)
  end
end
GO
