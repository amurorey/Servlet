CREATE PROCEDURE [dbo].[AutoAddZYCheck]
AS
begin
  BEGIN TRANSACTION autoadd 

  insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzoper,jzdate,
                 checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,yskscode,
                 ysksname,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,yzflag)
    select currentzynum,checkno,checkprice,checkcount,checkmoney,'自动记帐',getdate(),
           checkname,kmname,kmcode,kscwbasefy.kscode,kscwbasefy.ksname,'自记','自动记帐','自记',
           '自动记帐',checklb,checklbname,unitname,null,kscwbasefy.kscode,kscwbasefy.ksname,3
      from kscwbasefy,kscwset 
      where kscwbasefy.cwname=kscwset.cwname and kscwbasefy.kscode=kscwset.kscode 
            and currentzynum is not null

  select currentzynum as zynum,sum(checkmoney) as checkmoney into #checkmoneyforzynum
    from kscwbasefy,kscwset 
    where kscwbasefy.cwname=kscwset.cwname and kscwbasefy.kscode=kscwset.kscode 
          and currentzynum is not null
    group by currentzynum

  update mbase
    set m25=case when m25 is null then 0 else m25 end+
            case when checkmoney is null then 0 else checkmoney end
    from mbase,#checkmoneyforzynum
    where m01=zynum

  COMMIT TRANSACTION autoadd
end
GO
