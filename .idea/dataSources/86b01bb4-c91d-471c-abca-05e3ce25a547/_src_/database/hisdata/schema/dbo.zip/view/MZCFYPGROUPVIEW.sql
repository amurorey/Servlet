


CREATE VIEW MZCFYPGROUPVIEW AS
select yfcode,fpnum,goodsno,sum(ypcount*cfcount) as sumypcount 
  from mzcfypk (nolock)
  where deldate is null
  group by yfcode,fpnum,goodsno


GO
