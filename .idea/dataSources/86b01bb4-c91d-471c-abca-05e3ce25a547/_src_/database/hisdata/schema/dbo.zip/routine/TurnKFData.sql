CREATE PROCEDURE [dbo].[TurnKFData]
(@storecode char(2),@turndate datetime,@turnyear int,@opername char(10))
AS
begin
  if exists(select * from kfturnset where storecode=@storecode and turnyear=@turnyear)
    return 1

  insert kfturndata
    select goodsid,e01,e03,e10,e08,e09,e12,@turndate,@turnyear,@opername from store
      where e12=@storecode and e10<>0

  update kfturnset
    set enddate=@turndate where enddate is null and storecode=@storecode

  insert kfturnset
    values(@storecode,@turnyear,@turndate,null,@opername)

  
end
GO
