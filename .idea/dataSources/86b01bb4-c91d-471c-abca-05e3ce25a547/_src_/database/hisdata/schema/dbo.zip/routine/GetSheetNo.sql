CREATE PROCEDURE [dbo].[GetSheetNo]
(@storecode char(2),@NewUniqueNo int output)
AS
begin
  /*Attention:This no is from ykcode table*/
  update ykcode set SheetNo=SheetNo+1 where ykcode=@storecode
  select @NewUniqueNo=SheetNo from ykcode where ykcode=@storecode
end
GO
