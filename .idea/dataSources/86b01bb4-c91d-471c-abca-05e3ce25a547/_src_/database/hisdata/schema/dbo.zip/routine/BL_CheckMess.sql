/*ErrorLeve:  0:完成
              1:完成但超时

              -1：提示
              -2：警告

Flag:  1:病案
       2：入院记录
       3：首次病程记录
       4：日病程记录
       5：出院记录
       6：死亡记录
*/
CREATE             PROCEDURE [dbo].[BL_CheckMess]
(@ZYNum int,@userid numeric(18,0))
AS
begin
  delete _BLErrorMess where userid=@userid
  if @zynum=0 
    return 0

  declare @t_zynum int
  declare @t_fp0 char(10)

  declare @t_rydate datetime
  declare @t_cydate datetime
  declare @t_createdate datetime
  declare @t_auditdate datetime
  declare @t_swflag int
  declare @t_blflag int
  declare @t_attributiondate datetime

  select @t_rydate=M51,@t_cydate=m53,@t_blflag=m64 from mbase (nolock) where m01=@zynum

  if @t_blflag=1
  begin
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('注意：当前患者不书写病历！',1,-2,getdate(),@userid)

    return 0
  end


  --1、病案首页
  set @t_fp0=null
  select @t_fp0=fp0,@t_swflag=fp42 from ba_fpage (nolock) where fp0=rtrim(convert(char(10),@zynum)) and fp131 is not null
  if @t_fp0 is not null
  begin
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('当前患者“病案首页”已完成！',1,0,getdate(),@userid)
  end else
  begin
    set @t_fp0=null
    set @t_createdate=null
    select @t_fp0=fp0 from ba_fpage (nolock) where fp0=rtrim(convert(char(10),@zynum)) and fp131 is null
    if @t_fp0 is not null
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“病案首页”尚未完成！',1,-1,getdate(),@userid)
  end

  --2、入院记录
  set @t_zynum=null
  set @t_createdate=null
  select @t_zynum=zynum,@t_createdate=createdate,@t_auditdate=auditdate
    from bl_patientsheet (nolock) 
    where zynum=@zynum and bltype='01' and deldate is null
  if @t_createdate is null
  begin
    if datediff(hour,@t_rydate,getdate())<24
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“入院记录”尚未创建！',2,-1,getdate(),@userid)
    else
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“入院记录”尚未创建,并且已超过规定时限入院后24小时！',2,-2,getdate(),@userid)
  end else
  begin
    if @t_auditdate is null 
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“入院记录”已于'+convert(char(10),@t_createdate,120)+'创建,尚未审核！',2,-1,getdate(),@userid)
    else
      if datediff(hour,@t_rydate,@t_auditdate)<24
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“入院记录”已审核完成！',2,0,getdate(),@userid)
      else
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“入院记录”已审核完成,但超过规定时限入院后24小时！',2,1,getdate(),@userid)
  end


  --3、首次病程记录
  set @t_zynum=null
  set @t_createdate=null
  select @t_zynum=zynum,@t_auditdate=auditdate,@t_createdate=createdate
   from bl_patientsheet (nolock) 
   where zynum=@zynum and bltype='02' and deldate is null
  if @t_createdate is null
    if datediff(hour,@t_rydate,getdate())<8
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“首次病程记录”尚未创建！',3,-1,getdate(),@userid)
    else
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者“首次病程记录”尚未创建,并且已超过规定时限入院后8小时！',3,-2,getdate(),@userid)
  else
    if @t_auditdate is null 
      if datediff(hour,@t_rydate,getdate())<8
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“首次病程记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核！',3,-1,getdate(),@userid)
      else
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“首次病程记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核，请尽快审核！',3,-1,getdate(),@userid)
    else
      if datediff(hour,@t_rydate,@t_auditdate)<8
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“首次病程记录”已审核完成！',3,0,getdate(),@userid)
      else
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“首次病程记录”已审核完成,但超过规定时限入院后8小时！',3,1,getdate(),@userid)

  --4、日病程记录
  set @t_zynum=null
  set @t_createdate=null
  set @t_attributiondate=null
  select @t_auditdate=max(auditdate),@t_attributiondate=MAX(AttributionDate)
   from bl_patientsheet (nolock) 
   where zynum=@zynum and bltype in ('03','64') and deldate is null
  if @t_attributiondate is null   --@t_auditdate is null
    if datediff(day,@t_rydate,getdate())>3 and @t_cydate is null
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者已超过3天未书写“日病程记录”！',4,-2,getdate(),@userid)
  else
    if datediff(day,@t_attributiondate,getdate())>3 and @t_cydate is null
      insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
        values('当前患者已超过3天未书写“日病程记录”！',4,-2,getdate(),@userid)


  --5、出院记录
  if @t_cydate is not null and @t_swflag<>4
  begin
    set @t_zynum=null
    set @t_createdate=null
    select @t_zynum=zynum,@t_auditdate=auditdate,@t_createdate=createdate
     from bl_patientsheet (nolock) 
     where zynum=@zynum and bltype='09' and deldate is null
    if @t_createdate is null
      if datediff(hour,@t_cydate,getdate())<24
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“出院记录”尚未创建！',5,-1,getdate(),@userid)
      else
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“出院记录”尚未创建,并且已超过规定时限出院后24小时！',5,-2,getdate(),@userid)
    else
      if @t_auditdate is null 
        if datediff(hour,@t_cydate,getdate())<24
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“出院记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核！',5,-1,getdate(),@userid)
        else
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“出院记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核，请尽快审核！',5,-1,getdate(),@userid)
      else
        if datediff(hour,@t_cydate,@t_auditdate)<24
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“出院记录”已审核完成！',5,0,getdate(),@userid)
        else
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“出院记录”已审核完成,但超过规定时限出院后24小时！',5,1,getdate(),@userid)
  end

  --6、死亡记录
  if @t_swflag=4
  begin
    set @t_zynum=null
    set @t_createdate=null
    select @t_zynum=zynum,@t_auditdate=auditdate,@t_createdate=createdate
     from bl_patientsheet (nolock) 
     where zynum=@zynum and bltype='10' and deldate is null
    if @t_createdate is null
      if datediff(hour,@t_cydate,getdate())<24
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“死亡记录”尚未创建！',6,-1,getdate(),@userid)
      else
        insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
          values('当前患者“死亡记录”尚未创建,并且已超过规定时限出院后24小时！',6,-2,getdate(),@userid)
    else
      if @t_auditdate is null 
        if datediff(hour,@t_cydate,getdate())<24
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“死亡记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核！',6,-1,getdate(),@userid)
        else
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“死亡记录”已于 '+rtrim(convert(char(10),@t_createdate,120))+' 创建,尚未审核，请尽快审核！',6,-1,getdate(),@userid)
      else
        if datediff(hour,@t_cydate,@t_auditdate)<24
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“死亡记录”已审核完成！',5,0,getdate(),@userid)
        else
          insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
            values('当前患者“死亡记录”已审核完成,但超过规定时限出院后24小时！',6,1,getdate(),@userid)
  end


  --7、病历批注
  set @t_zynum=null
  select @t_zynum=zynum from bl_note where zynum=@zynum and procdate is null
  if @t_zynum is not null
    insert _blerrormess(errormess,flag,errorlevel,procdate,userid)
      values('病历监管部门对当前患者的病历有批注，请注意查看！',7,-1,getdate(),@userid)
end
GO
