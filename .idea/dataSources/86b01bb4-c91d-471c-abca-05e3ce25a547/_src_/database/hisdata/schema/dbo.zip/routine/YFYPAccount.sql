CREATE PROCEDURE [dbo].[YFYPAccount] 
(@begdate datetime,@enddate datetime,@yfcode char(2),@flag int)
AS
begin
  declare @zybegdate datetime
  select @zybegdate=min(begdate) from yfturnset (nolock) where yfcode=@yfcode

  if @flag=0
  begin
    select goodsname,rtrim(unit) as unit,
      sum(case 
        when procdate<@begdate then ypcount else 0 end) as A1,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag=1 then
        ypcount
      else
        0
      end) as A2,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag>=3 and flag<7 then
        -ypcount
      else
        0
      end) as A3,
      sum(case
      when procdate>=@begdate and procdate<@enddate and (flag=2 or flag=7) then
        ypcount
      else
        0
      end) as A4,
      sum(case
      when procdate<@enddate then
        ypcount
      else 
        0
      end) as A5
    from mzallypview (nolock)
    where yfcode=@yfcode and procdate>=@zybegdate and procdate<@enddate
    group by goodsname,rtrim(unit)
    order by goodsname,rtrim(unit)
  end else 
  begin
    select goods.a03 as lbname,
      sum(case 
        when procdate<@begdate then ypmoney1 else 0 end) as A1_1,
      sum(case 
        when procdate<@begdate then ypmoney2 else 0 end) as A1_2,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag=1 then
        ypmoney1
      else
        0
      end) as A2_1,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag=1 then
        ypmoney2
      else
        0
      end) as A2_2,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag>=3 and flag<7 then
        -ypmoney1
      else
        0
      end) as A3_1,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and flag>=3 and flag<7 then
        -ypmoney2
      else
        0
      end) as A3_2,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and (flag=7 or flag=2) then
        ypmoney1
      else
        0
      end) as A4_1,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and (flag=7 or flag=2) then
        ypmoney2
      else
        0
      end) as A4_2,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and (flag=8) then
        ypmoney1
      else
        0
      end) as A5_1,
      sum(case 
      when procdate>=@begdate and procdate<@enddate and (flag=8) then
        ypmoney2
      else
        0
      end) as A5_2,
      sum(case
      when procdate<@enddate then
        ypmoney1
      else 
        0
      end) as A6_1,
      sum(case
      when procdate<@enddate then
        ypmoney2
      else 
        0
      end) as A6_2
    from mzallypview,goods (nolock)
    where goodsno=goods.a01 and yfcode=@yfcode and procdate>=@zybegdate and procdate<@enddate
    group by goods.a03
    order by goods.a03
  end
end
GO
