













/****** Object:  View dbo.YFAllOutYPView    Script Date: 2005-01-24 09:32:15 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2004-12-05 21:16:02 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2004-11-19 10:15:21 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2004-10-18 16:22:46 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2004-08-19 10:16:19 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2003-11-07 20:41:34 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2003-07-25 16:36:34 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2003-07-11 14:02:10 ******/
/****** Object:  View dbo.YFAllOutYPView    Script Date: 2003-06-20 08:59:59 ******/
CREATE VIEW YFAllOutYPView AS
select goodsno,rtrim(goodsname) as goodsname ,unitname,-(ypcount*cfcount) as ypcount,ypprice_1 as price1,ypprice as price2,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end as _ypcount,fpdate as procdate,yfcode,3 as flag,-ypprice_1*ypcount*cfcount as ypmoney1,-ypmoney*cfcount as ypmoney2,yskscode as fskscode,ysksname as fsksname
  from mzcfypk (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,fpdate,yfcode,4,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount,yskscode,ysksname
  from mzcfypkhis (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,jzdate,yfcode,5,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount,yskscode,ysksname
  from zycfypk (nolock)
  where deldate is null
union all
select goodsno,rtrim(goodsname),unitname,-(ypcount*cfcount),ypprice_1,ypprice,
  case
    when fydate is null then (ypcount*cfcount)
    else 0
  end,jzdate,yfcode,6,-ypprice_1*ypcount*cfcount,-ypmoney*cfcount,yskscode,ysksname
  from zycfypkhis (nolock)
  where deldate is null


GO
