CREATE         PROCEDURE [dbo].[UTST_Patient_Cost]
(@req_time_begin datetime,@req_time_end datetime,@Patient_Code int,@Patient_kind char(1))
as
begin

  select @req_time_begin=convert(datetime,convert(char(20),@req_time_begin,101))  --去掉时间
  select @req_time_end=convert(datetime,convert(char(20),@req_time_end,101))      --去掉时间

  if @Patient_Kind = '0'
    SELECT '0' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.zynum)) AS patient_code,
          patientname AS patient_name,
          bedno AS bed_no,
          lykscode AS ward_code,
          checkno AS item_code,
          checkname AS item_name,
          patient_applicationcheckcode.checkmoney AS cost,
          samplecode AS module_kind,
          patient_applicationcheckcode.emergency_flag,
          patient_applicationsheet.YSName AS doctor,
          patient_applicationsheet.ApplyDate AS check_date,
          patient_applicationsheet.ysksname AS office,
          yldyname AS cost_type,
          JZOper AS cost_user,
          JZDate AS cost_date,
          convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
          convert(varchar(8),newgroupkeyno) as ord_item_no,
          '0' AS cost_flag,
          '0' AS check_flag,
          'null' AS remark_info,
          NULL AS other1,
          NULL AS other2
    FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock),kscode (nolock)
    WHERE patient_applicationsheet.zynum=@Patient_Code and
          patient_applicationcheckcode.applynum = patient_applicationsheet.applynum 
          and dbo.patient_applicationcheckcode.fskscode=KSCode.code and kscode.yjksattrib=1 and groupcode is null
      and yzrundate>=@req_time_begin and yzrundate<dateadd(day,1,@req_time_end) and deldate is null
    union all
    SELECT '0' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.zynum)) AS patient_code,
          patientname AS patient_name,
          bedno AS bed_no,
          lykscode AS ward_code,
          groupcode AS item_code,
          groupname AS item_name,
          patient_applicationcheckcode.groupprice AS cost,
          samplecode AS module_kind,
          patient_applicationcheckcode.emergency_flag,
          patient_applicationsheet.YSName AS doctor,
          patient_applicationsheet.ApplyDate AS check_date,
          patient_applicationsheet.ysksname AS office,
          yldyname AS cost_type,
          JZOper AS cost_user,
          JZDate AS cost_date,
          convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
          convert(varchar(8),newgroupkeyno) as ord_item_no,
          '0' AS cost_flag,
          '0' AS check_flag,
          'null' AS remark_info,
          NULL AS other1,
          NULL AS other2
    FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock),kscode (nolock)
    WHERE  patient_applicationcheckcode.zynum=@Patient_Code 
          and  patient_applicationcheckcode.applynum = patient_applicationsheet.applynum
          and patient_applicationsheet.zynum=@patient_code and yzrundate>=@req_time_begin and yzrundate<dateadd(day,1,@req_time_end) 
          and patient_applicationcheckcode.fskscode=KSCode.code and kscode.yjksattrib=1 and groupcode is not null
          and patient_applicationcheckcode.zynum is not null and deldate is null
          and keyno in(select min(keyno) from patient_applicationcheckcode (nolock),kscode (nolock)
                         where zynum=@patient_code and yzrundate>=@req_time_begin and yzrundate<dateadd(day,1,@req_time_end)
                               and fskscode=KSCode.code and kscode.yjksattrib=1 and groupcode is not null
                        group by applynum,newgroupkeyno)
  else
    SELECT '1' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.mznum)) AS patient_code,
          patientname AS patient_name,
          bedno AS bed_no,
          yskscode AS ward_code,
          checkno AS item_code,
          checkname AS item_name,
          patient_applicationcheckcode.checkmoney AS cost,
          samplecode AS module_kind,
          patient_applicationcheckcode.emergency_flag,
          patient_applicationsheet.YSName AS doctor,          patient_applicationsheet.ApplyDate AS check_date,
          patient_applicationsheet.ysksname AS office,
          yldyname AS cost_type,
          JZOper AS cost_user,
          JZDate AS cost_date,
          convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
          convert(varchar(8),newgroupkeyno) as ord_item_no,
          '0' AS cost_flag,
          '0' AS check_flag,
          'null' AS remark_info, 
          NULL AS other1, 
          NULL AS other2
    FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock),kscode (nolock)
    WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and patient_applicationsheet.mznum=@patient_code and jzdate>@req_time_begin and jzdate<dateadd(day,1,@req_time_end)
          and dbo.patient_applicationcheckcode.fskscode=KSCode.code and kscode.yjksattrib=1 and groupcode is null and deldate is null
    union all
    SELECT '1' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.mznum)) AS patient_code, 
          patientname AS patient_name, 
          bedno AS bed_no, 
          yskscode AS ward_code, 
          groupcode AS item_code, 
          groupname AS item_name, 
          patient_applicationcheckcode.groupprice AS cost, 
          samplecode AS module_kind,  
          patient_applicationcheckcode.emergency_flag, 
          patient_applicationsheet.YSName AS doctor, 
          patient_applicationsheet.ApplyDate AS check_date, 
          patient_applicationsheet.ysksname AS office,
          yldyname AS cost_type,
          JZOper AS cost_user,
          JZDate AS cost_date,
          convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
          convert(varchar(8),newgroupkeyno) as ord_item_no,
          '0' AS cost_flag,
          '0' AS check_flag,
          'null' AS remark_info,
          NULL AS other1,
          NULL AS other2
    FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock),kscode (nolock)
    WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and 
          patient_applicationsheet.mznum=@patient_code and jzdate>@req_time_begin and jzdate<dateadd(day,1,@req_time_end)
          and keyno in(select min(keyno) from patient_applicationcheckcode (nolock)
          where dbo.patient_applicationcheckcode.fskscode=KSCode.code and kscode.yjksattrib=1 and groupcode is not null and deldate is null
                and mznum=@patient_code
          group by applynum,newgroupkeyno)

end
GO
