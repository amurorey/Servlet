CREATE PROCEDURE [dbo].[DelHistoryData]  
(@turnyear int)
AS
begin
  declare @yearlastday datetime
  select @yearlastday=convert(datetime,convert(char(4),@turnyear)+'-12'+'-31')

  delete mzcfypkhis from mzcfypkhis,yfturnset where mzcfypkhis.yfcode=yfturnset.yfcode and turnyear=@turnyear and fpdate<enddate
  delete mzcfinfhis from mzcfinfhis,yfturnset where mzcfinfhis.yfcode=yfturnset.yfcode and turnyear=@turnyear and fpdate<enddate
  delete mzcheckhis where fpdate<@yearlastday
  delete mzinvoicehis where fpdate<@yearlastday
  delete mzchangeprice from mzchangeprice,yfturnset where mzchangeprice.yfcode=yfturnset.yfcode and turnyear=@turnyear and procdate<enddate

  delete zycfypkhis from zycfypkhis,yfturnset where zycfypkhis.yfcode=yfturnset.yfcode and turnyear=@turnyear and jzdate<enddate and jsdate<@yearlastday
  delete zycheckhis where jsdate<@yearlastday
  delete qfsetrec from mbase,qfsetrec where zynum=m01 and m31<@yearlastday and m19 is not null
  delete prepayhis from mbase,prepayhis where p01=m01 and m31<@yearlastday and m19 is not null
  delete zyinvoicebase from mbase,zyinvoicebase where zynum=m01 and m31<@yearlastday and m19 is not null
  delete zyinvoice from mbase,zyinvoice where zynum=m01 and m31<@yearlastday and m19 is not null
  delete turnmess from mbase,turnmess where zynum=m01 and m31<@yearlastday and m19 is not null
  delete yzsheethis from mbase,yzsheethis where zynum=m01 and m31<@yearlastday and m19 is not null
  delete mbase where m31<@yearlastday and m19 is not null

  delete yfstart from yfstart,yfturnset where yfstart.yfcode=yfturnset.yfcode and turnyear=@turnyear and operdate<enddate
  delete yfstorechange from yfstorechange,yfturnset where yfstorechange.yfcode=yfturnset.yfcode and turnyear=@turnyear and procdate<enddate
  delete yfturndata where turnyear<=@turnyear
  delete yfturnset where turnyear<=@turnyear and enddate is not null
end
GO
