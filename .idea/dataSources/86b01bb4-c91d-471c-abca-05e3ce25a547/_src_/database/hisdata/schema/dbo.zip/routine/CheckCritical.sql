--@flag=0  门诊
--@flag=1  住院
--@caseflag=0  尚未接收的记录
--@caseflag=1  已接收的记录
CREATE       PROCEDURE [dbo].[CheckCritical]
(@servername varchar(40),@databasename varchar(40),@username varchar (20),@password varchar(20),@flag int,@kscode char(10),@caseflag int=0)
AS
begin
SET ANSI_WARNINGS on
SET ANSI_NULLS on
  declare @casestr nvarchar(128)
  if @caseflag=0
    set @casestr='receive_date is null'
  else
    set @casestr='receive_date is not null'
  

  declare @str nvarchar(1024)
  if @flag=1  --住院
    select @str= 'select a.*,
                    case when flag=0 then ''危急值'' else ''疫情提示'' end as flagdisp,
                    b.m18 as cwname,m04 as patientname from OPENDATASOURCE(''SQLOLEDB'',''Data Source='+@servername+';User ID='+@username+';Password='+@password+
               ''') .'+@databasename+'.dbo.patientcritical a,mbase b where inpatientnum=convert(varchar(20),m01) and inpatientnum is not null and '+ @casestr + ' and m16='''+@kscode+''''
  else       --门诊
    select @str= 'select a.*,
                    case when flag=0 then ''危急值'' else ''疫情提示'' end as flagdisp,
                    b.registerdate,patientname from OPENDATASOURCE(''SQLOLEDB'',''Data Source='+@servername+';User ID='+@username+';Password='+@password+
               ''') .'+@databasename+'.dbo.patientcritical a,mzregistersheet b where outpatientnum=convert(varchar(20),mznum) and outpatientnum is not null and ' + @casestr + ' and kscode='''+@kscode+''''

  exec sp_executesql @str
end
GO
