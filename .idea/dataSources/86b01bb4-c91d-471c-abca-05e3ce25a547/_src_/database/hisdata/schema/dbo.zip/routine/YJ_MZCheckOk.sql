/*医技科室审核确认存储过程*/
/*@checkflag=1确认   2：取消*/
CREATE          PROCEDURE [dbo].[YJ_MZCheckOk]
(@fpnum int,@yjkscode char(10),@opercode char(10),@opername char(20),@checkflag int)
AS
begin
  declare @t_applynum int
  select @t_applynum=null
  select @t_applynum=applynum from yj_applysheet (nolock) where fpnum=@fpnum and deldate is not null and itemkscode=@yjkscode
  if @t_applynum is not null
    return -1  --已被删除

  if @checkflag=1
  begin
    select @t_applynum=null
    select @t_applynum=applynum from yj_applysheet (nolock) where fpnum=@fpnum and itemkscode=@yjkscode and yjcheckdate is not null
    if @t_applynum is not null
      return -2


    update patient_applicationsheet
      set yjcheckdate=getdate(),yjcheckoper=@opername
      from patient_applicationsheet
      where fpnum=@fpnum and yjcheckdate is null and fskscode=@yjkscode

    update patient_applicationcheckcode
      set yjcheckdate=getdate(),yjcheckoper=@opername
      from patient_applicationcheckcode,patient_applicationsheet
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and fpnum=@fpnum and patient_applicationcheckcode.yjcheckdate is null and patient_applicationsheet.fskscode=@yjkscode

    update yj_applysheet
      set yjcheckopercode=@opercode,yjcheckopername=@opername,
          yjcheckdate=getdate()
      where fpnum=@fpnum and itemkscode=@yjkscode

    update yj_applysheethis
      set yjcheckopercode=@opercode,yjcheckopername=@opername,
          yjcheckdate=getdate()
      where fpnum=@fpnum and itemkscode=@yjkscode
  end

  if @checkflag=2 
  begin
    select @t_applynum=null
    select @t_applynum=applynum from yj_applysheet (nolock) where fpnum=@fpnum and yjcheckdate is null and itemkscode=@yjkscode
/*    if @t_applynum is not null
      return -3  --已被取消*/

    select @t_applynum=null
    select @t_applynum=applynum from yj_applysheet (nolock) where fpnum=@fpnum and jsdate is not null and itemkscode=@yjkscode
    if @t_applynum is not null
      return -4  --已被结算


    update patient_applicationsheet
      set yjcheckdate=null,yjcheckoper=null
      from patient_applicationsheet
      where fpnum=@fpnum and yjcheckdate is not null and fskscode=@yjkscode

    update patient_applicationcheckcode
      set yjcheckdate=null,yjcheckoper=null
      from patient_applicationcheckcode,patient_applicationsheet
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and fpnum=@fpnum and patient_applicationcheckcode.yjcheckdate is not null and patient_applicationsheet.fskscode=@yjkscode


    update yj_applysheet
      set yjcheckopercode=null,yjcheckopername=null,
          yjcheckdate=null
      where fpnum=@fpnum and itemkscode=@yjkscode

    update yj_applysheethis
      set yjcheckopercode=null,yjcheckopername=null,
          yjcheckdate=null
      where fpnum=@fpnum and itemkscode=@yjkscode
  end
  
  return 0
end
GO
