CREATE   PROCEDURE [dbo].[DispZYCFYPKNEW] 
(@zynum int,@yzflag int=0) with recompile
/*@yzflag显示医嘱方式*/
/*0：全部  1：长期  2：临时  3：出院带药*/
AS
begin
  if exists(select cfnum from zycfypk (nolock) where zynum=@zynum)
    if @yzflag=0
      select goodsno,
             case when jbypflag='1' then '*' else '' end + goodsname as goodsname,
             ypcount*cfcount as ypcount,ypmoney*cfcount as ypmoney,*,
             hzylflag as hzyl
             from zycfypk (nolock) 
        where zynum=@zynum and clflag is null
        order by jzdate desc,keyno asc
    else
      select goodsno,
             case when jbypflag='1' then '*' else '' end + goodsname as goodsname,
             ypcount*cfcount as ypcount,ypmoney*cfcount as ypmoney,*,
             hzylflag as hzyl
             from zycfypk (nolock) 
        where zynum=@zynum and yzflag=@yzflag and clflag is null
        order by jzdate desc,keyno asc
  else
    if @yzflag=0
      select goodsno,
             case when jbypflag='1' then '*' else '' end + goodsname as goodsname,
             ypcount*cfcount as ypcount,ypmoney*cfcount as ypmoney,*,
             hzylflag as hzyl
             from zycfypkhis (nolock) 
        where zynum=@zynum and clflag is null
        order by jzdate desc,keyno asc
    else 
      select goodsno,
             case when jbypflag='1' then '*' else '' end + goodsname as goodsname,
             ypcount*cfcount as ypcount,ypmoney*cfcount as ypmoney,*,
             hzylflag as hzyl
             from zycfypkhis (nolock) 
        where zynum=@zynum and yzflag=@yzflag and clflag is null
        order by jzdate desc,keyno asc
end
GO
