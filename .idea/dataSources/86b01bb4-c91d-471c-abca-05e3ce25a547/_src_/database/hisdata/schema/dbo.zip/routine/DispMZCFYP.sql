CREATE    PROCEDURE [dbo].[DispMZCFYP]
(@fpnum int,@cfnum int,@flag int) with recompile
AS
begin
  if exists(select * from mzcfypk where fpnum=@fpnum and cfnum=@cfnum)
    select case when jbypflag='1' then '*' else '' end +
           case
             when yblb='1' then '(甲)'
             when yblb='2' then '(乙)'
             when yblb='0' then '(丙)'
             else ''
             end + goodsname as ybgoodsname,
             * from mzcfypk (nolock) 
      where fpnum=@fpnum and cfnum=@cfnum and clflag is null
      order by keyno
  else
    select case when jbypflag='1' then '*' else '' end +
           case
             when yblb='1' then '(甲)'
             when yblb='2' then '(乙)'
             when yblb='0' then '(丙)'
             else ''
             end + goodsname as ybgoodsname,
             * from mzcfypkhis (nolock)
      where fpnum=@fpnum and cfnum=@cfnum and clflag is null
      order by keyno
end
GO
