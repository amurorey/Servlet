CREATE   PROCEDURE [dbo].[AddLongZYCF] 
(@zynum int,@userid numeric,@opername char(10),@retval varchar(40)="" output,@currentdate datetime,@fyflag int,@operkscode char(4),@operksname char(10),@qfsetflag int)
AS
begin
  if exists(select zynum from zycfypk where zynum=@zynum and datename(yy,jzdate)=datename(yy,@currentdate) 
                and datename(mm,jzdate)=datename(mm,@currentdate) and datename(dd,jzdate)=datename(dd,@currentdate) and yzflag=1 and yzid is null)
    return -1
  /***Insert into _zycfypk table***/
  delete _zycfypk where userid=@userid
  insert _zycfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,yscode,ysname,yskscode,ysksname,userid,procdate,yplb,yplbname)
    select null,goodsno,ypcount,a08,a07,round(a08*ypcount,2),cfcount,goodsname,a05,unitname,yfcode,yfname,kmcode,kmname,yscode,ysname,yskscode,ysksname,@userid,@currentdate,yplb,yplbname
      from longcfypk,yfstore
      where goodsno=a01 and yfcode=a10 and zynum=@zynum
      order by keyno

  update _zycfypk
    set jbypflag=a37
    from _zycfypk (nolock),goods(nolock)
    where goodsno=a01 and userid=@userid

  /***Insert int _zycfinf table***/
/*  delete _zycfinf where userid=@userid
  declare @yscode char(4),@ysname char(10),@cfprice numeric(12,2),@yfcode char(2),@yfname char(20)
  declare @yskscode char(4),@ysksname char(10)
  select @yscode=yscode,@ysname=ysname,@yfcode=yfcode,@yfname=yfname,@yskscode=yskscode,@ysksname=ysksname
    from longcfypk where zynum=@zynum
  select @cfprice=sum(ypmoney) from _zycfypk where userid=@userid
  insert _zycfinf(cfnum,yscode,ysname,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,yskscode,ysksname,userid,procdate)
    values(@cfnum,@yscode,@ysname,3,@cfprice,1,@cfprice*1,@yfcode,@yfname,@yskscode,@ysksname,@userid,@currentdate)*/


  declare @ret int
  exec @ret=addzycf @zynum,@userid,@opername,@retval output,@currentdate,@fyflag,@operkscode,@operksname,null,@qfsetflag,1
  /***Update LongCFYPK table***/
  if @ret=0 
  begin
    update longcfypk
      set procdate=@currentdate
    where zynum=@zynum
  end
  delete _zycfypk where userid=@userid
  return @ret
end
GO
