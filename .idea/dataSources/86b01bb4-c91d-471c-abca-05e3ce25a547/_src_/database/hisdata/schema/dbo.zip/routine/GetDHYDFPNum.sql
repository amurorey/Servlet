CREATE PROCEDURE [dbo].[GetDHYDFPNum]
(@NewUniqueNo int output)
AS
begin
  update dhyd_fpnum set fpnum=fpnum+1
  select @NewUniqueNo=fpnum from dhyd_fpnum
end
GO
