--住院检查项目价格审核
--@shflag=1通过审核  @shflag=0取消审核
--@checkallflag=1审核（或取消）所有  @checkallflag=0单条
CREATE  PROCEDURE [dbo].[ZYCHECKSH]
(@zynum int,@keyno numeric(12),@groupkeyno numeric(12),@checkoper char(10),@checkdate datetime,@shflag int,@checkallflag int=0)
AS
begin
  if exists(select m01 from mbase (nolock) where m19 is not null and m01=@zynum)
    return -1  --已出院

  if @shflag=1   --审核
  begin
    if @checkallflag=0
    begin
      if @groupkeyno is not null and @groupkeyno<>0  --组套
        update zycheck
          set checkoper=@checkoper,checkdate=@checkdate
          where zynum=@zynum and groupkeyno=@groupkeyno and checkoper is null
      else
        update zycheck
          set checkoper=@checkoper,checkdate=@checkdate
          where zynum=@zynum and keyno=@keyno and checkoper is null
    end else
    begin
      update zycheck
        set checkoper=@checkoper,checkdate=@checkdate
        where zynum=@zynum
    end
  end else       --取消审核
  begin
    if @checkallflag=0 
    begin
      if @groupkeyno is not null and @groupkeyno<>0  --组套
        update zycheck
          set checkoper=null,checkdate=null
          where zynum=@zynum and groupkeyno=@groupkeyno and checkoper is not null
      else
        update zycheck
          set checkoper=null,checkdate=null
          where zynum=@zynum and keyno=@keyno and checkoper is not null
    end else
    begin
      update zycheck
        set checkoper=null,checkdate=null
        where zynum=@zynum
    end
  end

  return 0

end
GO
