CREATE  PROCEDURE [dbo].[ProcYZ] 
(@zynum int,@zyyzid int,@userid numeric,@opercode char(4),@opername char(10),
 @retval char(1024)="" output,@operkscode char(4),@operksname char(20),
 @qfsetflag int,@yzflag int,@xmflag int=null,@subyzid int=0,@nowdate datetime)
AS
begin
  if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
    return 5  --已取消入院


  /*在MBASE中定义当前的护理级别*/
  declare @t_hljbcount int
  declare @t_hljbflag char(10)

  select @t_hljbcount=0
  DECLARE hljb_cursor CURSOR FOR
    select hljbflag from
    (select hljbflag from yzsheet (nolock),checkcode (nolock)
      where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzstopdate is null and yzflag=1
            and hljbflag is not null and hljbflag<>''
     union all--附加计价
     select hljbflag from yzfjcheck (nolock),checkcode (nolock)
      where checkno=code and yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzstopdate is null and yzflag=1)
            and hljbflag is not null and hljbflag<>''
     group by hljbflag) disp
  OPEN hljb_cursor
  FETCH NEXT FROM hljb_cursor into @t_hljbflag
  WHILE @@FETCH_STATUS = 0
  BEGIN
    select @t_hljbcount=@t_hljbcount + 1

    FETCH NEXT FROM hljb_cursor into @t_hljbflag
  END
  CLOSE hljb_cursor
  DEALLOCATE hljb_cursor

         
  if @t_hljbcount>1 and (@yzflag=1 or @yzflag=2)  /*在未停长期医嘱中不能同时有两个以上护理级别*/
    return -1

  
  update mbase
    set m37=@t_hljbflag
    where m01=@zynum and @t_hljbflag is not null and rtrim(@t_hljbflag)<>''


  update yzsheet
    set yzcountforday=countforday,
        yzcountforweek=countforweek
    from yzsheet (nolock),yzusedmethodcode (nolock)
    where zynum=@zynum and yzusedmethod=methodcode and (yzcountforweek is null or yzcountforday is null)
      and case when subyzid is null then 0 else subyzid end=@subyzid

  --如果没有输入频次则自动将每天用法设置为1次
  update yzsheet
    set YZCOUNTFORDAY=1,YZCOUNTFORWEEK=1
    where zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and (yzcountforday is null or yzcountforday=0)
       and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新长期医嘱中诊疗项目的单价等项目*/
  /*A.如果价格不允许修改时*/
  update yzsheet
    set xmprice=price,xmmoney=round(price*xmcount,2)
    from yzsheet (nolock),checkcode (nolock)
    where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and yzflag=1
         and yzstopdate is null and xmprice<>price
         and unchangeprice=1 and case when subyzid is null then 0 else subyzid end=@subyzid

  /*B.如果价格允许修改时*/
  update yzsheet
    set xmprice=maxprice,xmmoney=round(maxprice*xmcount,2)
    from yzsheet (nolock),checkcode (nolock)
    where xmcode=code and zynum=@zynum and zyyzid=@zyyzid and xmflag=4 and yzflag=1
          and yzstopdate is null
          and xmprice>maxprice and standflag=1 and unchangeprice is null
          and case when subyzid is null then 0 else subyzid end=@subyzid

  /*C.更新组单价*/
  update yzsheet
    set checkgroupprice=groupprice
  from yzsheet (nolock),
    (select yzid,sum(xmprice*xmcount) as groupprice from yzsheet (nolock) where zynum=@zynum and xmflag=4 and yzflag=1 and zyyzid=@zyyzid and checkgroupcode is not null
        and case when subyzid is null then 0 else subyzid end=@subyzid
      group by yzid) disp
  where yzsheet.yzid=disp.yzid and zynum=@zynum and zyyzid=@zyyzid and xmflag>=4 and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新长期医嘱中药品的单价等项目*/
  update yzsheet
    set xmprice=a08,xmmoney=round(a08*xmcount,2)
    from yzsheet (nolock),yfstore (nolock)
    where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid and xmflag<4 and yzflag=1
         and yzstopdate is null and xmprice<>a08
         and case when subyzid is null then 0 else subyzid end=@subyzid

  /*修改附加记帐*/
  update yzfjcheck
    set checkprice=price,checkmoney=round(price*checkcount,2)
    from yzfjcheck (nolock),checkcode (nolock)
    where checkno=code and checkprice<>price 
          and standflag=1 and unchangeprice=1
          and yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and yzstopdate is null and case when subyzid is null then 0 else subyzid end=@subyzid) 
 

  update yzfjcheck
    set checkprice=price,checkmoney=round(price*checkcount,2)
    from yzfjcheck (nolock),checkcode (nolock)
    where checkno=code and checkprice<>price 
          and ((checkprice>maxprice and standflag=1) or (standflag is null and unchangeprice is not null))
          and yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and yzstopdate is null and case when subyzid is null then 0 else subyzid end=@subyzid) 


  update yzfjcheck
    set yscode=yzyscode,
        ysname=yzysname,
        yskscode=yzyskscode,
        ysksname=yzysksname
    from yzfjcheck (nolock),yzsheet (nolock)
    where zynum=@zynum and yzfjcheck.yzid=yzsheet.yzid and yzstopdate is null and case when subyzid is null then 0 else subyzid end=@subyzid


  /*更新附加记价组单价*/
  update yzfjcheck
    set yzfjcheck.groupprice=disp.groupprice
  from yzfjcheck (nolock),
    (select yzid,sum(checkprice*checkcount) as groupprice 
      from yzfjcheck (nolock)
      where groupcode is not null
        and yzfjcheck.yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzflag=1 and case when subyzid is null then 0 else subyzid end=@subyzid)
      group by yzid) disp
  where yzfjcheck.yzid=disp.yzid and yzfjcheck.yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and yzstopdate is null and yzflag=1
       and case when subyzid is null then 0 else subyzid end=@subyzid) 


  update yzsheet
    set totcount=round(xmcount*(case when yzcountforday=0 or yzcountforday is null then 1 else yzcountforday end)+0.4,0)
    where zynum=@zynum and zyyzid=@zyyzid
          and xmflag<4 and (totcount is null or totcount=0)
          and case when subyzid is null then 0 else subyzid end=@subyzid


  /********以下开始生成_ZYCFYPK临时表*******/
  /***Insert into _zycfypk table***/
  delete _zycfypk where userid=@userid

  if (@xmflag is null) or (@xmflag=1)
  begin
    if @yzflag=1  /*长期医嘱时*/
      insert _zycfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                      goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                      yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                      yzusedmethod,yppath,userid,procdate,yzflag)
        select null,xmcode,totcount,a08,a07,
               round(a08*totcount,2),1,a02,a05,a06,yfcode,yfname,
               kmcode,kmname,yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,
               ypjl,ypjlunit,yzusedmethod,yppath,@userid,@nowdate,@yzflag
          from yzsheet (nolock),yfstore (nolock)
          where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid
                and yzflag=1 and xmflag<4 and yzbegdate<=@nowdate
                and (datediff(dd,yzlastrundate,@nowdate)>=yzcountforweek
                     or yzlastrundate is null)
                and (yzstopdate is null or yzstopdate>@nowdate) and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null
          order by keyno
    else if @yzflag=2          /*临时医嘱时*/
      insert _zycfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                      goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                      yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                      yzusedmethod,yppath,userid,procdate,yzflag)
        select null,xmcode,totcount,a08,a07,
               round(a08*totcount,2),1,a02,a05,a06,yfcode,yfname,
               kmcode,kmname,yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,
               ypjl,ypjlunit,yzusedmethod,yppath,@userid,@nowdate,@yzflag
          from yzsheet (nolock),yfstore (nolock)
          where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid
                and yzflag=2 and xmflag<4
           and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null
          order by keyno
  end


  /***********以下开始生成_ZYCheck临时表************/
  delete _zycheck where userid=@userid
  if (@xmflag=null) or (@xmflag=2)
  begin
    if @yzflag=1    /*长期医嘱时*/
      insert _zycheck(checkno,checkprice,
                      checkcount,
                      checkmoney,
                      checkname,
                      kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                      fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                      groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,userid)
        select xmcode,xmprice,
               case when checkgroupcode is null then totcount else xmcount*totcount end,
               case when checkgroupcode is null then round(xmprice*totcount,2) else round(xmprice*xmcount*totcount,2) end,
               xmname,
               kmname,kmcode,yzyscode,yzysname,yzyskscode,yzysksname,yblb,yblbname,xmunit,
               fskscode,fsksname,checkgroupcode,checkgroupname,checkgroupprice,totcount,
               checkgroupkeyno,yzid,yzusedmethod,yjapplynum,@nowdate,@userid
          from yzsheet (nolock)
          where zynum=@zynum and zyyzid=@zyyzid and yzflag=1 and (xmflag=4 or xmflag=5 or xmflag=7 or xmflag=8 or xmflag=9 or xmflag=10 or xmflag=11)
             and yzbegdate<=@nowdate
             and (datediff(dd,yzlastrundate,@nowdate)>=yzcountforweek
                  or yzlastrundate is null)
             and (yzstopdate is null or yzstopdate>@nowdate) and case when subyzid is null then 0 else subyzid end=@subyzid
            order by keyno
    else if @yzflag=2            /*临时医嘱时*/
      insert _zycheck(checkno,checkprice,
                      checkcount,
                      checkmoney,
                      checkname,
                      kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                      fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                      groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,userid)
        select xmcode,xmprice,
               case when checkgroupcode is null then totcount else xmcount*totcount end,
               case when checkgroupcode is null then round(xmprice*totcount,2) else round(xmprice*xmcount*totcount,2) end,
               xmname,
               kmname,kmcode,yzyscode,yzysname,yzyskscode,yzysksname,yblb,yblbname,xmunit,
               fskscode,fsksname,checkgroupcode,checkgroupname,checkgroupprice,totcount,
               checkgroupkeyno,yzid,yzusedmethod,yjapplynum,@nowdate,@userid
          from yzsheet (nolock)
          where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and (xmflag=4 or xmflag=5 or xmflag=7 or xmflag=8 or xmflag=9 or xmflag=10 or xmflag=11)
           and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid
          order by keyno
  end


  --将医嘱执行后直接记账的检查申请存入临时表中
  if @yzflag=2
  begin
    insert _zycheck(checkno,checkprice,checkcount,checkmoney,checkname,
                    kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
                    fskscode,fsksname,groupcode,groupname,groupprice,groupcount,
                    groupkeyno,yzid,yzusedmethod,yjapplynum,procdate,applicationflag,userid)
      select checkno,checkprice,checkcount,patient_applicationcheckcode.checkmoney,checkname,
             kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,unitname,
             patient_applicationcheckcode.fskscode,patient_applicationcheckcode.fsksname,groupcode,groupname,groupprice,groupcount,
             newgroupkeyno,yzid,null,patient_applicationsheet.applynum,getdate(),1,@userid
      from patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and patient_applicationcheckcode.zynum=@zynum and
            yzid in(select yzid from yzsheet (nolock) where zynum=@zynum and zyyzid=@zyyzid and yzflag=2 and xmflag=11 and yzbegdate<=@nowdate and yzlastrundate is null) and
            case when subyzid is null then 0 else subyzid end=@subyzid and
            jzflag is null --医嘱执行后记账
  end


  /***将附加计价中的数据追加至_zycheck表中***/
  insert _zycheck(checkno,checkprice,checkcount,checkmoney,checkname,
                  kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,
                  unitname,fskscode,fsksname,groupcode,groupname,groupprice,groupcount,groupkeyno,yzid,userid,procdate)
    select checkno,checkprice,checkcount,checkmoney,checkname,
                  kmname,kmcode,yscode,ysname,yskscode,ysksname,checklb,checklbname,
                  unitname,fskscode,fsksname,groupcode,groupname,groupprice,groupcount,groupkeyno,yzid,@userid,@nowdate
      from yzfjcheck (nolock)
      where yzid in(select yzid from _zycfypk (nolock) where userid=@userid 
                    union all 
                    select yzid from _zycheck (nolock) where userid=@userid
                    union all
                    select yzid from yzsheet (nolock) 
                      where zynum=@zynum 
                      and zyyzid=@zyyzid and @yzflag=1 and yzflag=1 and (xmflag=5) and yzbegdate<=@nowdate
                      and yzlastrundate is null
                      and (yzstopdate is null or yzstopdate>@nowdate) and case when subyzid is null then 0 else subyzid end=@subyzid
                      and yzflag=@yzflag
                    union all
                    select yzid from yzsheet (nolock)
                       where zynum=@zynum and zyyzid=@zyyzid and @yzflag=2 and (xmflag=5 or xmflag=6 or xmflag=11)
                         and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid
                         and yzflag=@yzflag)
      order by keyno

  /*将附加记价的材料追加至_zycfypk表中*/
    insert _zycfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                    goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                    yscode,ysname,yskscode,ysksname,yzid,
                    clflag,userid,procdate,yzflag)
      select null,goodsno,ypcount,ypprice,ypprice_1,ypmoney,1,
             goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
             yscode,ysname,yskscode,ysksname,yzid,
             1,@userid,getdate(),@yzflag
        from yzfjcl (nolock)
        where yzid in(select yzid from _zycfypk (nolock) where userid=@userid 
                      union all 
                      select yzid from _zycheck (nolock) where userid=@userid
                      union all
                      select yzid from yzsheet (nolock) 
                        where zynum=@zynum 
                        and zyyzid=@zyyzid and @yzflag=1 and yzflag=1 and (xmflag=5) and yzbegdate<=@nowdate
                        and yzlastrundate is null
                        and (yzstopdate is null or yzstopdate>@nowdate) and case when subyzid is null then 0 else subyzid end=@subyzid
                      union all
                      select yzid from yzsheet (nolock)
                         where zynum=@zynum and zyyzid=@zyyzid and @yzflag=2 and yzflag=2 and (xmflag=5 or xmflag=6 or xmflag=11)
                           and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid)
      order by keyno


   /*判断在同一药房、同一医师的为同一处方*/
  declare @t_yfcode char(2)
  declare @t_yscode char(4)
  declare @t_cfnum int
  DECLARE yfcodegroup_cursor CURSOR FOR
    SELECT yfcode,yscode FROM _zycfypk where userid=@userid group by yfcode,yscode
  OPEN yfcodegroup_cursor
  FETCH NEXT FROM yfcodegroup_cursor into @t_yfcode,@t_yscode
  WHILE @@FETCH_STATUS = 0
  BEGIN
    begin transaction
      execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output
    commit transaction

    update _zycfypk
      set cfnum=@t_cfnum      
        where yfcode=@t_yfcode and yscode=@t_yscode and userid=@userid

    FETCH NEXT FROM yfcodegroup_cursor into @t_yfcode,@t_yscode
  END
  CLOSE yfcodegroup_cursor
  DEALLOCATE yfcodegroup_cursor
  /***********************************************************************/ 


  /*执行临时处方时，有两种情况：1.长期  2.临时  特别注意：无论长期或临时仅执行一次*/
  /*在执行长期医嘱时执行临时处方。注意仅第一次执行，不需要对CFNUM重新赋值，所以把此语句放在对处方号赋值后*/
  insert _zycfypk(cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,
                  goodsname,procname,unitname,yfcode,yfname,kmcode,kmname,
                  yscode,ysname,yskscode,ysksname,yzid,percount,ypjl,ypjlunit,
                  yzusedmethod,yppath,userid,procdate,yzflag)
    select cfnum,xmcode,totcount,xmprice,a07,round(a08*totcount,2),case when cfcount is null then 1 else cfcount end,
           a02,a05,a06,yfcode,yfname,kmcode,kmname,
           yzyscode,yzysname,yzyskscode,yzysksname,yzid,xmcount,ypjl,ypjlunit,
           yzusedmethod,yppath,@userid,@nowdate,4
      from yzsheet (nolock),yfstore (nolock)
        where xmcode=a01 and yfcode=a10 and zynum=@zynum and zyyzid=@zyyzid
              and yzflag=@yzflag and xmflag=6/*xmflag=6时表示临时处方*/
         and yzbegdate<=@nowdate and yzlastrundate is null and case when subyzid is null then 0 else subyzid end=@subyzid and notjzflag is null and yzstopdate is null
        order by keyno


  /*合作医疗*/
  update _zycfypk 
    set hzylflag=case when a32='1' then '允许' else null end 
    from _zycfypk (nolock),goods (nolock)
    where goodsno=a01 and userid=@userid

  update _zycfypk
    set yskscode=kscode,ysksname=ksname
    from _zycfypk (nolock),yscode (nolock)
    where yscode=code and userid=@userid


  if exists(select ybservername from unitset (nolock) where ybservername is not null)
  begin
    /*得到医保对应的编码（如果有）*/
    update _zycfypk
      set ybno=a30
      from _zycfypk (nolock),goods (nolock)
      where goodsno=a01 and userid=@userid

    /*得到医保科目*/
    update _zycfypk
      set ybkmcode=yb_goods.kmcode,
          yplb=case when yblb='1' or yblb='2' then yblb else '0' end,
          yplbname=case when yblb='1' then '甲类' when yblb='2' then '乙类' else '非甲非乙' end
      from _zycfypk (nolock),yb_goods (nolock)
      where _zycfypk.ybno=yb_goods.goodsno and userid=@userid and yb_goods.flag=0

    /*将没有对应的医保编码设置为十个9*/
    update _zycfypk
      set ybno='9999999999',yplb='0',yplbname='非甲非乙'
      where userid=@userid and (ybno is null or ybno='')

    /*将没有对应关系的编码的科目设为原科目*/
    update _zycfypk
      set ybkmcode=kmcode.ybkmcode
      from _zycfypk (nolock),kmcode (nolock)
      where kmcode=code and userid=@userid and ybno='9999999999'


  end
  /********************************************/

  /***重新对Groupkeyno赋值***/
  update _zycheck
    set groupkeyno=-keyno
    where groupkeyno is null and userid=@userid

  declare @t_oldgroupkeyno numeric(18,0)
  declare @t_ksattrib int

  declare @t_newgroupkeyno numeric(18,0)
  declare @t_newyjapplynum numeric(18,0)
  declare @t_applicationflag int
  DECLARE checkgroup_cursor CURSOR FOR
    SELECT groupkeyno,ksattrib,applicationflag FROM _zycheck (nolock) left join kscode (nolock) on fskscode=code 
      where userid=@userid
      group by groupkeyno,ksattrib,applicationflag
  OPEN checkgroup_cursor
  FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_ksattrib,@t_applicationflag
  WHILE @@FETCH_STATUS = 0
  BEGIN
    /*如果是医技科室则生成YJApplyNum,如果是电子申请单则无须更新*/
    if (@t_ksattrib=5) and (@t_applicationflag is null)
    begin
      begin transaction
        execute GetUniqueNo 20,@NewUniqueNo=@t_NewYJApplyNum output
      commit transaction
      update _zycheck
        set yjapplynum=@t_NewYJApplyNum
        where groupkeyno=@t_oldgroupkeyno and applicationflag is null
    end


    begin transaction
      execute GetUniqueNo 14,@NewUniqueNo=@t_newgroupkeyno output
    commit transaction

    update _zycheck
      set groupkeyno=@t_newgroupkeyno
      where groupkeyno=@t_oldgroupkeyno and userid=@userid

    FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_ksattrib,@t_applicationflag
  END
  CLOSE checkgroup_cursor
  DEALLOCATE checkgroup_cursor

  /*********************重新更新医保属性************************/
  if exists(select ybservername from unitset (nolock) where ybservername is not null)
  begin
    /**更新_zycheck对应的医保代码（如果有）**/
    update _zycheck
      set ybno=ybcheckcode
      from _zycheck (nolock),checkcode (nolock)

      where checkno=code and userid=@userid

    /**更新_zycheck对应的医保科目**/
    update _zycheck
      set ybkmcode=yb_checkcode.kmcode,
          checklb=case when yblb='1' or yblb='2' or yblb='3' or yblb='4' then yblb else '3' end,
          checklbname=case 
                        when yblb='1' then '甲类' 
                        when yblb='2' then '乙类' 
                        when yblb='3' then '丙类'
                        when yblb='4' then '特检特治'
                        else '丙类' 
                      end

      from _zycheck (nolock),yb_checkcode (nolock)
      where _zycheck.ybno=yb_checkcode.checkno and userid=@userid and yb_checkcode.flag=0

    /**如果没有医保对应关系做如下操作**/
    update _zycheck
      set ybno='9999999999',checklb='3',checklbname='丙类'
      where userid=@userid and (ybno is null or ybno='')
    update _zycheck
      set ybkmcode=kmcode.ybkmcode
      from _zycheck (nolock),kmcode (nolock)
      where kmcode=code and ybno='9999999999' and userid=@userid
  end
  /***********************************************/

  /*更新合作医疗标志*/
  update _zycheck
    set hzylflag=case when checkcode.hzylflag='1' then '允许' else null end
    from _zycheck (nolock),checkcode (nolock)
    where checkno=code and userid=@userid



  /*************************合法性判断***************************/
  /***判断是否有需要执行的医嘱***/
  if not exists(select yzid from _zycfypk (nolock) where userid=@userid
                union all
                select yzid from _zycheck (nolock) where userid=@userid
                union all
                select yzid from yzsheet (nolock)
                  where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid and yzflag=@yzflag
                     and ((yzstopdate is not null and yzstophscode is null) or (yzlastrundate is null and notjzflag is not null)))
    return -2



  /***判断是否有足够库存量***/
  if exists (select goodsno from _zycfypgroupview,yfstore
               where _zycfypgroupview.goodsno=yfstore.a01
               and _zycfypgroupview.yfcode=yfstore.a10
               and yfstore.a09<(_zycfypgroupview.sumypcount)
               and _zycfypgroupview.userid=@userid)
  begin
    declare @t_disptext char(100)
    DECLARE checkyfstore_cursor CURSOR FOR
      select rtrim(yfstore.a11)+'"'+rtrim(goodsname)+'"的库存为'+
             rtrim(convert(char(10),yfstore.a09))+'已不足' as disptext
        from _zycfypgroupview (nolock),yfstore (nolock)
         where _zycfypgroupview.goodsno=yfstore.a01
               and _zycfypgroupview.yfcode=yfstore.a10
               and yfstore.a09<(_zycfypgroupview.sumypcount)
               and _zycfypgroupview.userid=@userid    OPEN checkyfstore_cursor
    FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+rtrim(@t_disptext)+char(13)

      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    END
    CLOSE checkyfstore_cursor
    DEALLOCATE checkyfstore_cursor
    return 1
  end

  /***有无库存判断***/
  if exists (select goodsno from _zycfypgroupview where userid=@userid and
             goodsno not in(select a01 from yfstore,_zycfypgroupview (nolock)
                              where goodsno=a01 and yfcode=a10))
  begin
    declare @t_disptext2 char(100)
    DECLARE checkyfstore2_cursor CURSOR FOR
      select '"'+rtrim(goodsname)+'"在'+rtrim(yfname)+'药房没有库存',@userid
        from _zycfypgroupview (nolock)
        where userid=@userid and goodsno

          not in(select a01 from yfstore (nolock),_zycfypgroupview (nolock)
                   where goodsno=a01 and yfcode=a10)

    OPEN checkyfstore2_cursor
    FETCH NEXT FROM checkyfstore2_cursor into @t_disptext2
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext2+char(13)


      FETCH NEXT FROM checkyfstore_cursor into @t_disptext2
    END
    CLOSE checkyfstore2_cursor
    DEALLOCATE checkyfstore2_cursor

    return 1
  end

  return 0
end
GO
