CREATE      PROCEDURE [dbo].[MZInvoiceJS] 
/****@flag=0 结医保和自费(正常)****/
/****@flag=1 仅结自费****/
/****@flag=2 仅结医保****/

/***@mzjsflag=0 门诊程序结算***/
/***@mzjsflag=1 非门诊程序结算***/
(@opername char(10),@operdate datetime,@prnmoney numeric(12,2)=null,@todaydate datetime,@flag int,@mzjsflag int=0)
AS
begin
  declare @sumfpmoney numeric(12,2)

  if @flag=0
  begin
    if @mzjsflag=0 
    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and jfcardid is null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and jfcardid is null)
        return 1
      if exists(select fpnum from mzinvoicehis (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and jfcardid is null)
        return 1
      if exists(select invoiceoperid from Invoice_Damage where InvoiceOperID is not null and [type]=0 and OperName=@opername and jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate))
        return 1

      if @sumfpmoney is null
        select @sumfpmoney=0
      if @prnmoney is not null and @prnmoney <> @sumfpmoney
        return 2

      update mzinvoice
        set jsdate=@operdate
        where jsdate is null and opername=@opername and jfcardid is null
    end else
    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and jfcardid is not null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and jfcardid is not null)
        return 1
      if exists(select fpnum from mzinvoicehis (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and jfcardid is not null)
        return 1


      if @sumfpmoney is null
        select @sumfpmoney=0
      if @prnmoney is not null and  @prnmoney <> @sumfpmoney 
        return 2

      update mzinvoice
        set jsdate=@operdate
        where jsdate is null and opername=@opername and jfcardid is not null
    end
  end else if @flag=1
  begin
    if @mzjsflag=0    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and ybflag is null and jfcardid is null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is null and jfcardid is null)
        return 1
      if exists(select fpnum from mzinvoicehis (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is null and jfcardid is null)
        return 1

      if @prnmoney is not null and @prnmoney <> @sumfpmoney
        return 2

      update mzinvoice
        set jsdate=@operdate
      where jsdate is null and opername=@opername and ybflag is null and jfcardid is null
    end else
    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and ybflag is null and jfcardid is not null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is null and jfcardid is not null)
        return 1
      if @prnmoney is not null and @prnmoney <> @sumfpmoney
        return 2

      update mzinvoice
        set jsdate=@operdate
      where jsdate is null and opername=@opername and ybflag is null and jfcardid is not null
    end
  end else if @flag=2
  begin
    if @mzjsflag=0
    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and ybflag is not null and jfcardid is null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is not null and jfcardid is null)
        return 1
      if exists(select fpnum from mzinvoicehis (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is not null and jfcardid is null)
        return 1

      if @prnmoney is not null and @prnmoney <> @sumfpmoney
        return 2

      update mzinvoice
        set jsdate=@operdate
      where jsdate is null and opername=@opername and ybflag is not null and jfcardid is null
    end else
    begin
      select @sumfpmoney=sum(fpmoney) from mzinvoice (nolock) where jsdate is null and deldate is null and opername=@opername and ybflag is not null and jfcardid is not null
      if exists(select fpnum from mzinvoice (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is not null and jfcardid is not null)
        return 1
      if exists(select fpnum from mzinvoicehis (nolock)
              where jsdate>=@todaydate and jsdate<dateadd(day,1,@todaydate) and opername=@opername and ybflag is not null and jfcardid is not null)
        return 1

      if @prnmoney is not null and @prnmoney <> @sumfpmoney
        return 2

      update mzinvoice
        set jsdate=@operdate
      where jsdate is null and opername=@opername and ybflag is not null and jfcardid is not null
    end
  end
  
  update Invoice_Damage
    set JSDate=@operdate
    where JSDate is null and OperName=@opername and InvoiceOperID is not null and [type]=0

  /*银海医保数据表结算*/
  update yhyb_invoicebase
    set jsdate=@operdate
    where jsdate is null and fpoper=@opername and fpflag>=1 and fpflag<=6 
  update yhyb_transsheet
    set jsdate=@operdate
    where jsdate is null and arranger=@opername and fpflag>=1 and fpflag<=6 

  /*东软医保数据表结算*/
  update dryb_invoicebase
    set jsdate=@operdate
    where jsdate is null and fpoper=@opername and patientstate=1

  /*新农合数据表结算*/
  update xnh_invoicebase
    set jsdate=@operdate
    where jsdate is null and fpopername=@opername and patientstate=1

  /*异地医保数据表结算*/
  update ydyb_invoicebase
    set jsdate=@operdate
    where jsdate is null and fpopername=@opername and patientstate=1

  /*挂号明细结算*/
  update mzregistersheet
    set jsdate=@operdate
    where jsdate is null and opername=@opername 

  /*医技申请结算*/
  update yj_applysheet
    set jsdate=mzinvoice.jsdate
    from yj_applysheet,mzinvoice
    where yj_applysheet.fpnum=mzinvoice.fpnum and yj_applysheet.jsdate is null 
          and patientkind=1 and mzinvoice.opername=@opername

  return 0
end
GO
