CREATE       PROCEDURE [dbo].[ZYBRUnOut] 
(@zynum int)
AS
begin
  if exists(select m01 from mbase (nolock) where m01=@zynum and m31 is not null)
    return 1
  if exists(select m01 from mbase (nolock) where m01=@zynum and m32 is not null)
    return 2
--  if exists(select fp0 from ba_fpage (nolock) where fp0=rtrim(convert(char(20),@zynum)) and fp121_date is not null)
--    return 3

  if exists(select zynum from zyinvoicebase where zynum=@zynum and outflag=0 and deldate is null)
    return 4  --请先取消分项结算

  update mbase
    set m19=null,m20=null,m21=null,m22=null,m23=null,m24=null,m28=null
    where m01=@zynum

  return 0
end
GO
