CREATE  PROCEDURE [dbo].[ZYBRYJFP]
(@m01 int,@enddate datetime,@fpnum int,@m04 char(10),@procdate datetime,@opername char(10),@fpmoney numeric(12,2),@m26 numeric(12,2),@userid numeric(18),
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  /*其它支付金额*/
  declare @otherzfmoney numeric(12,2)
  select @otherzfmoney=sum(zfmoney) from _zyfpotherzf where userid=@userid and zynum=@m01
  if @otherzfmoney is null 
    select @otherzfmoney=0


  /*判断是否该病人已出院*/
  if exists(select m01 from mbase where m19 is not null and m01=@m01)
    return 1

  /*判断票金额是否一致*/
  declare @moneytemp numeric(12,2)

  select @moneytemp=sum(xmmoney) from
    (select ypmoney*cfcount as xmmoney from zycfypk (nolock)
      where zynum=@m01 and deldate is null and jzdate<@enddate and tyid is null and yjfpnum is null
    union all
    select ypmoney*cfcount from zycfypk (nolock)
      where zynum=@m01 and deldate is null and jzdate<@enddate and tyid is not null and ypcount>0  and yjfpnum is null
    union all
    select ypmoney*cfcount from zycfypk (nolock)
      where zynum=@m01 and deldate is null and tyid in(select tyid from zycfypk (nolock)
                                                            where zynum=@m01 and deldate is null and jzdate<@enddate and tyid is not null and ypcount>0  and yjfpnum is null)
          and ypcount<0
    union all
    select checkmoney from zycheck (nolock)
      where zynum=@m01 and deldate is null and tfkeyno is null and jzdate<@enddate and yjfpnum is null) disp

  if @moneytemp is null 
    select @moneytemp=0  
  if @moneytemp <> @fpmoney
    return 2

  /*判断交退款是否一致*/
  declare @yjmoneytemp numeric(12,2),@jtmoneytemp numeric(12,2)
  select @yjmoneytemp=case when m27 is not null then m27 else 0 end+case when m50 is not null then m50 else 0 end-case when m33 is not null then m33 else 0 end
    from mbase where m01=@m01
  select @jtmoneytemp=-(@yjmoneytemp+@otherzfmoney-@moneytemp)
  /*交退款不一致*/
  if @m26 <> @jtmoneytemp
    return 3
    
  declare @t_curnum int
  if @InvoiceNum is not null
  begin
    select @t_curnum=isnull(curnum+1,BegNum) from Invoice_Operator where invoiceoperid=@InvoiceOperID and backflag is null and [TYPE]=1
    if convert(int,@InvoiceNum) <> @t_curnum
      return 6  --保存时发现当前号已被使用
    if @t_curnum is null 
      return 7  --发票号异常
  end

  if exists(select InvoiceMangFlag from unitset where InvoiceMangFlag=1 or InvoiceMangFlag=2) and (@InvoiceNum is null or RTRIM(@InvoiceNum)='' or @InvoiceOperID is null or @InvoiceOperID=0)
    return 8 --启用发票管理后发票号不能空且批次号不能空

  update zycfinf 
    set yjfpnum=@fpnum,fpdate=@procdate
    where zynum=@m01 and yjfpnum is null and jzdate<@enddate and deldate is null
  update zycfypk
    set yjfpnum=@fpnum,fpdate=@procdate
    where zynum=@m01 and yjfpnum is null and jzdate<@enddate and deldate is null
  update zycheck
    set yjfpnum=@fpnum,fpdate=@procdate
    where zynum=@m01 and yjfpnum is null and jzdate<@enddate and deldate is null

  update zycfypk
    set yjfpnum=@fpnum,fpdate=@procdate
    where zynum=@m01 and tyid in(select tyid from zycfypk (nolock) where zynum=@m01 and yjfpnum=@fpnum and tyid is not null)
          and ypcount<0 and yjfpnum is null

  update zycheck
    set yjfpnum=@fpnum,fpdate=@procdate
    where zynum=@m01 and tfkeyno in(select tfkeyno from zycheck (nolock) where zynum=@m01 and yjfpnum=@fpnum and tfkeyno is not null)
         and checkcount<0 and yjfpnum is null

  select kmcode,kmname,sum(kmmoney) as kmmoney into #zyfpinvoice
    from nowzykmview
    where zynum=@m01 and yjfpnum=@fpnum
    group by kmcode,kmname


  insert zyinvoice(zynum,zyname,kmcode,kmname,kmmoney,fpdate,fpoper,fpnum,enddate)
    select @m01,@m04,kmcode,kmname,kmmoney,@procdate,@opername,@fpnum,dateadd(day,-1,@enddate)
      from #zyfpinvoice

  declare @t_zydays int
  declare @t_begdate datetime
  select @t_begdate=max(enddate) from ZYINVOICEBASE where zynum=@m01 and deldate is null and outflag is null
  if @t_begdate is null
    select @t_begdate=m11 from MBASE (nolock) where M01=@m01

  select @t_zydays=DATEDIFF(day,@t_begdate,dateadd(day,-1,@enddate))
  if @t_zydays=0 
    select @t_zydays=1

  insert zyinvoicebase(FPNUM,ZYNUM,FPDATE,ENDDATE,FPOPER,FPMONEY,OUTFLAG,DELDATE,PREMONEY,JTMONEY,JSDATE,JSOPER,DELOPER,JTFLAG,OTHERZFMONEY,YLDYName,InvoiceNum,InvoiceOperID,ZYDays)
    select @fpnum,@m01,@procdate,dateadd(day,-1,@enddate),@opername,@moneytemp,null,null,@yjmoneytemp,@jtmoneytemp,null,null,null,'现金',@otherzfmoney,m02,@InvoiceNum,@InvoiceOperID,@t_zydays
      from mbase 
      where m01=@m01
  
  if @InvoiceNum is not null
  begin
    update invoice_operator
      set curnum=@t_curnum
      where invoiceoperid=@InvoiceOperID
  end
  
  update mbase 
    set m33=m33+@moneytemp,m27=m27+@jtmoneytemp,m50=case when m50 is not null then m50 else 0 end+@otherzfmoney
    where m01=@m01
  update prepay
    set fpnum=@fpnum,InvoiceNum_FP=@InvoiceNum,InvoiceOperID_FP=@InvoiceOperID
    where p01=@m01 and fpnum is null

  /*现金支付*/
  insert prepay(p01,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
    select m01,m04,@procdate,@opername,'预结补退',@jtmoneytemp,'现金',2,@fpnum,@InvoiceNum,@InvoiceOperID
      from mbase where m01=@m01

  /*其它补退款*/
  insert prepay(p01,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
    select @m01,@m04,@procdate,@opername,'预结算时其它方式支付款',zfmoney,zffs,2,@fpnum,@InvoiceNum,@InvoiceOperID
      from _zyfpotherzf where userid=@userid and zynum=@m01
  return 0
end
GO
