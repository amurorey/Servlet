CREATE PROCEDURE [dbo].[GetCurrentDate]
(@CurDate datetime output)
AS
  select @CurDate=getdate()
GO
