-- =============================================
-- Author:LanYuzhi
-- Create date:2014-6-24
-- Description:	校验影像系统的电子申请单记账情况
-- =============================================
CREATE PROCEDURE [dbo].[CheckPacs]
(@ZYNum varchar(20), @ServerName varchar(40), @UserID varchar(20), @Password varchar(20))
AS
begin
  SET ANSI_WARNINGS on
  SET ANSI_NULLS on
  declare @t_Str nvarchar(2048)
  
  select @t_Str='select applyfromhis,bodypartexamined,inpatientnum,a.patientname,a.patientarriveddate,a.applyusername,a.clinicname,b.applydate,b.ysksname,b.ysname,b.checkmoney,'+
                ' case when a.reportdate is null and b.jzdate is not null then ''已记账检查未做'' when a.reportdate is not null and b.jzdate is null then ''检查已做未记账'' end as disp' +
                '  from OPENDATASOURCE(''SQLOLEDB'', ''Data Source='+@ServerName+';User ID='+@UserID+';Password='+@Password+''').dicomserver.dbo.patientschedule a,patient_applicationsheet b (nolock)'+
                '  where a.applyfromhis=b.applynum and a.inpatientnum='''+@ZYNum+''''+
                '  and a.deldate is null and b.deldate is null'+
                '  and ((a.reportdate is null and b.jzdate is not null) or (a.reportdate is not null and b.jzdate is null))'
                
  exec sp_executesql @t_Str
end
GO
