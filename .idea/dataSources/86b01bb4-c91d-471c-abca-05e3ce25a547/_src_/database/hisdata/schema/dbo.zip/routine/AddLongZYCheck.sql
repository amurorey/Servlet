CREATE    PROCEDURE [dbo].[AddLongZYCheck]
(@zynum int,@userid numeric,@opername char(10),@operdate datetime,@qfsetflag int,@operkscode char(4),@operksname char(10))
AS
begin
   if exists(select zynum from zycheck (nolock) where zynum=@zynum and datename(yy,jzdate)=datename(yy,@operdate) and datename(mm,jzdate)=datename(mm,@operdate)
              and datename(dd,jzdate)=datename(dd,@operdate) and yzflag=1 and yzid is null)
    return -1

  /*update longzycheck*/
  update longzycheck
    set kmcode=checkcode.kmcode,kmname=checkcode.kmname,
        unitname=checkcode.unitname
    from longzycheck,checkcode
    where checkno=code and zynum=@zynum

  update longzycheck
   set checkprice=price,checkmoney=price*checkcount
   from longzycheck,checkcode
   where checkno=code and zynum=@zynum and checkprice>maxprice and standflag=1

  /*更新groupkeyno*/
  update longzycheck
    set groupkeyno=-keyno
    where zynum=@zynum and groupkeyno is null

  declare @t_newgroupkeyno numeric(18)
  declare @t_groupkeyno numeric(18)
  DECLARE longzycheck_cursor CURSOR FOR
    select groupkeyno from longzycheck
       where zynum=@zynum
       group by groupkeyno  
  OPEN longzycheck_cursor
  FETCH NEXT FROM longzycheck_cursor into @t_groupkeyno
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 14,@NewUniqueNo=@t_newgroupkeyno output

    update longzycheck
      set groupkeyno=@t_newgroupkeyno
      where groupkeyno=@t_groupkeyno

    FETCH NEXT FROM longzycheck_cursor into @t_groupkeyno
  END
  CLOSE longzycheck_cursor
  DEALLOCATE longzycheck_cursor


  /***Insert into _zycheck table***/
  delete _zycheck where userid=@userid
  insert _zycheck(CHECKNO,CHECKPRICE,CHECKCOUNT,CHECKMONEY,CHECKNAME,
                  KMNAME,KMCODE,YSCODE,YSNAME,YSKSCODE,YSKSNAME,CHECKLB,CHECKLBNAME,
                  UNITNAME,FSKSCODE,FSKSNAME,HSFLAG,
                  groupcode,groupname,groupprice,groupcount,groupkeyno,PROCDATE,USERID)
    select CHECKNO,CHECKPRICE,CHECKCOUNT,CHECKMONEY,CHECKNAME,
           KMNAME,KMCODE,YSCODE,YSNAME,YSKSCODE,YSKSNAME,CHECKLB,CHECKLBNAME,
           UNITNAME,FSKSCODE,FSKSNAME,HSFLAG,
           groupcode,groupname,groupprice,groupcount,groupkeyno,@operdate,@userid
      from longzycheck (nolock)
      where zynum=@zynum
      order by keyno

  declare @ret int
  exec @ret=addzycheck @zynum,@opername,@operdate,@userid,null,@qfsetflag,@operkscode,@operksname,1
  if @ret=0
  begin
    update longzycheck
      set lastprocdate=@operdate where zynum=@zynum
  end

  delete _zycheck where userid=@userid
  return @ret
end
GO
