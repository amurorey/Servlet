CREATE PROCEDURE [dbo].[DispCYBRFY] 
(@begdate datetime,@enddate datetime,@flag int=0,@dyflag char(10))
AS
begin
  if @flag=0
  begin
    select m20 as cykscode,m21 as cyksname,zynum,kmcode,kmname,sum(checkmoney) as kmmoney  into #cybrfy1 
      from zycheck,mbase (nolock) 
        where zynum=m01 and deldate is null and m30>=@begdate and m30<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21,zynum,kmcode,kmname,sum(ypmoney)
      from zycfypk,mbase (nolock) 
        where zynum=m01 and deldate is null and m30>=@begdate and m30<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21 as cyksname,zynum,kmcode,kmname,sum(checkmoney) as kmmoney
      from zycheckhis,mbase (nolock) 
        where zynum=m01 and deldate is null and m30>=@begdate and m30<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21,zynum,kmcode,kmname,sum(ypmoney)
      from zycfypkhis,mbase (nolock) 
        where zynum=m01 and deldate is null and m30>=@begdate and m30<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname

    select cykscode,cyksname,zynum,kmcode,kmname,sum(kmmoney) as kmmoney 
      from #cybrfy1,kmcode 
        where code=kmcode 
      group by cykscode,cyksname,zynum,kmcode,kmname
      order by cykscode,cyksname,zynum,kmcode,kmname
  end else if @flag=1 
  begin
    select m20 as cykscode,m21 as cyksname,zynum,kmcode,kmname,sum(checkmoney) as kmmoney  into #cybrfy2 
      from zycheck,mbase (nolock) 
        where zynum=m01 and deldate is null and m31>=@begdate and m31<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21,zynum,kmcode,kmname,sum(ypmoney)
      from zycfypk,mbase (nolock) 
        where zynum=m01 and deldate is null and m31>=@begdate and m31<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21 as cyksname,zynum,kmcode,kmname,sum(checkmoney) as kmmoney
      from zycheckhis,mbase (nolock) 
        where zynum=m01 and deldate is null and m31>=@begdate and m31<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname
    union all
    select m20,m21,zynum,kmcode,kmname,sum(ypmoney)
      from zycfypkhis,mbase (nolock) 
        where zynum=m01 and deldate is null and m31>=@begdate and m31<@enddate and m02=@dyflag
      group by m20,m21,zynum,kmcode,kmname

    select cykscode,cyksname,zynum,kmcode,kmname,sum(kmmoney) as kmmoney 
      from #cybrfy2,kmcode 
        where code=kmcode 
      group by cykscode,cyksname,zynum,kmcode,kmname
      order by cykscode,cyksname,zynum,kmcode,kmname
  end
end
GO
