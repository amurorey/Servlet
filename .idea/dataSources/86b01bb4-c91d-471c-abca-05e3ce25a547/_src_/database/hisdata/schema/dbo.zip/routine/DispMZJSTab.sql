CREATE PROCEDURE [dbo].[DispMZJSTab] 
(@begdate datetime,@enddate datetime,@sumflag int,@flag int)
AS
begin
  select mzinvoice.jsdate,opername,kmcode,kmname,ypmoney*cfcount as kmmoney,mzcfypk.deldate,mzinvoice.ybflag
    into #dispmzjstab
    from mzcfypk,mzinvoice (nolock) 
    where mzcfypk.fpnum=mzinvoice.fpnum and mzinvoice.jsdate>=@begdate and mzinvoice.jsdate<@enddate
  union all
  select mzinvoicehis.jsdate,opername,kmcode,kmname,ypmoney*cfcount,mzcfypkhis.deldate,mzinvoicehis.ybflag
    from mzcfypkhis (nolock),mzinvoicehis
    where mzinvoicehis.fpnum=mzcfypkhis.fpnum and mzinvoicehis.jsdate>=@begdate and mzinvoicehis.jsdate<@enddate
  union all
  select mzinvoice.jsdate,opername,kmcode,kmname,checkmoney,mzcheck.deldate,mzinvoice.ybflag
    from mzcheck,mzinvoice (nolock) 
    where mzcheck.fpnum=mzinvoice.fpnum and mzinvoice.jsdate>=@begdate and mzinvoice.jsdate<@enddate
  union all
  select mzinvoicehis.jsdate,opername,kmcode,kmname,checkmoney,mzcheckhis.deldate,mzinvoicehis.ybflag
    from mzcheckhis,mzinvoicehis (nolock) 
    where mzcheckhis.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate>=@begdate and mzinvoicehis.jsdate<@enddate
  
  select opername,deldate,fpmoney,ybflag into #dispmzfptab
    from mzinvoice (nolock) where jsdate>=@begdate and jsdate<@enddate
  union all
  select opername,deldate,fpmoney,ybflag
    from mzinvoicehis (nolock) where jsdate>=@begdate and jsdate<@enddate


  if @flag=0
  begin
    if @sumflag=0
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null
        group by all opername,code,name
    else if @sumflag=1
      select code,name,sum(kmmoney) as kmmoney from #dispmzjstab,kmcode
        where kmcode=code and deldate is null
        group by all code,name
    else if @sumflag=2
      select opername,
        sum(case when deldate is null then 1 else 0 end) as yxfp,
        sum(case when deldate is not null then 1 else 0 end) as wxfp
        from #dispmzfptab 
        group by all opername
    else if @sumflag=3
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null
        group by all code,name,opername
    else if @sumflag=4
      select opername,
        sum(fpmoney) as fpmoney,
        sum(case when ybflag is null then fpmoney else 0 end) as xjmoney,
        sum(case when ybflag is not null then fpmoney else 0 end) as ybmoney
      from #dispmzfptab where deldate is null
      group by all opername
  end else if @flag=1
  begin
    if @sumflag=0
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is null
        group by all opername,code,name
    else if @sumflag=1
      select code,name,sum(kmmoney) as kmmoney from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is null
        group by all code,name
    else if @sumflag=2
      select opername,
        sum(case when deldate is null then 1 else 0 end) as yxfp,
        sum(case when deldate is not null then 1 else 0 end) as wxfp
        from #dispmzfptab
        where ybflag is null
        group by all opername
    else if @sumflag=3
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is null
        group by all code,name,opername
    else if @sumflag=4
      select opername,
        sum(fpmoney) as fpmoney,
        sum(case when ybflag is null then fpmoney else 0 end) as xjmoney,
        sum(case when ybflag is not null then fpmoney else 0 end) as ybmoney
      from #dispmzfptab where deldate is null and ybflag is null
      group by opername
  end else if @flag=2
  begin
    if @sumflag=0
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is not null
        group by all opername,code,name
    else if @sumflag=1
      select code,name,sum(kmmoney) as kmmoney from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is not null
        group by all code,name
    else if @sumflag=2
      select opername,
        sum(case when deldate is null then 1 else 0 end) as yxfp,
        sum(case when deldate is not null then 1 else 0 end) as wxfp
        from #dispmzfptab
        where ybflag is not null
        group by all opername
    else if @sumflag=3
      select code,name, opername,
        sum(kmmoney) as kmmoney
        from #dispmzjstab,kmcode
        where kmcode=code and deldate is null and ybflag is not null
        group by all code,name,opername
    else if @sumflag=4
      select opername,
        sum(fpmoney) as fpmoney,
        sum(case when ybflag is null then fpmoney else 0 end) as xjmoney,
        sum(case when ybflag is not null then fpmoney else 0 end) as ybmoney
      from #dispmzfptab where deldate is null and ybflag is not null
      group by all opername
  end
end
GO
