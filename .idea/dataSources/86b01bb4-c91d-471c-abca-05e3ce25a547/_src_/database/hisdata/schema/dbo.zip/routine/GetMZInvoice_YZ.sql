CREATE        PROCEDURE [dbo].[GetMZInvoice_YZ]
(@MZNum int,@userid numeric)
as
begin
  declare @t_keyno1 numeric(18,0)
  declare @t_keyno2 numeric(18,0)
  select @t_keyno1=count(*) from mzcfinf_yz where mznum=@mznum and mzoper is null
  select @t_keyno2=count(*) from patient_applicationsheet where mznum=@mznum and jzoper is null

  if @t_keyno1=0 and @t_keyno2=0 
    return -1  --无任何记录  


  delete _mzcfinf where userid=@userid
  delete _mzcfypk where userid=@userid
  delete _MZCheck_Inf where UserID=@userid
  delete _mzcheck where userid=@userid

  insert _mzcfinf(CFNUM,YSCODE,YSNAME,CFFLAG,CFPRICE,CFCOUNT,CFMONEY,YFCODE,YFNAME,YSKSCODE,YSKSNAME,USERID,PROCDATE,yzflag)
    select cfnum,yscode,ysname,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,yskscode,ysksname,@userid,getdate(),1
      from mzcfinf_yz (nolock)
      where mznum=@mznum and mzoper is null and cfnum in(select applynum from _selmzyz (nolock) where userid=@userid and selected=1 and Flag=0)
      order by cfnum

  insert _mzcfypk(CFNUM,GOODSNO,YPCOUNT,YPPRICE,YPPRICE_1,YPMONEY,CFCOUNT,GOODSNAME,PROCNAME,UNITNAME,
                  YFCODE,YFNAME,KMCODE,KMNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
                  USERID,PROCDATE,YBLB,YBLBNAME,YBNO,YBKMCODE,yzflag,YZID,YPPath)
    select mzcfypk_yz.cfnum,goodsno,round(totcount+0.4,0),ypprice,ypprice_1,ypmoney,mzcfypk_yz.cfcount,goodsname,procname,unitname,
           mzcfypk_yz.yfcode,mzcfypk_yz.yfname,kmcode,kmname,yzyscode,yzysname,yzyskscode,yzysksname,
           @userid,getdate(),yblb,yblbname,'','',1,YZID,YPPath
      from mzcfypk_yz (nolock),mzcfinf_yz (nolock)
      where mzcfypk_yz.cfnum=mzcfinf_yz.cfnum and mzcfinf_yz.mznum=@mznum 
         and mzoper is null and mzcfinf_yz.cfnum in(select applynum from _selmzyz (nolock) where userid=@userid and selected=1 and Flag=0)
      order by keyno

  update _mzcfypk
    set goodsname=a07,yblb=a24,yblbname=a24,ybno=a30,jbypflag=a37
    from _mzcfypk,goods
    where a01=goodsno and _mzcfypk.userid=@userid
   
  insert _MZCheck_Inf(YJApplyNum,YSKSCode,YSKSName,YSCode,YSName,FSKSCode,FSKSName,ApplyDate,ApplicationName,PriceFlag,UserID,procdate)
    select applynum,YSKSCODE,YSKSNAME,YSCode,YSName,FSKSCODE,FSKSNAME,APPLYDATE,ApplicationName,priceflag,@userid,GETDATE()
      from Patient_ApplicationSheet (nolock)
      where APPLYNUM in(select applynum from _selmzyz (nolock) where userid=@userid and selected=1 and Flag=1)
           
  insert _mzcheck(CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,CHECKCOUNT,CHECKMONEY,YSCODE,YSNAME,KMNAME,KMCODE,YSKSCODE,YSKSNAME,
                  USERID,PROCDATE,FSKSCODE,FSKSNAME,CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,GROUPKEYNO,
                  YBNO,YBKMCODE,YJApplyNum,yzflag,APPLICATIONCODE,APPLICATIONNAME,samplecode,sampletype,emergency_flag)
    select checkno,checkname,unitname,checkprice,checkcount,patient_applicationcheckcode.checkmoney,yscode,ysname,kmname,kmcode,yskscode,ysksname,
           @userid,getdate(),patient_applicationcheckcode.fskscode,patient_applicationcheckcode.fsksname,checklb,checklbname,groupcode,groupname,groupprice,groupcount,newgroupkeyno,
           ybno,ybkmcode,patient_applicationcheckcode.applynum,1,patient_applicationsheet.APPLICATIONCODE,patient_applicationsheet.APPLICATIONNAME,samplecode,sampletype,patient_applicationsheet.emergency_flag
      from patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and Patient_ApplicationCheckCode.CHECKNO is not null and jzoper is null and patient_applicationcheckcode.mznum=@mznum 
           and patient_applicationsheet.applynum in(select applynum from _selmzyz (nolock) where userid=@userid and selected=1 and Flag=1)

  delete _selmzyz where userid=@userid

  return 0
end
GO
