CREATE  PROCEDURE [dbo].[GetCustNo]
(@storecode char(2),@CustNo char(10) output)
AS
begin
  /*Attention:This no is from ykcode table*/
  declare @NewUniqueNo int

  update ykcode set CustNo=case when CustNo is null then 0 else CustNo end+1 where ykcode=@storecode
  select @NewUniqueNo=CustNo from ykcode where ykcode=@storecode

  if @NewUniqueNo < 10 
    set @CustNo='000000000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=10 and @NewUniqueNo <100 
    set @CustNo='00000000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=100 and @NewUniqueNo <= 1000
    set @CustNo='0000000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=1000 and @NewUniqueNo < 10000
    set @CustNo='000000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=10000 and @NewUniqueNo < 100000
    set @CustNo='00000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=100000 and @NewUniqueNo < 1000000
    set @CustNo='0000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=1000000 and @NewUniqueNo < 10000000
    set @CustNo='000'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=10000000 and @NewUniqueNo < 100000000
    set @CustNo='00'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=100000000 and @NewUniqueNo < 1000000000
    set @CustNo='0'+rtrim(convert(char(10),@NewUniqueNo))
  else if @NewUniqueNo >=1000000000 and @NewUniqueNo < 10000000000
    set @CustNo=rtrim(convert(char(10),@NewUniqueNo))
end
GO
