


CREATE VIEW SumOutStockView AS
select c05,goodsid,sum(c17) as sumc17 from outstock (nolock) group by c05,goodsid


GO
