CREATE PROCEDURE [dbo].[SaveYFStart] 
(@goodsno char(10),@goodsname varchar(40),@procname varchar(10),@unitname char(4),
 @ypcount int,@ypprice1 money,@ypprice2 money,@yfcode char(3),@yfname char(10),@opername char(10))
AS
/*if exists(select goodsno from yfstart where goodsno=@goodsno group by goodsno having sum(ypcount)<@ypcount)
  return 1*/

insert yfstart
  values(@goodsno,@goodsname,@procname,@unitname,@ypcount,@ypprice1,@ypprice2,@ypprice1*@ypcount,@ypprice2*@ypcount,
         @opername,getdate(),@yfcode,@yfname)
if not exists(select a01 from yfstore where a01=@goodsno and a10=@yfcode)
  insert yfstore(a01,a02,a03,a04,a05,a06,a07,a08,a09,a10,a11,a12,a13,a14,a15,a16)
    select a01,a07,a02,a03,a08,a12,@ypprice1,@ypprice2,@ypcount,@yfcode,@yfname,a14,a15,@ypcount,0,0
    from goods where a01=@goodsno
else
  update yfstore
    set a09=a09+@ypcount,a14=a14+@ypcount
    where a01=@goodsno and a10=@yfcode
return 0
GO
