CREATE   PROCEDURE [dbo].[MZFYProc]
(@fpnum int,@cfnum int,@opername char(10)='',@yfcode char(3),@yfname char(20),@userid int,@retval varchar(256)=null output)
AS
begin
  declare @currentdate datetime
  select @currentdate=getdate()

  declare @mzmoreyfset int
  select @mzmoreyfset=mzmoreyfset from unitset

  /*在未结算库和已结算库中判断*/
  if exists(select cfnum from mzcfinf where cfnum=@cfnum and fpnum=@fpnum) 
  begin
    if exists(select cfnum from mzcfinf where cfnum=@cfnum and fpnum=@fpnum and fydate is not null)
      return 1
    if exists(select cfnum from mzcfypk where cfnum=@cfnum and fpnum=@fpnum and deldate is not null)
      return 2
    if exists(select yfcode from mzcfinf where cfnum=@cfnum and fpnum=@fpnum and yfcode<> '' and yfcode<>@yfcode)
      return 3

    /***Compute the count of this CF***/
    select @yfcode as yfcode,fpnum,goodsno,goodsname,sum(ypcount*cfcount) as sumypcount 
      into #cfypcount
      from mzcfypk
      where cfnum=@cfnum and fpnum=@fpnum
      group by yfcode,fpnum,goodsno,goodsname

    /*如果划价时不判断库存则现在判断该药房是否有足够库存*/
    if @mzmoreyfset=1  
    begin
      /***库存不足判断***/
      if exists (select * from #cfypcount,yfstore
                   where goodsno=yfstore.a01
                   and a10=@yfcode
                   and a09<sumypcount)
      begin
          delete _checkyfstore where userid=@userid
          insert _checkyfstore
          select '"'+a02+'"的现有库存为:'+rtrim(convert(char(10),a09))+',已不足!',@userid from #cfypcount,yfstore
                   where goodsno=a01
                   and a10=@yfcode
                   and a09<sumypcount
        return 4
      end

      /***有无库存判断***/
      if exists (select goodsno from #cfypcount where goodsno not in(select a01 from yfstore,#cfypcount (nolock) where goodsno=a01 and yfcode=a10))
      begin
        declare @t_disptext char(100)
        DECLARE checkyfstore_cursor CURSOR FOR
          select '"'+rtrim(goodsname)+'"在药房没有库存' as disptext from #cfypcount where goodsno not in(select a01 from yfstore,#cfypcount (nolock) where goodsno=a01 and yfcode=a10)
        OPEN checkyfstore_cursor
        FETCH NEXT FROM checkyfstore_cursor into @t_disptext
        WHILE @@FETCH_STATUS = 0
        BEGIN
          select @retval=@retval+@t_disptext+char(13)

          FETCH NEXT FROM checkyfstore_cursor into @t_disptext
        END
        CLOSE checkyfstore_cursor
        DEALLOCATE checkyfstore_cursor

        return 4
      end
    end

    update mzcfinf
      set fydate=@currentdate,
          fyopername=@opername,
          yfcode=@yfcode,yfname=@yfname
    where cfnum=@cfnum and fpnum=@fpnum
    update mzcfypk
      set fydate=@currentdate,yfcode=@yfcode
    where cfnum=@cfnum and fpnum=@fpnum


    /*判断是否是门诊划价时不判断库存方式 1:是 如果是则发药时下库存*/
    if @mzmoreyfset<>1  
    begin
      update yfstore
        set a16=a16-sumypcount
      from yfstore,#cfypcount
      where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10
    end else
    begin
      update yfstore
        set a09=a09-sumypcount,a15=a15+sumypcount
      from yfstore,#cfypcount
      where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10


      insert mzchangeprice
         select mzcfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,-ypcount,(a08-ypprice)*(-ypcount)*cfcount,
                (a07-ypprice_1)*(-ypcount)*cfcount,@opername,
           '划价时价差',a10,a11 
         from yfstore,mzcfypk
         where a01=mzcfypk.goodsno and mzcfypk.yfcode=a10 and
                   (mzcfypk.ypprice<>a08 or mzcfypk.ypprice_1<>a07) and mzcfypk.cfnum=@cfnum and fpnum=@fpnum
    end
  end else
  begin
    if exists(select cfnum from mzcfinfhis where cfnum=@cfnum and fpnum=@fpnum and fydate is not null)
      return 1
    if exists(select cfnum from mzcfypkhis where cfnum=@cfnum and fpnum=@fpnum and deldate is not null)
      return 2

    /***Compute the count of this CF***/
    select @yfcode as yfcode,fpnum,goodsno,goodsname,sum(ypcount*cfcount) as sumypcount 
      into #cfypcounthis
      from mzcfypkhis
      where cfnum=@cfnum and fpnum=@fpnum
      group by yfcode,fpnum,goodsno,goodsname

    /*如果划价时不判断库存则现在判断该药房是否有足够库存*/
    if @mzmoreyfset=1  
    begin
      /***库存不足时判断***/
      if exists (select * from #cfypcounthis,yfstore
                   where goodsno=yfstore.a01
                   and a10=@yfcode
                   and a09<sumypcount)
      begin
          delete _checkyfstore where userid=@userid
          insert _checkyfstore
          select '"'+a02+'"的现有库存为:'+rtrim(convert(char(10),a09))+',已不足!',@userid from #cfypcounthis,yfstore
                   where goodsno=a01
                   and a10=@yfcode
                   and a09<sumypcount
        return 4
      end

      /***有无库存判断***/
      if exists (select goodsno from #cfypcounthis where goodsno not in(select a01 from yfstore,#cfypcounthis (nolock) where goodsno=a01 and yfcode=a10))
      begin
        delete _checkyfstore where userid=@userid
        insert _checkyfstore
          select '"'+rtrim(goodsname)+'"在药房没有库存',@userid from #cfypcounthis where goodsno not in(select a01 from yfstore,#cfypcounthis (nolock) where goodsno=a01 and yfcode=a10)
        return 4
      end
    end

    update mzcfinfhis
      set fydate=@currentdate,
          fyopername=@opername,
          yfcode=@yfcode,yfname=@yfname
    where cfnum=@cfnum and fpnum=@fpnum
 
    update mzcfypkhis
      set fydate=@currentdate,yfcode=@yfcode
    where cfnum=@cfnum and fpnum=@fpnum

    /*判断是否是门诊划价时不判断库存方式 1:是 如果是则发药时下库存*/
    if @mzmoreyfset<>1  
    begin
      update yfstore
        set a16=a16-sumypcount
      from yfstore,#cfypcounthis
      where #cfypcounthis.goodsno=a01 and #cfypcounthis.yfcode=a10
    end else
    begin
      update yfstore
        set a09=a09-sumypcount,a15=a15+sumypcount
      from yfstore,#cfypcounthis
      where #cfypcounthis.goodsno=a01 and #cfypcounthis.yfcode=a10

      insert mzchangeprice
         select mzcfypkhis.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,-ypcount,(a08-ypprice)*(-ypcount)*cfcount,
                (a07-ypprice_1)*(-ypcount)*cfcount,@opername,
           '划价时价差',a10,a11 
         from yfstore,mzcfypkhis
         where a01=mzcfypkhis.goodsno and mzcfypkhis.yfcode=a10 and
                   (mzcfypkhis.ypprice<>a08 or mzcfypkhis.ypprice_1<>a07) and mzcfypkhis.cfnum=@cfnum and mzcfypkhis.fpnum=@fpnum
    end
  end

  delete mzyflinebase where fpnum=@fpnum and yfcode=@yfcode

  return 0
end
GO
