/****德宏模式****/
CREATE      PROCEDURE [dbo].[ZYRBJS_All] 
(@rjendtime datetime)
AS
begin  
  if exists(select p01 from prepay where convert(char(12),p09,1)=convert(char(12),getdate(),1))
    return 1
  if exists(select p01 from prepayhis where convert(char(12),p09,1)=convert(char(12),getdate(),1))
    return 1
  if getdate()<@rjendtime 
    return 2
  
  update mbase
    set m31=@rjendtime
    where m30 is not null and m31 is null and m30<=@rjendtime
  
  update prepay
    set p09=@rjendtime
    where p09 is null and p04<=@rjendtime

  update prepayhis
    set p09=@rjendtime
    where p09 is null and p04<=@rjendtime


  update zycheck
    set jsdate=@rjendtime
    from zycheck,zyinvoicebase
    where zycheck.yjfpnum=zyinvoicebase.fpnum and zycheck.deldate=null
      and zyinvoicebase.jsdate=null and zyinvoicebase.fpdate<=@rjendtime

  update zycfypk
    set jsdate=@rjendtime
    from zycfypk,zyinvoicebase
    where zycfypk.yjfpnum=zyinvoicebase.fpnum and zycfypk.deldate=null
      and zyinvoicebase.jsdate=null and zyinvoicebase.fpdate<=@rjendtime

  update zyinvoicebase
    set jsdate=@rjendtime,jsoper=fpoper
    where jsdate is null and fpdate<=@rjendtime
  update zyinvoice
    set jsdate=@rjendtime,jsoper=fpoper
    where jsdate is null and fpdate<=@rjendtime

  update yb_zyinvoice
    set jsdate=@rjendtime,jsoper=fpoper
    where jsdate is null and fpdate<=@rjendtime


  update yj_applysheet
    set jsdate=zyinvoicebase.jsdate
    from yj_applysheet,zyinvoicebase
    where yj_applysheet.fpnum=zyinvoicebase.fpnum and yj_applysheet.jsdate is null  and yj_applysheet.fpdate<=@rjendtime
          and patientkind=2

  /*东软医保数据表结算*/
  update dryb_invoicebase
    set jsdate=@rjendtime
    where jsdate is null and fpdate<=@rjendtime and patientstate=2

  /*东软医保数据表结算*/
  update ydyb_invoicebase
    set jsdate=@rjendtime
    where jsdate is null and fpdate<=@rjendtime and patientstate=2

  /*新农合数据表结算*/
  update xnh_invoicebase
    set jsdate=@rjendtime
    where jsdate is null and fpdate<=@rjendtime and patientstate=2

  /*强制出院*/
  update zycheck
    set jsdate=@rjendtime
    from zycheck,mbase
    where zynum=m01 and jsdate=null and yjfpnum=null
      and m19 is not null and m28=1 and m31 is null and m19<=@rjendtime

  update zycfypk
    set jsdate=@rjendtime
    from zycfypk,mbase
    where zynum=m01 and jsdate=null and yjfpnum=null
      and m19 is not null and m28=1 and m31 is null and m19<=@rjendtime

  update mbase
    set m31=@rjendtime
    where m19 is not null and m28=1 and m31 is null and m19<=@rjendtime

  return 0
end
GO
