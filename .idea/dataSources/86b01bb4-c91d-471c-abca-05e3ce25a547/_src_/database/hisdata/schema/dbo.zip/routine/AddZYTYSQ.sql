CREATE     PROCEDURE [dbo].[AddZYTYSQ]
(@keyno numeric(18),@opername char(10),@sqdate datetime,@tyid numeric(18) output,@tycount int)
AS
begin
  /*如果已做出院申请则退出*/
  if exists(select m01 from mbase,zycfypk (nolock) where m01=zynum and keyno=@keyno and m19 is not null)
    return 1
  
  declare @t_tyid numeric(18)
  declare @t_sycount int  /*该条记录的实有数量*/
  select @t_tyid=tyid,@t_sycount=ypcount*cfcount-(case when tycount is null then 0 else tycount end) from zycfypk (nolock) where keyno=@keyno

  /*开单药品数量已等于已退药品数量则退出*/
  if @tycount>@t_sycount
    return 2

  --已做过结算处理，不能退药
  if exists(select zynum from zycfypk (nolock) where keyno=@keyno and yjfpnum is not null)
    return 3  
  

  if @t_tyid is null 
  begin
    execute GetUniqueNo 17,@NewUniqueNo=@t_tyid output
    update zycfypk 
      set tyid=@t_tyid 
      where keyno=@keyno
  end  

  if not exists(select keyno from zytysq (nolock) where tyid=@t_tyid and yfcheckokdate is null)
  begin
    insert zytysq(ZYNUM,GOODSNO,GOODSNAME,UNITNAME,PROCNAME,YPPRICE,YPPRICE_1,
                  YPCOUNT,YPMONEY,YFCODE,YFNAME,FSKSCODE,FSKSNAME,YSCODE,YSNAME,
                  YSKSCODE,YSKSNAME,KMCODE,KMNAME,LYKSCODE,LYKSNAME,YPLB,YPLBNAME,
                  SQDATE,SQOPERNAME,YFCHECKOKOPER,YFCHECKOKDATE,TYCFNUM,TYID,JZDATE,YBNO,YBKMCODE,zgysname,yzid)
      select zynum,goodsno,goodsname,unitname,procname,ypprice,ypprice_1,
             @tycount,round(ypprice*@tycount,2),yfcode,yfname,operkscode,operksname,yscode,ysname,
             yskscode,ysksname,kmcode,kmname,lykscode,lyksname,yplb,yplbname,
             @sqdate,@opername,null,null,cfnum,@t_tyid,jzdate,ybno,ybkmcode,zgysname,yzid
        from zycfypk (nolock)
        where keyno=@keyno
  end else
  begin
    if exists(select keyno from zytysq (nolock) where tyid=@t_tyid and yfcheckokdate is null)
    begin
      update zytysq
        set ypcount=@tycount,ypmoney=round(ypprice*@tycount,2),sqopername=@opername
        where tyid=@t_tyid and yfcheckokdate is null
    end
  end

  select @tyid=@t_tyid
  return 0
end
GO
