CREATE    PROCEDURE [dbo].[GetMZInvoice_Tmp]
(@fpnum_tmp int,@userid numeric)
as
begin
  insert _mzcfinf(CFNUM,YSCODE,YSNAME,CFFLAG,CFPRICE,CFCOUNT,CFMONEY,YFCODE,YFNAME,YSKSCODE,YSKSNAME,USERID,PROCDATE)
    select cfnum,yscode,ysname,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,yskscode,ysksname,@userid,getdate()
    from mzcfinf_tmp (nolock)
    where fpnum_tmp=@fpnum_tmp

  insert _mzcfypk(CFNUM,GOODSNO,YPCOUNT,YPPRICE,YPPRICE_1,YPMONEY,CFCOUNT,GOODSNAME,PROCNAME,UNITNAME,
                  YFCODE,YFNAME,KMCODE,KMNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,USERID,PROCDATE,YBLB,YBLBNAME,YBNO,YBKMCODE,CLFlag)
    select cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,cfcount,goodsname,procname,unitname,yfcode,yfname,kmcode,
           kmname,yscode,ysname,yskscode,ysksname,@userid,getdate(),yblb,yblbname,ybno,ybkmcode,clflag
    from mzcfypk_tmp (nolock)
    where fpnum_tmp=@fpnum_tmp

  insert _mzcheck(CHECKNO,CHECKNAME,UNITNAME,CHECKPRICE,CHECKCOUNT,CHECKMONEY,YSCODE,YSNAME,KMNAME,KMCODE,YSKSCODE,YSKSNAME,
                  USERID,PROCDATE,FSKSCODE,FSKSNAME,CHECKLB,CHECKLBNAME,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,GROUPKEYNO,
                  YBNO,YBKMCODE,YJApplyNum)
    select checkno,checkname,unitname,checkprice,checkcount,checkmoney,yscode,
           ysname,kmname,kmcode,yskscode,ysksname,
           @userid,getdate(),fskscode,fsksname,checklb,checklbname,groupcode,groupname,groupprice,groupcount,groupkeyno,
           ybno,ybkmcode,yjapplynum
    from mzcheck_Tmp (nolock)
    where fpnum_tmp=@fpnum_tmp

  /*重新生成cfnum*/
  declare @t_cfnum int
  declare @t_newcfnum int
  DECLARE _mzcfypk_cursor CURSOR FOR
    select cfnum from _mzcfypk (nolock) where userid=@userid group by cfnum
  OPEN _mzcfypk_cursor
  FETCH NEXT FROM _mzcfypk_cursor into @t_cfnum
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 6,@NewUniqueNo=@t_newcfnum output
    update _mzcfypk
      set cfnum=@t_newcfnum where userid=@userid and cfnum=@t_cfnum

    update _mzcfinf
      set cfnum=@t_newcfnum where userid=@userid and cfnum=@t_cfnum
    
    FETCH NEXT FROM _mzcfypk_cursor into @t_cfnum
  END
  CLOSE _mzcfypk_cursor
  DEALLOCATE _mzcfypk_cursor

  /***重新对Groupkeyno赋值***/
  update _mzcheck
    set groupkeyno=-keyno
    where groupkeyno is null and userid=@userid

  declare @t_newgroupkeyno numeric(18,0)
  declare @t_oldgroupkeyno numeric(18,0)

  declare @t_newyjapplynum numeric(18,0)
  declare @t_oldyjapplynum numeric(18,0)
  DECLARE checkgroup_cursor CURSOR FOR
    SELECT groupkeyno,yjapplynum FROM _mzcheck where userid=@userid group by groupkeyno,yjapplynum
  OPEN checkgroup_cursor
  FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_oldyjapplynum
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 14,@NewUniqueNo=@t_newgroupkeyno output

    update _mzcheck
      set groupkeyno=@t_newgroupkeyno
      where groupkeyno=@t_oldgroupkeyno and userid=@userid

    if @t_oldyjapplynum is not null
    begin
      execute GetUniqueNo 20,@NewUniqueNo=@t_NewYJApplyNum output
      update _mzcheck
        set yjapplynum=@t_NewYJApplyNum
        where yjapplynum=@t_OldYJApplyNum
    end

    FETCH NEXT FROM checkgroup_cursor into @t_oldgroupkeyno,@t_oldyjapplynum
  END
  CLOSE checkgroup_cursor
  DEALLOCATE checkgroup_cursor
end
GO
