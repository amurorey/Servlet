


CREATE VIEW _MZFPKMVIEW
AS
  select kmname,kmcode,summoney,userid from _mzcfkmview
union all
  select kmname,kmcode,summoney,userid from _mzcheckkmview


GO
