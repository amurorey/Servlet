CREATE  PROCEDURE [dbo].[AddPrePay]
(@p01 int,@p02 char(9),@p03 char(10),@p04 datetime,@p05 char(10),
 @p06 varchar(30),@p07 numeric(12,2),@p08 char(10),@InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  if exists(select m01 from mbase where m01=@p01 and m19 is not null)
    return 1

  if exists(select m01 from mbase (nolock) where m01=@p01 and m56 is not null)
    return 2  --已取消入院

  declare @t_curnum int
  if @InvoiceNum is not null
  begin
    select @t_curnum=isnull(curnum+1,BegNum) from Invoice_Operator where invoiceoperid=@InvoiceOperID and backflag is null and [TYPE]=2
    if convert(int,@InvoiceNum) <> @t_curnum
      return 6  --保存时发现当前号已被使用
    if @t_curnum is null 
      return 7  --发票号异常
  end
  
  if exists(select InvoiceMangFlag from unitset where InvoiceMangFlag=2) and (@InvoiceNum is null or RTRIM(@InvoiceNum)='' or @InvoiceOperID is null or @InvoiceOperID=0)
    return 8 --启用预交金票据管理后发票号不能空且批次号不能空
  

  insert prepay(p01,p02,p03,p04,p05,p06,p07,p08,InvoiceNum,InvoiceOperID)
    values(@p01,@p02,@p03,@p04,@p05,@p06,@p07,@p08,@InvoiceNum,@InvoiceOperID)
    
  if @InvoiceNum is not null
  begin
    update invoice_operator
      set curnum=@t_curnum
      where invoiceoperid=@InvoiceOperID
  end
   
  update mbase
    set m27=m27+@p07
    where m01=@p01
  return 0
end
GO
