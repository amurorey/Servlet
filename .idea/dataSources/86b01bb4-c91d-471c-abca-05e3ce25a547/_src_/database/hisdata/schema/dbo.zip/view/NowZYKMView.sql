


CREATE VIEW NowZYKMView AS
select zynum,kmcode,kmname,ypmoney*cfcount as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum
from zycfypk (nolock)
where deldate is null
union all
select zynum,kmcode,kmname,checkmoney as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum
from zycheck (nolock)
where deldate is null


GO
