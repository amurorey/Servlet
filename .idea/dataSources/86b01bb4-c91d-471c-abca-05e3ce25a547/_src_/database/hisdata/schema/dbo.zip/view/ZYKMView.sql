


CREATE VIEW ZYKMView
AS
select zynum,goodsname as xmname,kmcode,kmname,unitname,ypprice as xmprice,ypcount*cfcount as kmcount,ypmoney*cfcount as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum,0 as flag,yskscode as fskscode,ysksname as fsksname
  from zycfypk (nolock)
  where deldate is null
union all
select zynum,goodsname,kmcode,kmname,unitname,ypprice,ypcount*cfcount,ypmoney*cfcount as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum,0,yskscode,ysksname
  from zycfypkhis (nolock)  where deldate is null
union all
select zynum,checkname,kmcode,kmname,'次',checkprice,checkcount,checkmoney as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum,1,fskscode,fsksname
  from zycheck (nolock)
  where deldate is null
union all
select zynum,checkname,kmcode,kmname,'次',checkprice,checkcount,checkmoney as kmmoney,jzdate,yskscode,ysksname,lykscode,lyksname,yjfpnum,1,fskscode,fsksname
  from zycheckhis (nolock)
  where deldate is null


GO
