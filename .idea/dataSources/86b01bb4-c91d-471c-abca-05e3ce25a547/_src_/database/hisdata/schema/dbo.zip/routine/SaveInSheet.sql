CREATE            PROCEDURE [dbo].[SaveInSheet] 
(@sheetno char(10),@procdate datetime,@customercode char(10),
 @customername varchar(40),@storecode char(3),@storename char(10),
 @opername char(10),@userid int,@flag int,@retval varchar(100)="" output)
AS
begin
/***check unique sheetno***/
if exists (select * from instock where b02=@sheetno and b24=@storecode)
  return 1
/****check if have enough store****/
if exists (select store.goodsid,store.e03 from store,_instock
           where store.goodsid=_instock.goodsid and _instock.b17+store.e10<0 
           and _instock.userid=@userid)
begin
  select @retval=rtrim(_instock.b06)
    from store,_instock
    where store.goodsid=_instock.goodsid and _instock.b17+store.e10<0 
          and _instock.userid=@userid
  return 2
end
if exists(select goodsid from _instock,goods
    where a01=b05 and userid=@userid and goods.A52 is not null and goods.A52<>0 and _INSTOCK.B13>goods.A52)
begin
  select @retval=RTRIM(_INSTOCK.B06) from _instock,goods
    where a01=b05 and userid=@userid and goods.A52 is not null and goods.A52<>0 and _INSTOCK.B13>goods.A52
  return 3
end


/********************/
update _instock
  set b02=@sheetno,
      b03=@procdate,
      b09=@customercode,
      b10=@customername,
      b24=@storecode,
      b25=@storename,
      b27=@opername,
      b28=getdate()
  where userid=@userid

update instock_save
  set b02=@sheetno
  from instock_save a,_instock b
  where a.code_save=b.code_save and b.userid=@userid

insert instock 
         (B02,B03,B04,B05,B06,
         B07,B08,B09,B10,B11,B12,
         B13,B14,B15,B16,B17,B18,
         B18_1,B19,B20,B21,B22,
         B23,B24,B25,B26,B27,B28,
         B29,B30,goodsID,B31,B32,B33,B34,B35,B36,b37,b38)
  select B02,B03,B04,B05,B06,B07,B08,B09,B10,B11,B12,
         B13,B14,B15,B16,B17,B18,
         B18_1,B19,B20,B21,B22,
         B23,B24,B25,B26,B27,B28,
         B29,B30,goodsID,B31,B32,B33,B34,B35,B36,b37,b38
    from _instock
    where userid=@userid
if @flag=0 
begin
  insert store
    select goodsid,b05,b20,b06,b07,
         b08,b11,b12,a12,a13,b13,        
         case
           when round(b13/a13,4) < 0.0001 then 0.0001
           else round(b13/a13,4)
         end,
         b16,
         case
           when round(b16/a13,4) < 0.0001 then 0.0001
           else round(b16/a13,4)
         end,
         b17,b17*a13,b24,b25,
         a14,a15,b03,b14,b15,b19,b22,b23,b09,b10,a24,b31,b32,b33,b34,b35,b36,b37
    from _instock,goods
    where a01=b05 and userid=@userid 

  --取当前入库的产地替换goods库中的产地
  update goods
    set a08=b11,a26=b31,a37=b38
    from goods,_instock
    where a01=b05 and userid=@userid
end else
begin
  /***update store table****/
  update store
    set e10=store.e10+_instock.b17,
        e10_1=store.e10_1+_instock.b17*store.e07_2
    from store,_instock
    where store.goodsid=_instock.goodsid 
      and _instock.userid=@userid

  --取当前入库的产地替换goods库中的产地
  update goods
    set a08=b11
    from goods,_instock
    where a01=b05 and userid=@userid

  /***自动做库房调价盈余表当出库冲单时冲单单价不等于现行单价时***/
  insert kfchangeprice
    select b02,_instock.goodsid,b05,b06,b12,b15,e10,b13,b13_1,b16,b16_1,e08,e08_1,e09,e09_1,(e08-b13)*b17,
          (e09-b16)*b17,getdate(),@opername,b24,b25,'出库时价差'      from _instock,store (nolock) 
      where _instock.goodsid=store.goodsid and b24=e12 and userid=@userid and (e08<>b13 or e09<>b16)
end

return 0
end
GO
