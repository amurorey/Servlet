/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2005-01-24 09:32:21 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2004-12-31 15:40:48 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2004-12-05 21:16:10 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2004-11-19 10:15:14 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2004-10-18 16:22:53 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2004-08-19 10:16:28 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2003-11-07 20:41:21 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2003-07-25 16:36:41 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2003-07-19 10:19:30 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2003-07-11 14:02:19 ******/
/****** Object:  Stored Procedure dbo.GetGoodsNo    Script Date: 2003-06-20 09:00:14 ******/
CREATE PROCEDURE [dbo].[GetGoodsNo]
(@storecode char(2),@NewUniqueNo int output)
AS
begin
  /*Attention:This no is from ykcode table*/
  update ykcode set GoodsNo=GoodsNo+1 where ykcode=@storecode
  select @NewUniqueNo=GoodsNo from ykcode where ykcode=@storecode
end
GO
