-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Interface_PDA_Return]
(@FP0 varchar(20), @UserCode varchar(20), @ReturnDate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @t_FP0 varchar(20)
    declare @t_FP125 datetime
    select @t_FP0=FP0,@t_FP125=FP125 from BA_FPage (nolock) where FP0=@FP0 and FP125 is not null
    
    declare @t_UserName varchar(20)
    select @t_UserName = [name] from YSCODE where [CODE]=@UserCode
    if @t_FP0 is null
    begin
      update BA_FPage
        set FP125=@ReturnDate,FP125_OperName=@t_UserName
        where FP0=@FP0
        
      insert ba_fpagelog(FP0,OperDate,OperName,OperNote)
        select @FP0,@ReturnDate,@t_UserName,'病历首次归档(PDA)'
    end;
    return 0
END
GO
