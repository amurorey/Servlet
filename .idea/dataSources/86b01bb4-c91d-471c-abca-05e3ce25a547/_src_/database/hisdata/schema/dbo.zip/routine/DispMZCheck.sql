CREATE   PROCEDURE [dbo].[DispMZCheck] 
(@fpnum int,@flag int) with recompile
AS
begin
  if exists(select fpnum from mzcheck where fpnum=@fpnum)
    select fpnum,keyno,groupkeyno,checkno as xmcode,
       case
         when mzcheck.checklbname='甲类' then '(甲)'+checkname
         when mzcheck.checklbname='乙类' then '(乙)'+checkname
         when mzcheck.checklbname='丙类' then '(丙)'+checkname
         when mzcheck.checklbname='定额' then '(定额)'+checkname
         else checkname
       end as checkname,
       mzcheck.unitname,checkprice,checkcount,checkmoney,yscode,ysname,maxprice,fsksname,mzcheck.kmcode,mzcheck.kmname
      from mzcheck,checkcode (nolock)
        where checkno=code and fpnum=@fpnum and groupcode is null
    union all
    select fpnum,max(keyno),groupkeyno,groupcode,
           '★'+groupname,
           '组套',
           groupprice,groupcount,sum(checkmoney),yscode,ysname,null,fsksname,'',''
      from mzcheck (nolock)
        where fpnum=@fpnum and groupcode is not null
        group by fpnum,groupkeyno,groupcode,groupname,yjapplynum,groupprice,groupcount,yscode,ysname,fsksname
    order by keyno
  else
    select fpnum,keyno,groupkeyno,checkno as xmcode,
       case
         when mzcheckhis.checklbname='甲类' then '(甲)'+checkname
         when mzcheckhis.checklbname='乙类' then '(乙)'+checkname
         when mzcheckhis.checklbname='丙类' then '(丙)'+checkname
         when mzcheckhis.checklbname='定额' then '(定额)'+checkname
         else checkname
       end as checkname,
       mzcheckhis.unitname,checkprice,checkcount,checkmoney,yscode,ysname,maxprice,fsksname,mzcheckhis.kmcode,mzcheckhis.kmname
      from mzcheckhis,checkcode (nolock)
        where checkno=code and fpnum=@fpnum and groupcode is null
    union all
    select fpnum,max(keyno),groupkeyno,groupcode,
           '★'+groupname,
           '组套',
           groupprice,groupcount,sum(checkmoney),yscode,ysname,null,fsksname,'',''
      from mzcheckhis (nolock)
        where fpnum=@fpnum and groupcode is not null
        group by fpnum,groupkeyno,groupcode,groupname,yjapplynum,groupprice,groupcount,yscode,ysname,fsksname
    order by keyno
end
GO
