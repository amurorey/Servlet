--@flag=0 门诊  1：住院
CREATE           PROCEDURE [dbo].[DispApplicationSheet]
(@kscode char(4),@flag int)
AS
begin
  if @flag=0  --门诊
  begin
    select kscode,ksname,0 as applicationcode,''applicationname,ksname as treename,0 as applicationtype,0 as childtreekeyno,0 as groupkeyno,'' as groupcode,'' as checkcode,
           ''as checkname,'' as checkname2,0 as xmcount,0.00 as checkprice,'' as unitname,
           '' as samplecode,'' as sampletype,0 as treelevel,0 as treekeyno,0 as xmkeyno,0 as parenttreekeyno,'' as hivflag,'' as tubecolor,0 as priceflag,0 as ApplicationSortID,0 as TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationsheet (nolock)
      where deldate is null and (useflag is null or useflag=2) and (privateflag is null or (privateflag=1 and kscode=@kscode))
      group by kscode,ksname
    union all
    select kscode,ksname,applicationcode,applicationname,treename,applicationtype,0 as childtreekeyno,0 as groupkeyno,'' as groupcode,'' as checkcode,
           ''as checkname,'' as checkname2,0 as xmcount,0.00,'',
           '' as samplecode,'' as sampletype,TreeLevel+1,treekeyno,0 as xmkeyno,parenttreekeyno,'' as hivflag,'' as tubecolor,PriceFlag,ApplicationSortID,TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationsheet (nolock)
      where deldate is null and (useflag is null or useflag=2) and (privateflag is null or (privateflag=1 and kscode=@kscode))
    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,a.checkname2,a.applicationtype,a.treekeyno as childtreekeyno,a.groupkeyno,a.groupcode,a.checkcode,
           a.checkname,a.checkname2,a.checkcount as xmcount,a.checkprice,a.unitname,
           a.samplecode,a.sampletype,a.treelevel+1,a.parenttreekeyno,a.keyno,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID,a.parenttreekeyno as TreeKeyNoSortiD,EnableChangePrice
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
        where a.parenttreekeyno=b.treekeyno and a.groupcode is null and a.deldate is null 
          and b.deldate is null and (useflag is null or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))
    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,'★' + a.groupname,a.applicationtype,min(a.treekeyno) as childtreekeyno,min(a.groupkeyno) as groupkeyno,a.groupcode,a.groupcode,
           '★' + a.groupname,a.groupname,1 as xmcount,a.groupprice,'组套',
           a.samplecode,a.sampletype,a.treelevel+1,a.parenttreekeyno,0,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID,a.parenttreekeyno as TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
      where a.parenttreekeyno=b.treekeyno and a.groupcode is not null and a.deldate is null
         and b.deldate is null and (useflag is null or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))
      group by a.kscode,a.ksname,a.ApplicationCode,a.applicationname,a.applicationtype,a.groupcode,a.groupname,a.groupprice,a.samplecode,a.sampletype,a.treelevel,a.parenttreekeyno,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID
/*    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,a.checkname2,a.applicationtype,a.groupkeyno,a.groupcode,a.groupcode,
           a.checkname,a.checkname2,a.checkcount,a.checkprice,a.unitname,
           a.samplecode,a.sampletype,a.treelevel+2,a.parenttreekeyno,a.keyno,b.parenttreekeyno
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
      where a.parenttreekeyno=b.treekeyno and a.groupcode is not null and a.deldate is null
        and a.deldate is null and (useflag is null or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))*/
    order by kscode,ApplicationSortID,parenttreekeyno,TreeKeyNoSortID,childtreekeyno,treelevel
  end else  --住院
  begin
    select kscode,ksname,0 as applicationcode,''applicationname,ksname as treename,0 as applicationtype,0 as childtreekeyno,0 as groupkeyno,'' as groupcode,'' as checkcode,
           ''as checkname,'' as checkname2,0 as xmcount,0.00 as checkprice,'' as unitname,
           '' as samplecode,'' as sampletype,0 as treelevel,0 as treekeyno,0 as xmkeyno,0 as parenttreekeyno,'' as hivflag,'' as tubecolor,0 as priceflag,0 as ApplicationSortID,0 as TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationsheet (nolock)
      where deldate is null and (useflag=1 or useflag=2) and (privateflag is null or (privateflag=1 and kscode=@kscode))
      group by kscode,ksname
    union all
    select kscode,ksname,applicationcode,applicationname,treename,applicationtype,0 as childtreekeyno,0 as groupkeyno,'' as groupcode,'' as checkcode,
           ''as checkname,'' as checkname2,0 as xmcount,0.00,'',
           '' as samplecode,'' as sampletype,TreeLevel+1,treekeyno,0 as xmkeyno,parenttreekeyno,'' as hivflag,'' as tubecolor,PriceFlag,ApplicationSortID,TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationsheet (nolock)
      where deldate is null and (useflag=1 or useflag=2) and (privateflag is null or (privateflag=1 and kscode=@kscode))
    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,a.checkname2,a.applicationtype,a.treekeyno as childtreekeyno,a.groupkeyno,a.groupcode,a.checkcode,
           a.checkname,a.checkname2,a.checkcount as xmcount,a.checkprice,a.unitname,
           a.samplecode,a.sampletype,a.treelevel+1,a.parenttreekeyno,a.keyno,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID,a.parenttreekeyno as TreeKeyNoSortiD,EnableChangePrice
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
        where a.parenttreekeyno=b.treekeyno and a.groupcode is null and a.deldate is null 
          and b.deldate is null and (useflag=1 or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))
    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,'★' + a.groupname,a.applicationtype,min(a.treekeyno) as childtreekeyno,min(a.groupkeyno) as groupkeyno,a.groupcode,a.groupcode,
           '★' + a.groupname,a.groupname,1 as xmcount,a.groupprice,'组套',
           a.samplecode,a.sampletype,a.treelevel+1,a.parenttreekeyno,0,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID,a.parenttreekeyno as TreeKeyNoSortiD,0 as EnableChangePrice
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
      where a.parenttreekeyno=b.treekeyno and a.groupcode is not null and a.deldate is null
         and b.deldate is null and (useflag=1 or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))
      group by a.kscode,a.ksname,a.applicationcode,a.applicationname,a.applicationtype,a.groupcode,a.groupname,a.groupprice,a.samplecode,a.sampletype,a.treelevel,a.parenttreekeyno,b.parenttreekeyno,hivflag,tubecolor,b.PriceFlag,b.ApplicationSortID
/*    union all
    select a.kscode,a.ksname,a.applicationcode,a.applicationname,a.checkname2,a.applicationtype,a.groupkeyno,a.groupcode,a.groupcode,
           a.checkname,a.checkname2,a.checkcount,a.checkprice,a.unitname,
           a.samplecode,a.sampletype,a.treelevel+2,a.parenttreekeyno,a.keyno,b.parenttreekeyno
      from applicationcheckcode as a (nolock),applicationsheet as b (nolock)
      where a.parenttreekeyno=b.treekeyno and a.groupcode is not null and a.deldate is null
        and a.deldate is null and (useflag=1 or useflag=2) and (privateflag is null or (privateflag=1 and b.kscode=@kscode))*/
    order by kscode,applicationcode,parenttreekeyno,treekeyno,childtreekeyno,treelevel
  end
end
GO
