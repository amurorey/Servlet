-- =============================================
-- Author:		Lanyuzhi
-- Create date: 2015-5-20
-- Description:	用于PDA接口的未归档病案首页信息查新
-- =============================================
CREATE PROCEDURE [dbo].[Interface_PDA_FPage]
AS
BEGIN
	SET NOCOUNT ON;

    select FP0,FP2,FP24,FP29,FP29_Name,FP31,FP118 from ba_fpage (nolock),kscode (nolock) where fp29=code and notbaflag is null and fp31 is not null and fp121 is null and fp125 is null order by fp0
END
GO
