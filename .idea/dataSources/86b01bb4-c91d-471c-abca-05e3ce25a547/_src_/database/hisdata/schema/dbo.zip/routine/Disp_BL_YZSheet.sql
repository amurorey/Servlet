/*_BL_YZSheet表中XMFLAG的描述
YZFlag=1  长期医嘱
YZFlag=2  临时医嘱 （临时医嘱包括  检查申请xmflag=11  临时处方xmflag=6其中cfcount is null 则为西药临时处方  cfcount>0则为临时草药医嘱）

XMFlag=1  西药医嘱
XMFlag=2  西药组医嘱
XMFlag=3  中成药医嘱（指向中药房，非草药处方）
XMFlag=4  诊疗医嘱
XMFlag=5  非记账医嘱
XMFlag=6  临时处方（包括西药处方及草药处方）

xmflag=7  术后医嘱
XMFlag=8  产后医嘱
XMFlag=9  重整医嘱  
XMFlag=10 转科后医嘱(在接收转科后处理）

XMFlag=11 检查申请
*/

CREATE                        PROCEDURE [dbo].[Disp_BL_YZSheet]
(@userid numeric,@yzflag int,@xmflag int=null,@dispflag int,@begdate datetime=null,@enddate datetime=null)
AS
begin
  --此处强制更新sortid
  update _BL_YZSheet 
    set SortID=YZID
    where UserID=@userid and sortid is null

  declare @t_casetext nvarchar(512)
  if @yzflag=1  /*显示长期医嘱*/
  begin
    declare @t_maxyzresetkeyno numeric(12,0)
    select @t_maxyzresetkeyno=max(keyno) from _bl_yzsheet (nolock) where userid=@userid and xmflag in(7,8,9,10)
    if @t_maxyzresetkeyno is null 
      set @t_maxyzresetkeyno=0

    if @dispflag=1  /*显示所有长期医嘱*/
      set @t_casetext=' and yzflag=1'
    else
      set @t_casetext= ' and yzflag=1 and (yzstopdate is null) and (not xmflag in(7,8,9,10) or keyno='+rtrim(convert(char(15),@t_maxyzresetkeyno))+')'
  end else if @yzflag=2      /*显示临时医嘱*/
  begin
    if @dispflag=1  /*显示所有临时医嘱*/
      set @t_casetext=' and (yzflag=2)'
    else
      set @t_casetext=' and (yzflag=2) and yzlastrundate is null'
  end else if @yzflag=3
  begin
    if @dispflag=1  /*显示所有临时处方*/
      set @t_casetext=' and xmflag=6'
    else
      set @t_casetext=' and xmflag=6 and ( (yzflag=1 and yzstopdate is null) or (yzflag=2 and yzlastrundate is null) )'
  end else if @yzflag=4
  begin
    if @dispflag=1  /*显示所有检查申请*/
      set @t_casetext=' and xmflag=11'
    else
      set @t_casetext=' and xmflag=11 and ( (yzflag=1 and yzstopdate is null) or (yzflag=2 and yzlastrundate is null) )'
  end

  if (@yzflag=1 or @yzflag=2) and (@xmflag=1)
    set @t_casetext=@t_casetext+ ' and xmflag in(1,2,3,6,7,8,9,10)'  --仅显示药品医嘱
  else if (@yzflag=1 or @yzflag=2) and (@xmflag=2)
    set @t_casetext=@t_casetext+ ' and xmflag in(4,5,7,8,9,10,11)'   --仅显示诊疗医嘱
  else if (@yzflag=3) and (@xmflag>0)
    set @t_casetext=@t_casetext+ ' and cfnum=' + convert(varchar(20),@xmflag)                --仅显示对应处方明细

  if @begdate is not null
    set @t_casetext=@t_casetext+ ' and yzbegdate>='''+convert(char(10),@begdate,121)+''''          --设置医嘱起始日期
  if @enddate is not null
    set @t_casetext=@t_casetext+ ' and yzbegdate<'''+convert(char(10),@enddate,121)+''''           --设置医嘱终止日期
  
  declare @t_orderflag int
  select @t_orderflag=yzorderflag from unitset
  declare @t_orderstr varchar(200)
  if @t_orderflag is null
    select @t_orderstr=' order by keyno'
  else
    select @t_orderstr=' order by sortid,keyno'

  declare @t_sqltext nvarchar(4000)
  if (@yzflag=1) or (@yzflag=2)
  begin
    set @t_sqltext=N'select 1 as flag,case when SelectFlag=1 then ''√'' else '''' end as SelectFlag,keyno as xmcode,yzbegdate,'+
        'case when (xmflag=1 or xmflag=3) and a37=''1'' then ''*''+xmname'+
        ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) in(''┏'',''┃'',''┗'') then substring(xmname,1,1)+''*''+rtrim(substring(xmname,2,100))'+
        ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) not in(''┏'',''┃'',''┗'') then ''*''+xmname'+
        ' when xmflag=4 and XMDescription is not null and rtrim(XMDescription)<>'''' then XMDescription'+
        ' when xmflag=5 then ''◇''+xmname else xmname end as xmname,'+
        'ypjl,ypjlunit,'+
        'convert(varchar(10),xmcount)+xmunit as xmcount,'+
        'yzusedmethod,yppath,yzysname,'+
        'yzstopdate,yzlastrundate,yzrundate,'+
        'case when totcount is not null then convert(varchar(10),totcount)+xmunit else null end as totcount,note,xmflag,'+
        'case when a40=1 then ''非限制'' when a40=2 then ''限制'' when a40=3 then ''特殊'' else ''''  end as kjsflag,sortid'+
        ' from _bl_yzsheet (nolock) left join goods (nolock) on (xmcode=a01)'+
        ' where userid='+convert(varchar(20),@userid)+' and checkgroupcode is null and cfnum is null and cfcount is null'+
        @t_casetext +
        ' union all '+
        'select 2 as flag,case when SelectFlag=1 then ''√'' else '''' end as SelectFlag,checkgroupkeyno as xmcode,yzbegdate,'+
        'case when yjapplynum is null then ''★'' else ''▽'' end+case when XMDescription is not null and rtrim(XMDescription) <> '''' then XMDescription else checkgroupname end,'+
        'null,null,'+
        'convert(varchar(10),checkgroupcount)+''组套'','+
        'yzusedmethod,null,yzysname,'+
        'yzstopdate,yzlastrundate,yzrundate,'+
        'case when totcount is not null then convert(varchar(10),totcount)+''组套'' else null end,note,xmflag,'+
        'null,sortid'+
        ' from _bl_yzsheet (nolock) left join goods (nolock) on (xmcode=a01)'+
        ' where userid='+convert(varchar(20),@userid)+' and checkgroupcode is not null and cfcount is null'+
        @t_casetext +
        ' group by SelectFlag,checkgroupkeyno,yzid,yzbegdate,checkgroupcode,checkgroupname,XMDescription,yjapplynum,checkgroupcount,'+
        'yzusedmethod,yzysname,'+
        'yzstopdate,yzlastrundate,yzrundate,totcount,note,xmflag,sortid'+
        /*' union all '+
        'select 3 as flag,yzid as xmcode,yzbegdate,'+
        'xmdescription,'+
        'null,null,'+
        'null,'+
        'null,null,yzysname,'+
        'null,yzlastrundate,yzrundate,'+
        'null,null,xmflag,'+
        'null,sortid'+
        ' from _bl_yzsheet (nolock) left join goods (nolock) on (xmcode=a01)'+
        ' where zynum='+convert(varchar(20),@zynum)+' and userid='+convert(varchar(20),@userid)+' and checkgroupcode is null and cfcount is not null'+
        @t_casetext +
        ' group by yzid,yzbegdate,XMDescription,yzysname,'+
        ' yzlastrundate,yzrundate,xmflag,sortid'+*/

        @t_orderstr
  end else if (@yzflag=3) or (@yzflag=4)
  begin
    set @t_sqltext=N'select 1 as flag,case when SelectFlag=1 then ''√'' else '''' end as SelectFlag,keyno as xmcode,yzbegdate,'+
        'case when (xmflag=1 or xmflag=3) and a37=''1'' then ''*''+xmname'+
        ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) in(''┏'',''┃'',''┗'') then substring(xmname,1,1)+''*''+rtrim(substring(xmname,2,100))'+
        ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) not in(''┏'',''┃'',''┗'') then ''*''+xmname'+
        ' when xmflag=4 and XMDescription is not null and rtrim(XMDescription)<>'''' then XMDescription'+
        ' when xmflag=5 then ''◇''+xmname else xmname end as xmname,'+
        'ypjl,ypjlunit,'+
        'convert(varchar(10),xmcount)+xmunit as xmcount,'+
        'yzusedmethod,yppath,yzysname,'+
        'yzstopdate,yzlastrundate,yzrundate,'+
        'case when totcount is not null then convert(varchar(10),totcount)+xmunit else null end as totcount,note,xmflag,'+
        'case when a40=1 then ''非限制'' when a40=2 then ''限制'' when a40=3 then ''特殊'' else ''''  end as kjsflag,sortid'+
        ' from _bl_yzsheet (nolock) left join goods (nolock) on (xmcode=a01)'+
        ' where userid='+convert(varchar(20),@userid)+' and checkgroupcode is null'+
        @t_casetext +
        @t_orderstr
  end

  exec sp_executesql @t_sqltext

end
GO
