CREATE PROCEDURE [dbo].[ZYRBJS] 
(@opername char(10),@jsdate datetime)
AS
begin  
  if exists(select p01 from prepay (nolock) where convert(char(12),p09,1)=convert(char(12),@jsdate,1) and p05=@opername)
    return 1
  
  if exists(select p01 from prepayhis (nolock) where convert(char(12),p09,1)=convert(char(12),@jsdate,1) and p05=@opername)
    return 1
    
  if exists(select invoiceoperid from Invoice_Damage where InvoiceOperID is not null and ([type]=1 or [type]=2) and OperName=@opername and convert(char(12),JSDate,1)=convert(char(12),@jsdate,1))
    return 1
  

  if exists(select p01 from prepay (nolock) where p04>@jsdate and p05=@opername)
    return 2

  update mbase
    set m31=@jsdate
    where m30 is not null and m31 is null and m32=@opername
  
  update prepay
    set p09=@jsdate
    where p09 is null and p05=@opername

  update prepayhis
    set p09=@jsdate
    where p09 is null and p05=@opername

  update zycheck
    set jsdate=@jsdate
    from zycheck,zyinvoicebase
    where zycheck.yjfpnum=zyinvoicebase.fpnum
      and zyinvoicebase.jsdate is null and fpoper=@opername

  update zycfypk
    set jsdate=@jsdate
    from zycfypk,zyinvoicebase
    where zycfypk.yjfpnum=zyinvoicebase.fpnum
      and zyinvoicebase.jsdate is null and fpoper=@opername

  update zyinvoicebase
    set jsdate=@jsdate,jsoper=@opername    
    where jsdate is null and fpoper=@opername

  update zyinvoice
    set jsdate=@jsdate,jsoper=@opername
    where jsdate is null and fpoper=@opername

  update yb_zyinvoice
    set jsdate=@jsdate,jsoper=@opername
    where jsdate is null and fpoper=@opername

  update yj_applysheet
    set jsdate=zyinvoicebase.jsdate
    from yj_applysheet,zyinvoicebase
    where yj_applysheet.fpnum=zyinvoicebase.fpnum and yj_applysheet.jsdate is null 
          and patientkind=2 and zyinvoicebase.jsoper=@opername

  update Invoice_Damage
    set JSDate=@jsdate
    where invoiceoperid is not null and ([type]=1 or [type]=2)and jsdate is null and opername=@opername

  /*东软医保数据表结算*/
  update dryb_invoicebase
    set jsdate=@jsdate
    where jsdate is null and fpoper=@opername and patientstate=2

  /*新农合数据表结算*/
  update xnh_invoicebase
    set jsdate=@jsdate
    where jsdate is null and fpopername=@opername and patientstate=2

  /*异地医保数据表结算*/
  update ydyb_invoicebase
    set jsdate=@jsdate
    where jsdate is null and fpopername=@opername and patientstate=2

  /*银海医保数据表结算*/
  update yhyb_invoicebase
    set jsdate=@jsdate
    where jsdate is null and fpoper=@opername and zynum is not null

  /*强制出院*/
  update zycheck
    set jsdate=@jsdate
    from zycheck,mbase
    where zynum=m01 and jsdate is null and yjfpnum is null
      and m19 is not null and m28=1 and m31 is null and m23=@opername

  insert qfbraccount(zynum,name,kscode,ksname,brmoney,procdate,flag,opername,note)
    select m01,m04,m20,m21,m25-m27,@jsdate,null,@opername,'出院强制处理' from mbase where m28=1 and m31 is null and m23=@opername

  update zycfypk
    set jsdate=@jsdate
    from zycfypk,mbase
    where zynum=m01 and jsdate is null and yjfpnum is null
      and m19 is not null and m28=1 and m31 is null and m23=@opername

  update mbase
    set m31=@jsdate
    where m19 is not null and m28=1 and m31 is null and m23=@opername

  return 0
end
GO
