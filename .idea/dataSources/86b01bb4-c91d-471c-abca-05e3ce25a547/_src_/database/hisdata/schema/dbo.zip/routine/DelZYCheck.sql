CREATE PROCEDURE [dbo].[DelZYCheck]
(@zynum int,@keyno numeric=null,@opername char(10),@operkscode char(4))
AS
begin
  if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null)     return 1

  if exists(select zynum from zycheck (nolock) where zynum=@zynum and keyno=@keyno and              deldate is not null)
    return 2

  if exists(select zynum from zycheck (nolock) where zynum=@zynum and keyno=@keyno and
              yjfpnum is not null)
    return 3

  if @operkscode is not null
  begin
    if not exists(select checkno from zycheck (nolock)
                    where zynum=@zynum and keyno=@keyno 
                      and checkno in(select checkcode from kscheckcode (nolock) where kscode=@operkscode and groupflag is null)
                                     union all
                                     select checkcode from kscheckcode,checkcode where checkcode=code and groupflag=1 and kscode=@operkscode)
      return 4
  end

  update zycheck
    set deldate=getdate(),deloper=@opername
  where zynum=@zynum and keyno=@keyno
  update mbase
    set m25=m25-checkmoney
    from mbase,zycheck
    where m01=zynum and zynum=@zynum and keyno=@keyno

  return 0
end
GO
