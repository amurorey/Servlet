CREATE procedure [dbo].[BA_FPageSave]
(       @FP0 [char] (20),
        @FP1 [varchar] (10)  ,
      	@FP3 [varchar] (1)  ,
      	@FP4 [datetime]  ,
      	@FP5 [numeric](12, 2)=null  ,
        @FP5_Str varchar(20)=null,
      	@FP6 [varchar] (10)  ,
        @FP6_Name [Varchar] (20),
        @FP8 [varchar] (1)  ,
        @FP9 [varchar] (4)  ,
        @FP9_Name [varchar] (40),
        @FP9_YS [varchar] (40)=null,
        @FP10 [varchar] (6)  ,
        @FP10_Name [varchar] (40),
        @FP10_YS [varchar] (100)=null,
        @FP11 [varchar] (4)  ,
        @FP11_Name [varchar] (20),
        @FP11_YS [varchar] (10)=null,
        @Nationality_YS [varchar] (20)=null,
        @PersonNo [varchar] (20)=null,
        @FP12 [smallint]  ,
        @FP14 [varchar] (100)  ,
        @FP14_PostCode [varchar] (10)=null,
        @FP15 [varchar] (20),
        @FP17 [varchar] (6)  ,
        @FP17_Name [varchar] (40),
        @FP17_YS [varchar] (100)=null,
        @FP17_PostCode [varchar] (10)=null,
        @FP22 [varchar] (13)  ,
        @FP22_1 [varchar] (20)  ,
        @FP22_2 [varchar] (20)=null,
        @FP22_3 [varchar] (100)=null,
        @FP27 [varchar] (1)  ,
        @FP36_YS [varchar] (256)=null  ,
        @FP36 [varchar] (20)  ,
        @FP36_NAME [varchar] (40)  ,
        @FP37_YS [varchar] (256)=null  ,
        @FP37 [varchar] (20)  ,
        @FP37_NAME [varchar] (40)  ,
        @FP40 [smalldatetime]  ,
        @FP53_YS [varchar] (50)=null  ,
        @FP53 [varchar] (8)  ,
        @FP53_NAME [varchar] (40)  ,
        @FP54 [varchar] (1)  ,
        @FP55_YS [varchar] (100)=null  ,
        @FP69 [varchar] (1)  ,
        @FP70 [varchar] (1)  ,
        @FP71 [varchar] (1)  ,
        @FP72 [numeric](8, 2)=null  ,
        @FP73 [numeric](8, 2)=null  ,
        @FP74 [numeric](8, 2)=null  ,
        @FP75 [numeric](8, 2)=null  ,
        @FP76 [numeric](8, 2)=null  ,
        @FP76_1 [numeric](8,2)=null,  
        @FP77 [varchar] (1)=null  ,
        @FP80 [varchar] (1)  ,
        @FP81 [varchar] (1)  ,
        @FP82 [varchar] (1)  ,
        @FP83 [varchar] (1)  ,
        @FP84 [varchar] (1)  ,
        @FP85 [varchar] (1)  ,
        @FP86 [varchar] (1)=null  ,
        @FP87 [varchar] (1)  ,
        @FP90 [varchar] (1)  ,
        @FP93 [varchar] (2)  ,
        @FP94 [smallint]  ,
        @FP95 [smallint]  ,
        @FP96 [varchar] (1)=null  ,
        @FP97 [char](30)=null  ,
        @FP98 [varchar] (1)  ,
        @FP114 [varchar] (1)=null  ,
        @FP115 [varchar] (1)  ,
        @FP116 [char] (20),
        @FP117 [char] (20),
        @FP118_KZR [varchar] (10)=null,
        @FP118_ZRYS [varchar] (10)=null,
        @FP118_ZZYS [varchar] (10)=null,
        @FP118 [varchar] (8)  ,
        @FP120 [varchar] (10)=null  ,
        @FP122 [varchar] (1)  ,
        @FP125 [smalldatetime],
        @Note [varchar] (128),
        @userid numeric(12),
        @OperName char(20),
        @FP129 [char] (10) = null,  --病理诊断代码
        @FP129_Name [varchar] (60) =null, --病理诊断代码对应名称
        @FP129_YS [varchar] (80) = null,  --病理诊断由医师录入
        @FP130_YS [varchar] (40) = null,  --药物过敏名称

        @FP130 char(1)=null,              --是否药物过敏  （1无  2有 则必须输入FP130_YS)
        @FP134 varchar(30)=null,                  --新生儿出生体重
        @FP135 int=null,                  --新生儿入院体重
        @FP136 varchar(100)=null,          --籍贯
        @FP137 char(10)=null,          --现住址编码
        @FP137_Name varchar(60)=null,  --现住址编码对应的名称
        @FP137_YS varchar(100)=null,       --现住址名称
        @FP138 varchar(10)=null,          --现住址邮编
        @FP139 varchar(20)=null,          --现住址电话
        @FP140 char(2)=null,              --入院途径
        @FP141 varchar(20)=null,          --病理号
        @FP142 char(1)=null,              --离院方式
        @FP142_Name varchar(40)=null,     --离院方式对应的拟接收医疗机构名称
        @FP143 char(1)=null,              --再住院计划标志
        @FP143_Name varchar(40)=null,     --再住院计划对应的目的
        @FP144_D int=null,                --入院前昏迷时间(天）
        @FP144_H int=null,                --入院前昏迷时间(小时）
        @FP144_M int=null,                --入院前昏迷时间(分钟）
        @FP145_D int=null,                --入院后昏迷时间(天）
        @FP145_H int=null,               --入院后昏迷时间(小时）
        @FP145_M int=null,                --入院后昏迷时间(分钟）
        @FP146 char(1)=null,              --是否临床路径管理
        @FP146_Day int=null,              --临床路径住院天使
        @FP147 char(1)=null,              --产科新生儿离院方式
        @FP148 char(1)=null,              --本次住院距上次住院时间
        @FP149 char(10)=null,             --责任护士
        @FP150 datetime=null,             --质控日期
        @Ver char(10)=null,               --守业首页版本号(新首页为“2012”）
        @YSFlag int=0,                     --@ysflag int 表示是否是医师录入首页  0：否  1：是

        @FP95_1 char(1)=null,  --住院期间是否出现危重 1.是  2.否  (FP94:抢救次数 FP95：成功次数）
        @FP146_1 char(1)=null,  --是否完成临床路径 1.是 2.否　FP146为是否实施临床路径
        @FP146_2 varchar(60)=null,  --退出临床路径原因  FP146为是否实施临床路径
        @FP146_3 char(1)=null,  --临床路径是否变异 1.是 2.否　FP146为是否实施临床路径
        @FP146_4 varchar(60)=null,  --临床路径变异原因  FP146为是否实施临床路径
        @FP148_1 char(1)=null,  --上一次住本院与本次住院是否因同一疾病(主要诊断) 1.是  2.否
        @FP151 char(1)=null,  --Ⅰ类手术切口预防性应用抗菌药物 1.是 2.否
        @FP151_1 numeric(8,1)=null,  --Ⅰ类手术切口预防性应用抗菌药物持续时间小时
        @FP151_2 char(1)=null,  --联合用药： 1.是 2.否
        @FP152 char(1)=null,  --住院期间是否应用抗菌药物  1.是 2.否
        @FP152_1 numeric(8,1)=null,  --住院期间是否应用抗菌药物持续时间小时
        @FP152_2 char(1)=null,  --联合用药： 1.是 2.否
        @FP153 char(1)=null,  --住院期间是否输液 1.是 2.否
        @FP153_1 char(1)=null,  --是否发生输液反应 1.是 2.否
        @FP154 char(1)=null,  --住院期间是否输血 1.是 2.否
        @FP154_1 char(1)=null,  -- 是否发生输血反应：1.是 2.否
        @FP155 char(1)=null,  --是否有压疮 1.是 2.否
        @FP155_1 char(1)=null,  --压疮发生时间 1.入院前 2.住院期间
        @FP155_2 char(1)=null,  --压疮分期 1. 1期  2. 2期  3. 3期  4. 4期
        @FP156 char(1)=null,  --住院期间是否发生跌倒或坠床 1.是  2.否
        @FP156_1 char(1)=null,  --住院期间跌倒或坠床的伤害程度 0.未造成伤害 1. 一级 2. 二级 3. 三级
        @FP156_2 char(1)=null,  --跌倒或坠床的原因 □ 1.健康原因 2.治疗、药物、麻醉原因 3.环境因素 4.其他原因
        @FP157 char(1)=null,  --住院期间是否使用物理约束 □ 1.是  2.否
        @FP157_1 numeric(8,1)=null,  --约束总时间小时
        @FP157_2 char(1)=null,  --约束方式 1.一处 2.两处 3.三处 4.其他
        @FP157_3 char(1)=null,  --约束工具 1.软式管  2.硬式管  3.背心  4.老人椅  5.约束带  6.其他
        @FP157_4 char(1)=null,  --约束原因 1.认知障碍 2.可能跌倒 3.行为紊乱 4.治疗需要 5.躁动6.医疗限制 7.其他
        @FP158 varchar(60)=null,  --重症监护室名称
        @FP158_1 char(1)=null,  --是否发生人工气道脱出 1.是 2.否
        @FP158_2 char(1)=null,  --是否非预期的重返重症医学科 1.是 2.否（注：指同一住院过程中转出ICU后的重返）
        @FP158_3 char(1)=null,  --重返间隔时间   0.非重返     1. 24h内     2. 24-48h     3. ＞48h
        @FP159 char(1)=null,  --手术及操作相关情况：是否发生围术期死亡 1.是  2.否
        @FP160 char(1)=null,  --是否发生术后猝死 1.是  2.否

        --以下为中医首页参数，默认为空值
        @FPZY_MZZDCode char(10)=null,       --中医门诊诊断代码
        @FPZY_MZZDName varchar(80)=null,    --中医门诊诊断名称
        @FPZY_ZLLB char(4)=null,            --中医治疗类别   1.1中医 1.2民族医 2.中西医 3.西医
        @FPZY_LCLJ char(1)=null,            --中医临床路径  1.中医 2.西医 3.否
        @FPZY_ZYZJ char(1)= null,           --中医中药制剂  1.是 2.否
        @FPZY_ZLSB char(1)=null,            --中医诊疗设备   1.是 2.否
        @FPZY_ZLJS char(1)=null,            --中医诊疗技术 1.是  2.否
        @FPZY_BZSH char(1)=null,             --中医辩证施护  1.是  2.否
        
        --以下参数为出院后复诊预约信息
        @SubsequentDate datetime=null,
        @SubsequentTime int=null,
        @SubsequentType int=null,
        @SubsequentKSCode varchar(10)=null,
        @SubsequentKSName varchar(20)=null,
        @Treatment varchar(128)=null
)
as
begin
  declare @t_fp0 int
  select @t_fp0=null
  select @t_fp0=fp0 from ba_fpage (nolock) where fp0=@fp0 and fp121 is not null and rtrim(fp121)<>''
  if @t_fp0 is not null and @YSFlag=0
     return -1  --已由病案室审核

  select @t_fp0=fp0 from ba_fpage (nolock) where fp0=@fp0 and fp131 is not null and rtrim(fp131)<>''
  if @t_fp0 is not null and @YSFlag=1
    return -2   --已由科室医师审核


  declare @t_age numeric(8,2)
  declare @t_FP25 datetime  --入院日期
  select @t_Fp25=FP25 from ba_fpage (nolock) where fp0=@fp0
  if datediff(year,@FP4, @t_FP25) > = 1 
    select @t_age= round(convert(numeric(10),datediff(day,@FP4, @t_FP25))/365,2)
  else
    select @t_age= abs(round(convert(numeric(10),datediff(day,@FP4, @t_FP25))/365,2))

  if @ysflag=0  --由病案室录入
  begin
    update ba_fpage
      set FP1 = @FP1,
          FP3 = FP3,
          FP4 = @FP4,
          FP5 = @t_age,
          FP5_Str = @FP5_Str,
          FP6 = @FP6,
          FP6_Name = @FP6_NAME,
          FP8 = @FP8,
          FP9 = @FP9,
          FP9_Name = @FP9_Name,
          FP10 = @FP10,
          FP10_Name = @FP10_Name,
          FP11 = @FP11,
          FP11_Name = @FP11_Name,
          FP12 = @FP12,
          FP14 = @FP14,

          FP14_PostCode = @FP14_PostCode,
          FP15 = @FP15,
          FP17 = @FP17,
          FP17_Name = @FP17_Name,
          FP17_PostCode = @FP17_PostCode,
          FP22 = @FP22,
          FP22_1 = @FP22_1,
          FP22_2 = @FP22_2,
          FP22_3 = @FP22_3,
          FP27 = @FP27,
          FP36 = @FP36,
          FP36_NAME = @FP36_Name,
          FP37 = @FP37,
          FP37_NAME = @FP37_Name,
          FP40 = @FP40,
          FP53 = @FP53,
          FP53_NAME = @FP53_NAME,
          FP54 = @FP54,
          FP69 = @FP69,
          FP70 = @FP70,
          FP71 = @FP71,
          FP72 = @FP72,
          FP73 = @FP73,
          FP74 = @FP74,
          FP75 = @FP75,
          FP76 = @FP76,
          FP76_1=@FP76_1,
          FP77 = @FP77,
          FP80 = @FP80,
          FP81 = @FP81,
          FP82 = @FP82,
          FP83 = @FP83,
          FP84 = @FP84,
          FP85 = @FP85,
          FP86 = @FP86,
          FP87 = @FP87,
          FP90 = @FP90,
          FP93 = @FP93,
          FP94 = @FP94,
          FP95 = @FP95,
          FP96 = @FP96,
          FP97 = @FP97,
          FP98 = @FP98,
          FP114 = @FP114,
          FP115 = @FP115,
          FP116 = @FP116,
          FP117 = @FP117,
          FP118_KZR = @FP118_KZR,
          FP118_ZRYS = @FP118_ZRYS,
          FP118_ZZYS = @FP118_ZZYS,
          FP118 = @FP118,
          FP120 = @FP120,
          FP122 = @FP122,
          Nationality_YS = @Nationality_YS,
          FP125 = @FP125,  --病历回收日期
          Note = @Note,
          PersonNo = case when @PersonNo is null then PersonNo else @PersonNo end,
          FP129 = @FP129,            --病理诊断代码
          FP129_Name = @FP129_Name,  --病理诊断代码对应的名称
          FP130 = @FP130,        --是否药物过敏  （1无  2有 则必须输入FP130_YS)
          FP130_YS = @FP130_YS,
          FP134 = @FP134,        --新生儿出生体重
          FP135 = @FP135,        --新生儿入院体重
          FP136 = @FP136,        --籍贯
          FP137 = @FP137,        --现住址编码
          FP137_Name = @FP137_Name,        --现住址编码对应的名称
          FP138 = @FP138,        --现住址电话
          FP139 = @FP139,        --现住址邮编
          FP140 = @FP140,        --入院途径
          FP141 = @FP141,        --病理号
          FP142 = @FP142,        --离院方式
          FP142_Name= @FP142_Name,     --离院方式对应的拟接收医疗机构名称
          FP143 = @FP143,              --再住院计划标志
          FP143_Name = @FP143_Name,    --再住院计划对应的目的
          FP144_D = @FP144_D ,                --入院前昏迷时间(天）
          FP144_H = @FP144_H ,                --入院前昏迷时间(小时）
          FP144_M = @FP144_M ,                --入院前昏迷时间(分钟）

          FP145_D = @FP145_D ,                --入院后昏迷时间(天）
          FP145_H = @FP145_H ,                --入院后昏迷时间(小时）
          FP145_M = @FP145_M ,                --入院后昏迷时间(分钟）
          FP146 = @FP146,              --是否临床路径管理
          FP146_Day = @FP146_Day,      --临床路径住院天使
          FP147 = @FP147,              --产科新生儿离院方式
          FP148 = @FP148,              --本次住院距上次住院时间
          FP149 = @FP149,              --责任护士
          FP150 = @FP150,              --质控日期
          Ver = @ver,                   --首页版本号（新首页为“2012”）

          FP95_1 = @FP95_1,  --住院期间是否出现危重 1.是  2.否  (FP94:抢救次数 FP95：成功次数）
          FP146_1 =@FP146_1,  --是否完成临床路径 1.是 2.否　FP146为是否实施临床路径
          FP146_2 = @FP146_2,  --退出临床路径原因  FP146为是否实施临床路径
          FP146_3 = @FP146_3,  --临床路径是否变异 1.是 2.否　FP146为是否实施临床路径
          FP146_4 = @FP146_4,  --临床路径变异原因  FP146为是否实施临床路径
          FP148_1 = @FP148_1,  --上一次住本院与本次住院是否因同一疾病(主要诊断) 1.是  2.否
          FP151   = @FP151,  --Ⅰ类手术切口预防性应用抗菌药物 1.是 2.否
          FP151_1 = @FP151_1,  --Ⅰ类手术切口预防性应用抗菌药物持续时间小时
          FP151_2 = @FP151_2,  --联合用药： 1.是 2.否
          FP152   = @FP152,  --住院期间是否应用抗菌药物  1.是 2.否
          FP152_1 = @FP152_1,  --住院期间是否应用抗菌药物持续时间小时
          FP152_2 = @FP152_2,  --联合用药： 1.是 2.否
          FP153   = @FP153,  --住院期间是否输液 1.是 2.否
          FP153_1 = @FP153_1,  --是否发生输液反应 1.是 2.否
          FP154   = @FP154,  --住院期间是否输血 1.是 2.否
          FP154_1 = @FP154_1,  -- 是否发生输血反应：1.是 2.否
          FP155   = @FP155,  --是否有压疮 1.是 2.否
          FP155_1 = @FP155_1,  --压疮发生时间 1.入院前 2.住院期间
          FP155_2 = @FP155_2,  --压疮分期 1. 1期  2. 2期  3. 3期  4. 4期
          FP156   = @FP156,  --住院期间是否发生跌倒或坠床 1.是  2.否
          FP156_1 = @FP156_1,  --住院期间跌倒或坠床的伤害程度 0.未造成伤害 1. 一级 2. 二级 3. 三级
          FP156_2 = @FP156_2,  --跌倒或坠床的原因 □ 1.健康原因 2.治疗、药物、麻醉原因 3.环境因素 4.其他原因
          FP157   = @FP157,  --住院期间是否使用物理约束 □ 1.是  2.否
          FP157_1 = @FP157_1,  --约束总时间小时
          FP157_2 = @FP157_2,  --约束方式 1.一处 2.两处 3.三处 4.其他
          FP157_3 = @FP157_3,  --约束工具 1.软式管  2.硬式管  3.背心  4.老人椅  5.约束带  6.其他
          FP157_4 = @FP157_4,  --约束原因 1.认知障碍 2.可能跌倒 3.行为紊乱 4.治疗需要 5.躁动6.医疗限制 7.其他
          FP158   = @FP158,  --重症监护室名称
          FP158_1 = @FP158_1,  --是否发生人工气道脱出 1.是 2.否
          FP158_2 = @FP158_2,  --是否非预期的重返重症医学科 1.是 2.否（注：指同一住院过程中转出ICU后的重返）
          FP158_3 = @FP158_3,  --重返间隔时间   0.非重返     1. 24h内     2. 24-48h     3. ＞48h
          FP159   = @FP159,  --手术及操作相关情况：是否发生围术期死亡 1.是  2.否
          FP160   = @FP160,  --是否发生术后猝死 1.是  2.否

          --以下为中医首页增加内容
         FPZY_MZZDCode=@FPZY_MZZDCode,    --中医门诊诊断代码
         FPZY_MZZDName=@FPZY_MZZDName,    --中医门诊诊断名称
         FPZY_ZLLB=@FPZY_ZLLB,            --中医治疗类别   1.1中医 1.2民族医 2.中西医 3.西医
         FPZY_LCLJ=@FPZY_LCLJ,            --中医临床路径  1.中医 2.西医 3.否
         FPZY_ZYZJ=@FPZY_ZYZJ,            --中医中药制剂  1.是 2.否
         FPZY_ZLSB=@FPZY_ZLSB,            --中医诊疗设备   1.是 2.否
         FPZY_ZLJS=@FPZY_ZLJS,            --中医诊疗技术 1.是  2.否
         FPZY_BZSH=@FPZY_BZSH             --中医辩证施护  1.是  2.否

      where fp0=@FP0
  end else  --由医师录入
  begin
    update ba_fpage
      set FP3 = FP3,
          FP4 = @FP4,
          FP5 = @t_age,
          FP5_Str = @FP5_Str,
          FP6 = case when @FP6 is null then FP6 else @FP6 end,
          FP6_Name = @FP6_NAME,
          FP8 = @FP8,
          FP9 = @FP9,
          FP9_Name = @FP9_Name,
          FP9_YS = @FP9_YS,
          FP10_YS = @FP10_YS,
          FP11 = @FP11,
          FP11_Name = @FP11_Name,
          FP11_YS = @FP11_YS,
          FP12 = @FP12,
          FP14 = @FP14,
          FP14_PostCode = @FP14_PostCode,
          FP15 = @FP15,
          FP17_YS = @FP17_YS,
          FP17_PostCode = @FP17_PostCode,
          FP22 = @FP22,
          FP22_1 = @FP22_1,
          FP22_2 = @FP22_2,
          FP22_3 = @FP22_3,
          FP27 = @FP27,
          FP36 = @FP36,
          FP36_Name = @FP36_Name,
          FP36_YS = @FP36_YS,
          FP37 = @FP37,
          FP37_Name = @FP37_Name,
          FP37_YS = case when @FP37_YS is null then FP37_YS else @FP37_YS end,
          FP40 = @fp40,
          FP53_YS = @FP53_YS,
          FP54 = @FP54,
          FP55_YS = @FP55_YS,
          FP69 = @FP69,
          FP70 = @FP70,
          FP71 = @FP71,
          FP72 = @FP72,
          FP73 = @FP73,
          FP74 = @FP74,
          FP75 = @FP75,
          FP76 = @FP76,
          FP76_1=@FP76_1,
          FP77 = @FP77,
          FP80 = @FP80,
          FP82 = @FP82,
          FP83 = @FP83,
          FP84 = @FP84,
          FP85 = @FP85,
          FP86 = @FP86,
          FP87 = @FP87,
          FP93 = @FP93,
          FP94 = @FP94,
          FP95 = @FP95,
          FP96 = @FP96,
          FP97 = @FP97,
          FP98 = @FP98,
          FP114 = @FP114,
          FP115 = @FP115,
          FP116 = @FP116,
          FP117 = @FP117,
          FP118_KZR = @FP118_KZR,
          FP118_ZRYS = @FP118_ZRYS,
          FP118_ZZYS = @FP118_ZZYS,
          FP118 = @FP118,
          FP122 = @FP122,
          Nationality_YS = @Nationality_YS,
          PersonNo = case when @PersonNo is null then PersonNo else @PersonNo end,
          FP129 = @FP129,
          FP129_Name = @FP129_Name,
          FP129_YS=@FP129_YS,
          FP130 = @FP130,        --是否药物过敏  （1无  2有 则必须输入FP130_YS)
          FP130_YS=@FP130_YS,
          FP134 = @FP134,        --新生儿出生体重
          FP135 = @FP135,        --新生儿入院体重
          FP136 = @FP136,        --籍贯
          FP137_YS = @FP137_YS,  --现住址名称
          FP138 = @FP138,        --现住址电话
          FP139 = @FP139,        --现住址邮编
          FP140 = @FP140,        --入院途径
          FP141 = @FP141,        --病理号
          FP142 = @FP142,        --离院方式
          FP142_Name= @FP142_Name,     --离院方式对应的拟接收医疗机构名称
          FP143 = @FP143,              --再住院计划标志
          FP143_Name = @FP143_Name,    --再住院计划对应的目的
          FP144_D = @FP144_D ,                --入院前昏迷时间(天）
          FP144_H = @FP144_H ,                --入院前昏迷时间(小时）
          FP144_M = @FP144_M ,                --入院前昏迷时间(分钟）
          FP145_D = @FP145_D ,                --入院后昏迷时间(天）
          FP145_H = @FP145_H ,                --入院后昏迷时间(小时）
          FP145_M = @FP145_M ,                --入院后昏迷时间(分钟）
          FP146 = @FP146,              --是否临床路径管理
          FP146_Day = @FP146_Day,      --临床路径住院天使
          FP147 = @FP147,              --产科新生儿离院方式
          FP148 = @FP148,              --本次住院距上次住院时间
          FP149 = @FP149,              --责任护士
          FP150 = @FP150,              --质控日期
          Ver = @ver,                   --首页版本号（新首页为“2012”）

          FP95_1 = @FP95_1,  --住院期间是否出现危重 1.是  2.否  (FP94:抢救次数 FP95：成功次数）
          FP146_1 =@FP146_1,  --是否完成临床路径 1.是 2.否　FP146为是否实施临床路径
          FP146_2 = @FP146_2,  --退出临床路径原因  FP146为是否实施临床路径
          FP146_3 = @FP146_3,  --临床路径是否变异 1.是 2.否　FP146为是否实施临床路径
          FP146_4 = @FP146_4,  --临床路径变异原因  FP146为是否实施临床路径
          FP148_1 = @FP148_1,  --上一次住本院与本次住院是否因同一疾病(主要诊断) 1.是  2.否
          FP151   = @FP151,  --Ⅰ类手术切口预防性应用抗菌药物 1.是 2.否
          FP151_1 = @FP151_1,  --Ⅰ类手术切口预防性应用抗菌药物持续时间小时
          FP151_2 = @FP151_2,  --联合用药： 1.是 2.否
          FP152   = @FP152,  --住院期间是否应用抗菌药物  1.是 2.否
          FP152_1 = @FP152_1,  --住院期间是否应用抗菌药物持续时间小时
          FP152_2 = @FP152_2,  --联合用药： 1.是 2.否
          FP153   = @FP153,  --住院期间是否输液 1.是 2.否
          FP153_1 = @FP153_1,  --是否发生输液反应 1.是 2.否
          FP154   = @FP154,  --住院期间是否输血 1.是 2.否
          FP154_1 = @FP154_1,  -- 是否发生输血反应：1.是 2.否
          FP155   = @FP155,  --是否有压疮 1.是 2.否
          FP155_1 = @FP155_1,  --压疮发生时间 1.入院前 2.住院期间
          FP155_2 = @FP155_2,  --压疮分期 1. 1期  2. 2期  3. 3期  4. 4期
          FP156   = @FP156,  --住院期间是否发生跌倒或坠床 1.是  2.否
          FP156_1 = @FP156_1,  --住院期间跌倒或坠床的伤害程度 0.未造成伤害 1. 一级 2. 二级 3. 三级
          FP156_2 = @FP156_2,  --跌倒或坠床的原因 □ 1.健康原因 2.治疗、药物、麻醉原因 3.环境因素 4.其他原因
          FP157   = @FP157,  --住院期间是否使用物理约束 □ 1.是  2.否
          FP157_1 = @FP157_1,  --约束总时间小时
          FP157_2 = @FP157_2,  --约束方式 1.一处 2.两处 3.三处 4.其他
          FP157_3 = @FP157_3,  --约束工具 1.软式管  2.硬式管  3.背心  4.老人椅  5.约束带  6.其他
          FP157_4 = @FP157_4,  --约束原因 1.认知障碍 2.可能跌倒 3.行为紊乱 4.治疗需要 5.躁动6.医疗限制 7.其他
          FP158   = @FP158,  --重症监护室名称
          FP158_1 = @FP158_1,  --是否发生人工气道脱出 1.是 2.否
          FP158_2 = @FP158_2,  --是否非预期的重返重症医学科 1.是 2.否（注：指同一住院过程中转出ICU后的重返）
          FP158_3 = @FP158_3,  --重返间隔时间   0.非重返     1. 24h内     2. 24-48h     3. ＞48h
          FP159   = @FP159,  --手术及操作相关情况：是否发生围术期死亡 1.是  2.否
          FP160   = @FP160,  --是否发生术后猝死 1.是  2.否

          --以下为中医首页增加内容
         FPZY_MZZDCode=@FPZY_MZZDCode,    --中医门诊诊断代码
         FPZY_MZZDName=@FPZY_MZZDName,    --中医门诊诊断名称
         FPZY_ZLLB=@FPZY_ZLLB,            --中医治疗类别   1.1中医 1.2民族医 2.中西医 3.西医
         FPZY_LCLJ=@FPZY_LCLJ,            --中医临床路径  1.中医 2.西医 3.否
         FPZY_ZYZJ=@FPZY_ZYZJ,            --中医中药制剂  1.是 2.否
         FPZY_ZLSB=@FPZY_ZLSB,            --中医诊疗设备   1.是 2.否
         FPZY_ZLJS=@FPZY_ZLJS,            --中医诊疗技术 1.是  2.否
         FPZY_BZSH=@FPZY_BZSH             --中医辩证施护  1.是  2.否
      where fp0=@FP0



    --当医师录入时重新更新一下两字段的对应的名称
    update ba_fpage
      set fp36_name=name
      from ba_fpage,ba_allcode
      where fp0=@FP0 and fp36=code and flag='ICD10' and fp36 is not null and rtrim(fp36)<>''

    update ba_fpage
      set fp37_name=name
      from ba_fpage,ba_allcode
      where fp0=@FP0 and fp37=code and flag='ICD10' and fp37 is not null and rtrim(fp37)<>''
  end

  --重新初始化tjm
  update _BA_Diagnose
    set tjm=ba_allcode.tjm
    from _BA_Diagnose,ba_allcode
    where diagnosecode=code and flag='ICD10' and UserID=@userid
    

  delete ba_diagnose where zynum=@fp0
  if @ysflag=0  --由病案室录入
  begin
    insert ba_diagnose(ZYNum,DiagnoseCode,DiagnoseName,State,CaseCode,CaseName,MCode,MName,tjm,
                       DiagnoseCode_YS,DiagNoseName_YS,MCode_YS,MName_YS,CaseCode_YS,CaseName_YS,condition,order_ys,order_ba,ordernum_ys)
      select @FP0,DiagnoseCode,DiagnoseName,State,CaseCode,CaseName,MCode,MName,tjm,
             DiagnoseCode_YS,DiagNoseName_YS,MCode_YS,MName_YS,CaseCode_YS,CaseName_YS,condition,Order_YS,Order_BA,ordernum_ys
        from _ba_diagnose (nolock)
        where userid=@userid
        order by Order_BA
        
    update _BA_Diagnose
      set KeyNo_Order=Order_BA
      where UserID=@userid
  end else  --由医师录入
  begin
    insert ba_diagnose(ZYNum,diagnosecode,diagnosename,State,mcode,mname,casecode,casename,
           DiagnoseCode_YS,DiagnoseName_YS,condition,MCode_YS,MName_YS,CaseCode_YS,CaseName_YS,order_ys,order_ba,tjm,ordernum_ba)
      select @FP0,diagnosecode,diagnosename,State,mcode,mname,casecode,casename,
           DiagnoseCode_YS,DiagnoseName_YS,condition,MCode_YS,MName_YS,CaseCode_YS,CaseName_YS,Order_YS,Order_YS/*注意此处以医师排序*/,tjm,ordernum_ba
        from _ba_diagnose (nolock)
        where userid=@userid
        order by Order_YS
        
    update _BA_Diagnose
      set KeyNo_Order=Order_YS
      where UserID=@userid
  end

  delete ba_diagnose_zy where zynum=@fp0
  insert ba_diagnose_zy(ZYNum,JBCode,JBName,ZHCode,ZHName,Condition)
    select @fp0,JBCode,JBName,ZHCode,ZHName,Condition from _ba_diagnose_zy where userid=@userid


  --更新BA_Fpage表的诊断信息
  if @ysflag=0  --由病案室录入时
  begin
    --初始化诊断字段
    update ba_fpage
      set fp41=null,fp41_name=null,fp41_tjm=null,fp52=null,fp52_name=null,fp55=null,fp55_name=null,
          fp43=null,fp43_name=null,fp44=null,
          fp45=null,fp45_name=null,fp46=null
      where fp0=@fp0
  end

  --重新更新统计码
  update ba_diagnose
    set tjm=ba_allcode.tjm
    from ba_diagnose,ba_allcode
    where diagnosecode=code and flag='ICD10' and zynum=@fp0


  --从_Ba_diagnose表中更新诊断字段
  declare @t_count int
  declare @diagnosecode char(20)
  declare @diagnosename varchar(100)
  declare @diagnosename_ys varchar(200)
  declare @state char(10)
  declare @casecode char(10)
  declare @casename char(60)
  declare @mcode char(10)
  declare @mname char(60)
  declare @tjm char(10)
  declare @fp41_condition char(1)
  declare @t_keyno_order numeric(12,0)

  declare @casecode_ys char(10)
  declare @casename_ys varchar(60)
  declare @mcode_ys char(10)
  declare @mname_ys char(60)

  DECLARE diagnose_cursor CURSOR FOR
    select diagnosecode,diagnosename,diagnosename_ys,state,casecode,casename,
           mcode,mname,tjm,condition,keyno_order,casecode_ys,casename_ys,mcode_ys,mname_ys
      from _ba_diagnose (nolock)
      where userid=@userid
      order by keyno_order

  OPEN diagnose_cursor
  FETCH NEXT FROM diagnose_cursor into @diagnosecode,@diagnosename,@diagnosename_ys,@state,@casecode,@casename,@mcode,@mname,@tjm,@fp41_condition,@t_keyno_order,@casecode_ys,@casename_ys,@mcode_ys,@mname_ys
  set @t_count=1
  WHILE @@FETCH_STATUS = 0
  BEGIN
    if @ysflag=0  --由病案室录入时
    begin
      if @diagnosecode is not null
      begin
        if @t_count = 1  --主要诊断
          update ba_fpage
            set fp41=@diagnosecode,fp41_name=@diagnosename,fp41_tjm=@tjm,fp42=@state,fp52=@mcode,fp52_name=@mname,fp55=@casecode,fp55_name=@casename,
                fp41_condition=@fp41_condition
            where fp0=@fp0

        if @t_count =2   --次要诊断1
          update ba_fpage
            set fp43=@diagnosecode,fp43_name=@diagnosename,fp44=@state
            where fp0=@fp0

        if @t_count =3   --次要诊断2
          update ba_fpage
            set fp45=@diagnosecode,fp45_name=@diagnosename,fp46=@state
            where fp0=@fp0

        update ba_diagnose
          set orderNum_BA=@t_count
          where zynum=@fp0 and order_ba=@t_keyno_order

  
        set @t_count=@t_count + 1
      end
    end else  --由医师录入
    begin
      if @diagnosename_ys is not null
      begin
        if @t_count = 1  --主要诊断
          update ba_fpage
            set FP41_YS=@diagnosename_YS,FP52_YS=@mname
            where fp0=@fp0
      
        if @t_count = 2  --次要诊断1
          update ba_fpage
            set FP43_YS = @diagnosename_YS
            where fp0=@fp0

        if @t_count = 3  --次要诊断2
          update ba_fpage
            set FP45_YS = @diagnosename_ys
            where fp0=@fp0

      
        update ba_diagnose
          set orderNum_YS=@t_count
          where zynum=@fp0 and order_ys=@t_keyno_order

        if @t_count=1
          update ba_fpage
            set fp55=@casecode_ys,fp55_name=@casename,fp55_YS=case when @casecode_ys is not null and rtrim(@casecode_ys)<>'' then @casename_ys else FP55_YS end
            where fp0=@fp0

        set @t_count=@t_count + 1
      end
    end

    FETCH NEXT FROM diagnose_cursor into @diagnosecode,@diagnosename,@diagnosename_ys,@state,@casecode,@casename,@mcode,@mname,@tjm,@fp41_condition,@t_keyno_order,@casecode_ys,@casename_ys,@mcode_ys,@mname_ys
  END
  CLOSE diagnose_cursor
  DEALLOCATE diagnose_cursor


  delete ba_operation where zynum=@fp0
  if @ysflag=0    --由病案室录入
  begin
    insert ba_operation(ZYNum,OperationCode,OperationName,OperationPositionCode,OperationPositionName,OperationDate,OperationOperName,OperationHelper,
                        OperationHelper2,AnaesthesiaCode,AnaesthesiaName,CutCode,CutName,AnaesthesiaDoctor,OperationCode_YS,OperationName_YS,OperationLevel,
                        F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,ordernum_ys,order_ys,order_ba,OperationContinuousTime,F4_1,F4_2)
      select @FP0,OperationCode,OperationName,OperationPositionCode,OperationPositionName,OperationDate,OperationOperName,OperationHelper,
             OperationHelper2,AnaesthesiaCode,AnaesthesiaName,CutCode,CutName,AnaesthesiaDoctor,OperationCode_YS,OperationName_YS,OperationLevel,
             F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,ordernum_ys,order_ys,Order_BA,OperationContinuousTime,F4_1,F4_2
        from _ba_operation (nolock)
        where userid=@userid
        order by Order_BA
        
    update _ba_operation
      set keyno_order=order_ba
      where userid=@userid
  end else            --由医师录入
  begin
    insert ba_operation(ZYNum,operationcode,operationname,OperationPositionCode,OperationPositionName,OperationDate,OperationOperName,OperationHelper,
                        OperationHelper2,AnaesthesiaCode,AnaesthesiaName,CutCode,CutName,AnaesthesiaDoctor,OperationCode_YS,OperationName_YS,OperationLevel,
                        F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,order_ys,order_ba,OrderNum_BA,OperationContinuousTime,F4_1,F4_2)
      select @FP0,operationcode,operationname,OperationPositionCode,OperationPositionName,OperationDate,OperationOperName,OperationHelper,
             OperationHelper2,AnaesthesiaCode,AnaesthesiaName,CutCode,CutName,AnaesthesiaDoctor,OperationCode_YS,OperationName_YS,OperationLevel,
             F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,Order_YS,Order_YS/*注意此处以医师排序*/,OrderNum_BA,OperationContinuousTime,F4_1,F4_2
        from _ba_operation (nolock)
        where userid=@userid
        order by Order_YS

    update _ba_operation
      set keyno_order=order_ys
      where userid=@userid
  end

  /*更新BA_Fpage表的手术信息*/
  --1、初始化手术字段
  if @ysflag=0  --由病案室录入时
    update ba_fpage
      set fp56=null,fp57=null,fp57_name=null,fp58=null,fp58_oper=null,fp59=null,fp60=null,fp61=null,
          fp63=null,fp64=null,fp64_name=null,fp65=null,fp65_oper=null,fp66=null,fp67=null,fp68=null
       where fp0=@fp0

  --2、从_ba_operation中更新手术信息
  declare @OperationCode char(10)
  declare @OperationName varchar(100)
  declare @OperationName_YS varchar(200)
  declare @OperationDate datetime
  declare @OperationOperName char(10)
  declare @operationHelper char(10)
  declare @AnaesthesiaCode char(10)
  declare @CutCode char(10)
  declare @AnaesthesiaDoctor char(10)
  declare @t_keyno_order2 numeric(12)



  DECLARE operation_cursor CURSOR FOR
  select OperationCode,OperationName,OperationName_YS,OperationDate,OperationOperName,OperationHelper,
         AnaesthesiaCode,CutCode,AnaesthesiaDoctor,keyno_order
    from _ba_operation (nolock)
    where userid=@userid
    order by keyno_order


  OPEN operation_cursor
  FETCH NEXT FROM operation_cursor into 
                  @OperationCode,@OperationName,@OperationName_YS,@OperationDate,@OperationOperName,@operationHelper,
                  @AnaesthesiaCode,@CutCode,@AnaesthesiaDoctor,@t_keyno_order2
  set @t_count=1
  WHILE @@FETCH_STATUS = 0
  BEGIN
    if @ysflag=0  --由病案室录入时
    begin
      if @operationcode is not null
      begin
        if @t_count = 1  --手术一

          update ba_fpage
            set fp56=@operationdate,
                fp57=@operationcode,
                fp57_name=@operationname,
                fp58=@AnaesthesiaCode,
                fp58_oper=@AnaesthesiaDoctor,
                fp59=@CutCode,
                fp60=@OperationOperName,
                fp61=@operationHelper
             where fp0=@fp0
    
        if @t_count =2   --手术二
          update ba_fpage
            set fp63=@operationdate,
                fp64=@operationcode,
                fp64_name=@operationname,
                fp65=@AnaesthesiaCode,
                fp65_oper=@AnaesthesiaDoctor,
                fp66=@CutCode,
                fp67=@OperationOperName,
                fp68=@operationHelper
             where fp0=@fp0

        update ba_operation
          set ordernum_ba=@t_count
          where zynum=@fp0 and order_ba=@t_keyno_order2

    
        set @t_count=@t_count + 1
      end
    end else  --由医师录入时
    begin
      if @operationname_ys is not null
      begin
        update ba_operation
          set ordernum_YS=@t_count
          where zynum=@fp0 and order_ys=@t_keyno_order2

        set @t_count=@t_count + 1
      end
    end

    FETCH NEXT FROM operation_cursor into 
                    @OperationCode,@OperationName,@OperationName_YS,@OperationDate,@OperationOperName,@operationHelper,
                    @AnaesthesiaCode,@CutCode,@AnaesthesiaDoctor,@t_keyno_order2
  END
  CLOSE operation_cursor
  DEALLOCATE operation_cursor
  
  
  --以下为出院后复诊预约信息
  if @SubsequentDate is not null
  begin
    delete Patient_Subsequent where zynum=@fp0
    
    insert Patient_Subsequent(zynum,subsequentdate,subsequenttime,type,subsequentkscode,subsequentksname,treatment,opername,operdate)
      values(@fp0,@SubsequentDate,@SubsequentTime,@SubsequentType,@SubsequentKSCode,@SubsequentKSName,@Treatment,@opername,getdate())
  end
 
  return 0
end
GO
