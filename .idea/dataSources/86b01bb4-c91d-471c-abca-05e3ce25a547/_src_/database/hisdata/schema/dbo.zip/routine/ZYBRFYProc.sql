CREATE   PROCEDURE [dbo].[ZYBRFYProc]
(@userid numeric(18),@opername char(10)='',@operdate datetime,@yfcode char(4))
AS
begin
  if not exists(select keyno from _zyfysheet (nolock) where userid=@userid and fycheckflag=1)
    return 1

  if exists(select keyno from zycfypk 
              where keyno in(select _keyno from _zyfysheet where jsflag is null and userid=@userid and fycheckflag=1) 
                and deldate is not null)
    return 2  /*在审核发药时前台操作员又进行了删除操作*/

  declare @t_count1 int
  declare @t_count2 int
  select @t_count1=count(*) from _zyfysheet (nolock) where userid=@userid and fycheckflag=1 and jsflag is null
  select @t_count2=count(*) from _zyfysheet,zycfypk (nolock)
    where zycfypk.keyno=_keyno and userid=@userid and fycheckflag=1 and jsflag is null

  if @t_count1<>@t_count2
    return 3  /*在发药时如果出现住院数据结转则可能出现此情况*/

  if exists(select keyno from zycfypk (nolock) where keyno in(select _keyno from _zyfysheet (nolock) where userid=@userid and fycheckflag=1 and jsflag is null) and fydate is not null)
    return 4  /*药房两个以上窗口发药时可能出现重叠发药*/

  if exists(select keyno from zycfypkhis (nolock) where keyno in(select _keyno from _zyfysheet (nolock) where userid=@userid and fycheckflag=1 and jsflag=1) and fydate is not null)
    return 4  /*药房两个以上窗口发药时可能出现重叠发药*/


  declare @t_fyno int
  execute GetUniqueNo 32,@NewUniqueNo=@t_fyno output
  
  update zycfypk
    set fydate=@operdate,fyopername=@opername,putdrugflag=_zyfysheet.putdrugflag,fyno=@t_fyno
    from zycfypk,_zyfysheet
    where zycfypk.keyno=_keyno and jsflag is null and userid=@userid and fycheckflag=1

  if exists(select _keyno from _zyfysheet  where jsflag=1 and userid=@userid and fycheckflag=1)
    update zycfypkhis
      set fydate=@operdate,fyopername=@opername,fyno=@t_fyno
      from zycfypkhis,_zyfysheet
      where zycfypkhis.keyno=_keyno and jsflag=1 and userid=@userid and fycheckflag=1

  /***Compute the count of the fy***/
  select goodsno,sum(ypcount) as sumypcount 
    into #cfypcount
    from _zyfysheet
    where userid=@userid and fycheckflag=1
    group by goodsno

  update yfstore
    set a16=a16-sumypcount
    from yfstore,#cfypcount
    where goodsno=a01 and a10=@yfcode

  update _zyfysheet
    set fydate=@operdate,fyopername=@opername
    where userid=@userid and fycheckflag=1
  return 0
end
GO
