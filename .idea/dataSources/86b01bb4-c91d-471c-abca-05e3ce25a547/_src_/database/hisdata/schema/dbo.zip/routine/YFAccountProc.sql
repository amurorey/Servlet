CREATE PROCEDURE [dbo].[YFAccountProc]
(@goodsno char(10),@yfcode char(2),@turnyear int,@begdate datetime,@enddate datetime)
AS
begin
  select convert(datetime,convert(char(10),fpdate,111)) as sheetdate,ypcount*cfcount as ypcount,
         ypprice_1 as pjprice,ypprice as ljprice,ypcount*cfcount*ypprice_1 as pjmoney,
         ypcount*cfcount*ypprice as ljmoney
    into #cfypktab
    from mzcfypk (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and fpdate>=@begdate and fpdate<@enddate and deldate is null
  union all
  select convert(datetime,convert(char(10),fpdate,111)) as sheetdate,ypcount*cfcount as ypcount,
         ypprice_1 as pjprice,ypprice as ljprice,ypcount*cfcount*ypprice_1 as pjmoney,
         ypcount*cfcount*ypprice as ljmoney
    from mzcfypkhis (nolock)    where goodsno=@goodsno and yfcode=@yfcode and fpdate>=@begdate and fpdate<@enddate and deldate is null
  union all  select convert(datetime,convert(char(10),jzdate,111)) as sheetdate,ypcount*cfcount as ypcount,
         ypprice_1 as pjprice,ypprice as ljprice,ypcount*cfcount*ypprice_1 as pjmoney,
         ypcount*cfcount*ypprice as ljmoney
    from zycfypk (nolock)    where goodsno=@goodsno and yfcode=@yfcode and jzdate>=@begdate and jzdate<@enddate and deldate is null
  union all
  select convert(datetime,convert(char(10),jzdate,111)) as sheetdate,ypcount*cfcount as ypcount,
         ypprice_1 as pjprice,ypprice as ljprice,ypcount*cfcount*ypprice_1 as pjmoney,
         ypcount*cfcount*ypprice as ljmoney
    from zycfypkhis (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and jzdate>=@begdate and jzdate<@enddate and deldate is null

  select '          ' as sheetno,turndate as sheetdate,'上年结转' as note,'' as note_,
         0 as quantity1,0 as price1,0 as price1_,0 as money1,0 as money1_,
         0 as quantity2,0 as price2,0 as price2_,0 as money2,0 as money2_,
         quantity as quantity3,price1 as price3,price2 as price3_,
         quantity*price1 as money3,quantity*price2 as money3_,0 as tjflag
    from yfturndata (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and turnyear=@turnyear
  union all
  select '          ' as sheetno,convert(datetime,convert(char(10),operdate,111)) as sheetdate,'药房期初数' as note,'' as note_,
         0 as quantity1,0 as price1,0 as price1_,0 as money1,0 as money1_,
         0 as quantity2,0 as price2,0 as price2_,0 as money2,0 as money2_,
         ypcount as quantity3,ypprice1 as price3,ypprice2 as price3_,ypmoney1 as money3,ypmoney2 as money3_,0 as tjflag
    from yfstart (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and operdate>=@begdate and operdate<@enddate
  union all
  select c02 as sheetno,convert(datetime,convert(char(10),c28,111)) as sheetdate,c25+'发往'+c10+c26 as note,'' as note_,
         c17*a13 as quantity1,c13_1 as price1,c16_1 as price1_,c13_1*c17_1 as money1,c16_1*c17_1 as money1_,         0 as quantity2,0 as price2,0 as price2_,0 as money2,0 as money2_,
         0 as quantity3,0 as price3,0 as price3_,0 as money3,0 as money3_,0 as tjflag
    from outstock,goods (nolock)
    where a01=c05 and c05=@goodsno and c09=@yfcode and c03>=@begdate and c03<@enddate
  union all
  select '          ' as sheetno,convert(datetime,convert(char(10),procdate,111)) as sheetdate,
         '(批价由'+rtrim(convert(char(10),oldprice2))+' 调为'+rtrim(convert(char(10),newprice2))+')'+rtrim(note) as note,
         '(零价由'+rtrim(convert(char(10),oldprice1))+' 调为'+rtrim(convert(char(10),newprice1))+')'+rtrim(note) as note_,
         0 as quantity1,0 as price1,0 as price1_,0 as money1,0 as money1_,
         0 as quantity2,0 as price2,0 as price2_,0 as money2,0 as money2_,         0 as quantity3,newprice2 as price3,newprice1 as price3_,money2 as money3,money1 as money3_,1 as tjflag
    from mzchangeprice (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and procdate>=@begdate and procdate<@enddate
  union all
  select '          ' as sheetno,sheetdate,'当日处方累计' as note,'' as note_,
         0 as quantity1,0 as price1,0 as price1_,0 as money1,0 as money1_,
         sum(ypcount) as quantity2,pjprice as price2,ljprice as price2_,
         sum(ypcount*pjprice) as money2,sum(ypcount*ljprice) as money2_,
         0 as quantity3,0 as price3,0 as price3_,0 as money3,0 as money3_,0 as tjflag
    from #cfypktab (nolock)
    group by sheetdate,pjprice,ljprice
  union all
  select sheetno as sheetno,procdate as sheetdate,flag+note as note,'' as note_,
         0 as quantity1,0 as price1,0 as price1_,0 as money1,0 as money1_,
         0 as quantity2,0 as price2,0 as price2_,0 as money2,0 as money2_,
         ypcount as quantity3,price1 as price3,price2 as price3_,ypcount*price1 as money3,ypcount*price2 as money3_,0 as tjflag
    from yfstorechange (nolock)
    where goodsno=@goodsno and yfcode=@yfcode and procdate>=@begdate and procdate<@enddate
  order by sheetdate
end
GO
