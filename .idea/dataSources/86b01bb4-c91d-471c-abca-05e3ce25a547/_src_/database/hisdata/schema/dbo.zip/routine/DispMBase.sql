CREATE PROCEDURE [dbo].[DispMBase] 
(@zynum int) with recompile
AS
begin
  declare @t_zgorjmflag int
  declare @t_yldyname varchar(40)
  select @t_yldyname=m02 from MBASE (nolock) where M01=@zynum
  select @t_zgorjmflag=zgorjmflag from YLDYCode (nolock) where DYName=@t_yldyname
  
  select *,
         case when m25 is not null then m25 else 0 end - case when m33 is not null then m33 else 0 end as leftmoney,
         (case when m27 is not null then m27 else 0 end +case when m50 is not null then m50 else 0 end -m33+m26) as leftyjmoney,
         case 
           when m30 is null then case when m25 is not null then m25 else 0 end-case when m50 is not null then m50 else 0 end-case when m27 is not null then m27 else 0 end
         else
           0
         end as qfmoney,@t_zgorjmflag as zgorjmflag
   from mbase (nolock) where m01=@zynum
end
GO
