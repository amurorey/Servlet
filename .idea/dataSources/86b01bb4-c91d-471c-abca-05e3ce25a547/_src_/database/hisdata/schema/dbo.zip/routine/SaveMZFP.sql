/*注意:冲单时OLDFPNUM不为0,且立刻进行发药处理*/
/*@allownotprnFP:允许不打印发票，1：允许*/
CREATE    PROCEDURE [dbo].[SaveMZFP] 
(@fpnum int,@userid numeric,@fpname varchar(100),@fpmoney numeric(12,2),
 @opername char(10),@retval varchar(1024)='' output,@currentdate datetime,
 @oldfpnum int=0,@ybflag int,@ybnum char(15),@jfcardid char(10)=null,@roundflag int=null,
 @ybareacode char(10)=null,@ybareaname char(20)=null,@zfmoney1 numeric(12,2),
 @zfmoney2 numeric(12,2)=null,@roundmoney numeric(12,2)=null,@mznum int=null,
 @yldyname char(20),@fpnum_tmp int=null,@yberror numeric(12,2)=null,@patientid nvarchar(10)=null,@transno varchar(40)=null,
 @reserveflag int=null,@zfmoney3 numeric(12,2)=null,@InvoiceNum varchar(20)=null,@InvoiceOperID int=null,@Sex varchar(4)=null,
 @allownotPrnFP int=null)
AS 
begin
  declare @t_fpmoney numeric(12,2)
  select @t_fpmoney=sum(summoney)
    from
      (select kmcode,kmname,(ypmoney*cfcount) as summoney,userid from _mzcfypk (nolock)
       union all
       select kmcode,kmname,checkmoney,userid from _mzcheck (nolock)) disp
    where userid=@userid
   if @t_fpmoney<>@fpmoney
     return -1  --发票金额不一致
  
  if exists(select mzmoreyfset from unitset where mzmoreyfset is null)
  begin
    /***库存不足判断***/
    if exists (select goodsno from _mzcfypgroupview,yfstore (nolock)
                 where _mzcfypgroupview.goodsno=yfstore.a01
                 and _mzcfypgroupview.yfcode=yfstore.a10 
                 and yfstore.a09<(_mzcfypgroupview.sumypcount)
                 and _mzcfypgroupview.userid=@userid)
    begin
      declare @t_disptext char(100)
      DECLARE checkyfstore_cursor CURSOR FOR
        select rtrim(yfstore.a11)+'"'+rtrim(yfstore.a02)+'"的库存为'+rtrim(convert(char(10),yfstore.a09))+'已不足' as disptext
          from _mzcfypgroupview,yfstore (nolock)
                 where _mzcfypgroupview.goodsno=yfstore.a01
                 and _mzcfypgroupview.yfcode=yfstore.a10 
                 and yfstore.a09<(_mzcfypgroupview.sumypcount)
                 and _mzcfypgroupview.userid=@userid
      OPEN checkyfstore_cursor
      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
      WHILE @@FETCH_STATUS = 0
      BEGIN
        select @retval=@retval+@t_disptext+char(13)

        FETCH NEXT FROM checkyfstore_cursor into @t_disptext
      END
      CLOSE checkyfstore_cursor
      DEALLOCATE checkyfstore_cursor

      return 1
    end

    /***有无库存判断***/
    if exists (select goodsno from _mzcfypk where userid=@userid and 
               goodsno not in(select a01 from yfstore,_mzcfypk (nolock) where goodsno=a01 and yfcode=a10))
    begin
      delete _checkyfstore where userid=@userid
      insert _checkyfstore
        select '"'+rtrim(goodsname)+'"在药房没有库存',@userid from _mzcfypk where userid=@userid and 
               goodsno not in(select a01 from yfstore,_mzcfypk (nolock) where goodsno=a01 and yfcode=a10)
      return 1
    end
  end


  if @oldfpnum <> 0  
  begin
    /***Check if the Invoice is deleted***/
    if exists(select fpnum from mzinvoice where fpnum=@oldfpnum and deldate is not null)
      return 3
    if exists(select fpnum from mzinvoicehis where fpnum=@oldfpnum and deldate is not null)
      return 3
    /***Check if the invoice is CD***/
    if exists(select fpnum from mzinvoice where fpnum=@oldfpnum and cdnum is not null)
      return 4
    if exists(select fpnum from mzinvoicehis where fpnum=@oldfpnum and cdnum is not null)
      return 4
  end

  /***门诊挂号明细***/
  declare @t_xmcode varchar(40)
  declare @t_kscode char(4)
  select @t_xmcode=null
  select @t_xmcode=groupcode,@t_kscode=fskscode from _mzcheck (nolock) where userid=@userid and groupcode in(select groupcode from checkgroupcode (nolock) where groupflag=5)
  
  /*如果是保山则24小时内同一科室不能挂其它医院为12小时*/
  declare @t_H int
  select @t_H=case when unitno='432695504' then 24 else 12 end from unitset
  
  if exists(select mznum from mzregistersheet where xmcode=@t_xmcode and patientid=@patientid and kscode=@t_kscode and deldate is null and datediff(hour,registerdate,getdate())<@t_H and (@oldfpnum=0 or @oldfpnum is null)
            and DATEPART(YEAR, RegisterDate)=datepart(YEAR,GETDATE()) and DATEPART(MONTH, RegisterDate)=datepart(MONTH,GETDATE()) and DATEPART(DAY, RegisterDate)=datepart(DAY,GETDATE()))
    return 5

  declare @t_curnum int
  if @InvoiceNum is not null
  begin
    select @t_curnum=isnull(curnum+1,BegNum) from Invoice_Operator where invoiceoperid=@InvoiceOperID and backflag is null and [TYPE]=0
    if convert(int,@InvoiceNum) <> @t_curnum
      return 6  --保存时发现当前号已被使用
    if @t_curnum is null
      return 7  --发票号异常
  end
  
  if @allownotPrnFP is null and exists(select InvoiceMangFlag from unitset where InvoiceMangFlag=1 or InvoiceMangFlag=2) and (@InvoiceNum is null or RTRIM(@InvoiceNum)='' or @InvoiceOperID is null or @InvoiceOperID=0)
    return 8 --启用发票管理后发票号不能空且批次号不能空

  if (@oldfpnum is null or @oldfpnum=0) and exists(select UserID from _MZCHECK (nolock) where USERID=@userid and yzflag=1 and YJApplyNum is not null and YJApplyNum not in(select applynum from Patient_ApplicationSheet (nolock) where MZNUM=@mznum))
    return 9 --保存发票时原检查申请单已被医师删除
  

  --将当前发票号写入表中Curnum字段
  if @InvoiceNum is not null
  begin
    update invoice_operator
      set curnum=@t_curnum
      where invoiceoperid=@InvoiceOperID
  end

  /*更新门诊材料临时表中的cfnum*/
  if exists(select cfnum from _mzcfypk where userid=@userid and cfnum=-1)
  begin
    declare @t_cfnum int
    execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output
    update _mzcfypk
      set cfnum=@t_cfnum
      where userid=@userid and cfnum=-1
  end
  /*-----------------------------------*/

  if @ybnum=''
    select @ybnum=null
  /***Insert into mzcfypk table***/

  update _mzcfypk
    set jbypflag=a37
    from _mzcfypk,goods
    where a01=goodsno and userid=@userid

  insert mzcfypk(fpnum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                 cfcount,goodsname,procname,unitname,yfcode,fpdate,
                 yscode,kmcode,kmname,ysname,yskscode,ysksname,jfcardid,yblb,yblbname,
                 ybno,ybkmcode,jbypflag,fskscode,fsksname,clflag,YZID,YPPath)
    select @fpnum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
           cfcount,goodsname,procname,unitname,yfcode,@currentdate,yscode,kmcode,kmname,
           ysname,yskscode,ysksname,@jfcardid,yblb,yblbname,
           ybno,ybkmcode,jbypflag,fskscode,fsksname,clflag,YZID,YPPath
      from _mzcfypk
      where userid=@userid
      order by keyno
  /***Insert into mzcfinf table***/
  insert mzcfinf(cfnum,fpnum,yscode,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,ysname,yskscode,ysksname,fpdate,fydate,fyopername)
    select _mzcfinf.CFNUM,@fpnum,yscode,cfflag,cfprice,cfcount,round(cfprice*cfcount,2),yfcode,yfname,ysname,yskscode,ysksname,@currentdate,yfcancddate,yfcancdopername
      from _mzcfinf,(select cfnum,COUNT(*) as ypcount from _MZCFYPK (nolock) where USERID=@userid group by CFNUM) disp
      where userid=@userid and _MZCFINF.CFNUM=disp.CFNUM and ypcount>0
      order by _mzcfinf.CFNUM
 
  update mzcfypk
    set fydate=mzcfinf.fydate
    from mzcfypk,mzcfinf where mzcfypk.cfnum=mzcfinf.cfnum and mzcfinf.fpnum=@fpnum

  update cardbase
    set totmoney=totmoney+@fpmoney where cardid=@jfcardid

  /**生成医技申请单号**/
  declare @t_yjapplynum int
  declare @t_fskscode numeric(4)
  DECLARE _mzcheck_cursor CURSOR FOR
    select fskscode
      from _mzcheck,kscode
      where fskscode=code and ksattrib=5 and userid=@userid and yzflag is null
      group by fskscode
  OPEN _mzcheck_cursor
  FETCH NEXT FROM _mzcheck_cursor into @t_fskscode
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 20,@NewUniqueNo=@t_yjapplynum output

    update _mzcheck
      set yjapplynum=@t_yjapplynum
      where fskscode=@t_fskscode and yzflag is null and userid=@userid  --仅对非医师开具的医技项目更新

    FETCH NEXT FROM _mzcheck_cursor into @t_fskscode
  END
  CLOSE _mzcheck_cursor
  DEALLOCATE _mzcheck_cursor

  /*** Insert into mzcheck table***/
  insert mzcheck(fpnum,checkno,checkprice,checkcount,checkmoney,yscode,fpdate,checkname,
                 kmname,kmcode,ysname,yskscode,ysksname,fskscode,fsksname,unitname,checklb,checklbname,
                 groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,yjapplynum)
    select @fpnum,checkno,checkprice,checkcount,checkmoney,yscode,@currentdate,checkname,
           kmname,kmcode,ysname,yskscode,ysksname,fskscode,fsksname,unitname,checklb,checklbname,
           groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,yjapplynum
      from _mzcheck
      where userid=@userid
      order by keyno

  /*
  if @oldfpnum=0 or @oldfpnum is null   --非冲单时
  begin
    update patient_applicationsheet
      set patientname=@fpname,yldyname=@yldyname
      where mznum=@mznum and mznum is not null
  end*/

  /*** Get YP money ***/
  declare @ypmoney numeric(12,2)
  select @ypmoney=sum(ypmoney*cfcount) 
  from _mzcfypk
  where userid=@userid and clflag is null

  /*** Get CL Money ***/
  declare @clmoney numeric(12,2)
  select @clmoney=sum(ypmoney) 
  from _mzcfypk
  where userid=@userid and clflag=1
  
  /*** Get Check money ***/
  declare @checkmoney numeric(12,2)
  select @checkmoney=sum(checkmoney) from _mzcheck where userid=@userid
  select @checkmoney=case when @clmoney is null then 0 else @clmoney end +
                     case when @checkmoney is null then 0 else @checkmoney end

  /*** Get CFCount ***/
  declare @cfcount int
  select @cfcount=count(*) from _mzcfinf where userid=@userid
  if @ypmoney is null 
    select @ypmoney=0
  if @checkmoney is null
    select @checkmoney=0
  if @cfcount is null
    select @cfcount=0
  /*** Insert into mzinvoice table***/
  if @oldfpnum=0 or @oldfpnum is null  
  begin
    if @Sex is null
      select @Sex=Sex from MZRegisterSheet where MZNum=@mznum
    insert mzinvoice(FPNUM,FPNAME,FPMONEY,YP_MONEY,CHECK_MONEY,FPDATE,OPERNAME,JSDATE,DELDATE,CDNUM,CFS,YBFLAG,YBNUM,JFCARDID,ROUNDFLAG,JFINITDATE,YBAREACODE,YBAREANAME,ZFMONEY1,ZFMONEY2,ROUNDMONEY,
                     YBError,yldy,patientid,mznum,transno,zfmoney3,InvoiceNum,InvoiceOperID,Sex)
      values(@fpnum,@fpname,@fpmoney,@ypmoney,@checkmoney,@currentdate,@opername,null,null,null,@cfcount,@ybflag,@ybnum,@jfcardid,@roundflag,null,@ybareacode,@ybareaname,@zfmoney1,@zfmoney2,@roundmoney,
                     @yberror,@yldyname,@patientid,@mznum,@transno,@zfmoney3,case when @allownotPrnFP=1 then '未打印' else @InvoiceNum end/*允许不打印发票时该值为"未打印"*/,@InvoiceOperID,@Sex)
  end else  
  begin
    insert mzinvoice(FPNUM,FPNAME,FPMONEY,YP_MONEY,CHECK_MONEY,FPDATE,OPERNAME,JSDATE,DELDATE,CDNUM,CFS,YBFLAG,YBNUM,JFCARDID,ROUNDFLAG,JFINITDATE,YBAREACODE,YBAREANAME,ZFMONEY1,ZFMONEY2,ROUNDMONEY,
                     YBError,yldy,patientid,mznum,transno,zfmoney3,InvoiceNum,InvoiceOperID,Sex)
      select @fpnum,@fpname,@fpmoney,@ypmoney,@checkmoney,@currentdate,@opername,null,null,@oldfpnum,@cfcount,@ybflag,@ybnum,@jfcardid,@roundflag,null,@ybareacode,@ybareaname,@zfmoney1,@zfmoney2,@roundmoney,
             @yberror,@yldyname,patientid,mznum,transno,@zfmoney3,case when @allownotPrnFP=1 then '未打印' else @InvoiceNum end/*允许不打印发票时该值为"未打印"*/,@InvoiceOperID,Sex
        from mzinvoice where fpnum=@oldfpnum
      union all       
      select @fpnum,@fpname,@fpmoney,@ypmoney,@checkmoney,@currentdate,@opername,null,null,@oldfpnum,@cfcount,@ybflag,@ybnum,@jfcardid,@roundflag,null,@ybareacode,@ybareaname,@zfmoney1,@zfmoney2,@roundmoney,
             @yberror,@yldyname,patientid,mznum,transno,@zfmoney3,@InvoiceNum,@InvoiceOperID,Sex
        from mzinvoicehis where fpnum=@oldfpnum

    update mzinvoice
      set cdnum=@fpnum
    where fpnum=@oldfpnum
    
    update mzinvoicehis
      set cdnum=@fpnum
    where fpnum=@oldfpnum  
/*    update yhyb_invoicebase
      set deldate=@currentdate,
          deloper=@opername
      where fpnum=@oldfpnum*/
  end

  /***医技申请单***/
  insert yj_applysheet(ApplyNum,PatientName,PatientKind,PatientNum,GroupKeyNo,ItemCode,ItemName,ItemMoney,ItemPrice,ItemCount,
                       ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,ApplyDate,jzopername,jzdate,fpdate,fpnum,sampletype,samplecode,emergency_flag)
    select yjapplynum,@fpname,1,@patientid,groupkeyno,checkno,checkname,checkmoney,checkprice,checkcount,
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@currentdate,@opername,@currentdate,@currentdate,@fpnum,sampletype,samplecode,emergency_flag
      from _mzcheck,kscode
      where fskscode=code and ksattrib=5 and userid=@userid and yjapplynum is not null and groupcode is null
    union all
    select yjapplynum,@fpname,1,@patientid,groupkeyno,groupcode,groupname,sum(checkmoney),groupprice,groupcount,
           fskscode,fsksname,yscode,ysname,yskscode,ysksname,@currentdate,@opername,@currentdate,@currentdate,@fpnum,sampletype,samplecode,emergency_flag
      from _mzcheck,kscode
      where fskscode=code and ksattrib=5 and userid=@userid and yjapplynum is not null and groupcode is not null
      group by groupkeyno,groupcode,groupname,groupprice,groupcount,yjapplynum,fskscode,fsksname,yscode,ysname,yskscode,ysksname,sampletype,samplecode,emergency_flag


  /***Insert into mzregistersheet***/
  /***门诊挂号明细***/
--  declare @t_xmcode char(40)
  select @t_xmcode=null
  select @t_xmcode=groupcode from _mzcheck (nolock) where userid=@userid and groupcode in(select groupcode from checkgroupcode (nolock) where groupflag=5)
  if @t_xmcode is not null 
  begin
    /*declare @t_mznum int
    execute GetUniqueNo 22,@NewUniqueNo=@t_mznum output*/

    declare @t_mzregisterattrib int
    select @t_mzregisterattrib=mzregisterattrib from checkgroupcode (nolock) where groupcode=@t_xmcode

    --冲单时门诊号取负数
    declare @t_mznum int
    select @t_mznum=case when @oldfpnum is not null and @oldfpnum<>0 then -@mznum else @mznum end

    insert mzregistersheet(MZNum,FPNum,PatientName,XMCode,XMName,XMMoney,XMAttrib,KSCode,KSName,YSCode,YSName,RegisterDate,OperName,patientid)
      select @t_mznum,@fpnum,@fpname,groupcode,groupname,sum(checkmoney),@t_mzregisterattrib,fskscode,fsksname,yscode,ysname,@currentdate,@opername,@patientid
        from _mzcheck (nolock)
        where userid=@userid
        group by groupcode,groupname,groupprice,fskscode,fsksname,yscode,ysname

    
    if @oldfpnum is null or @oldfpnum=0  --非冲单时
    begin
      update mzregistersheet
        set sex=patientbase.sex,address=patientbase.address,birthday=patientbase.birthday,tel=patientbase.tel,
            Professional=patientbase.Professional,treatmentcode=patientbase.treatmentcode,
            treatmentname=patientbase.treatmentname,reserveflag=@reserveflag,ProfessionalCode=patientbase.ProfessionalCode
        from mzregistersheet,patientbase
        where mznum=@mznum and mzregistersheet.patientid=patientbase.patientid
    
      update mzinvoice
        set mzregisterflag=1
        where fpnum=@fpnum
    end
  end
  
  /***Update YFSTORE table***/
  /*如果不是冲单则要更新已划价未拿药字段A16*/
  if @oldfpnum=0 or @oldfpnum is null  
    /***如果是正常门诊则不发药，否则则直接发药***/
    if @jfcardid is null  
    begin
      update yfstore
        set a09=a09-sumypcount,a15=a15+sumypcount,a16=a16+sumypcount
        from yfstore,_mzcfypgroupview
        where a01=goodsno and a10=yfcode and userid=@userid
    end else
    begin
      update yfstore
        set a09=a09-sumypcount,a15=a15+sumypcount
        from yfstore,_mzcfypgroupview
        where a01=goodsno and a10=yfcode and userid=@userid

      update mzcfinf
        set fydate=@currentdate
        where fpnum=@fpnum

      update mzcfypk
        set fydate=@currentdate
        where fpnum=@fpnum
    end
  else
    update yfstore
      set a09=a09-sumypcount,a15=a15+sumypcount
      from yfstore,_mzcfypgroupview
      where a01=goodsno and a10=yfcode and userid=@userid
  
  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice
     select _mzcfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,-ypcount,(a08-ypprice)*(-ypcount)*cfcount,
            (a07-ypprice_1)*(-ypcount)*cfcount,@opername,
       '划价时价差',a10,a11 
     from yfstore,_mzcfypk
     where a01=_mzcfypk.goodsno and _mzcfypk.yfcode=a10 and
               (_mzcfypk.ypprice<>a08 or _mzcfypk.ypprice_1<>a07) and _mzcfypk.userid=@userid

  update mzcfinf_yz
    set mzoper=@opername,mzoperdate=@currentdate,fpnum=@fpnum
    from mzcfinf_yz,_mzcfinf
    where mzcfinf_yz.cfnum=_mzcfinf.cfnum and userid=@userid

  update patient_applicationsheet
    set jzoper=@opername,
         jzdate=@currentdate,
         fpnum=@fpnum,
         checkmoney=case when patient_applicationsheet.priceflag=1 then disp.checkmoney else patient_applicationsheet.checkmoney end
    from patient_applicationsheet,
         (select yjapplynum,sum(checkmoney) as checkmoney from _mzcheck (nolock) where userid=@userid group by yjapplynum) disp
    where applynum=disp.yjapplynum
    
  delete mzinvoice_tmp where fpnum_tmp=@fpnum_tmp
  delete mzcfinf_tmp where fpnum_tmp=@fpnum_tmp
  delete mzcfypk_tmp where fpnum_tmp=@fpnum_tmp
  delete mzcheck_tmp where fpnum_tmp=@fpnum_tmp
  return 0
end
GO
