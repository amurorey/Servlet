










CREATE      VIEW dbo.UT_PATIENT_INFO
AS
--住院
SELECT '0' AS patient_kind, CONVERT(char(20), M01) AS patient_code, 
      M04 AS patient_name, m02 as cost_type,
      CASE WHEN m05 = '男' THEN '1' WHEN m05 = '女' THEN '2' ELSE '3' END AS patient_sex,
      M06 AS patient_birthday, M03 AS medical_card, null AS office, M35 AS doctor, 
      m16 AS ward_code, M18 AS bed_no, M40 AS diagnosis, NULL AS remark_info, 
      CASE WHEN m19 IS NULL THEN '1' ELSE '0' END AS In_Hopital_Flag,--此字段为科华标准接口用
      CASE WHEN m19 IS NULL THEN '1' ELSE '0' END AS Expr1,--此字段为科华红河州医院用
      NULL AS other1, NULL 
      AS other2
FROM dbo.MBASE WITH (nolock) 
--  where m51 is not null 
where m19 is null and m53 is null and m51 is not null 
--    and m01 in(select zynum from patient_applicationcheckcode where fskscode='3001' group by zynum) 
union all
--门诊不挂号
select '1' AS patient_kind, 
      'm'+rtrim(CONVERT(char(20),mzinvoice.fpnum)) AS patient_code, 
      fpname AS patient_name,yldy,
      '3' as patient_sex,
      null as birthday, null AS medical_card, null AS office, null AS doctor, 
      NULL AS ward_code, null AS bed_no, null AS diagnosis, NULL AS remark_info, 
      '1' AS In_Hopital_Flag,--此字段为科华标准接口用
      '1' AS Expr1,--此字段为科华红河州医院用
      NULL AS other1, NULL 
      AS other2
  from mzinvoice (nolock) where mznum is null and fpnum in(select fpnum from mzcheck where fskscode='3001')
union all
--来源于门诊医生工作站申请
select '1' AS patient_kind, 
      rtrim(convert(char(20),mznum)) AS patient_code, 
      patientname AS patient_name,treatmentname,
      case when sex='男' then '1' when sex='女' then '2' else '3' end as patient_sex,
      birthday as birthday, null AS medical_card,kscode  AS office, yscode AS doctor, 
      NULL AS ward_code, null AS bed_no, diagnose AS diagnosis, NULL AS remark_info, 
      '1' AS In_Hopital_Flag,--此字段为科华标准接口用
      '1' AS Expr1,--此字段为科华红河州医院用
      NULL AS other1, NULL 
      AS other2
  from mzregistersheet (nolock)
  where mznum in
   (select patient_applicationcheckcode.mznum from patient_applicationcheckcode (nolock),patient_applicationsheet (nolock) 
      where patient_applicationcheckcode.mznum=patient_applicationsheet.mznum and patient_applicationcheckcode.fskscode='3001' and fpnum is not null
        and patient_applicationsheet.mznum is not null and deldate is null
      group by patient_applicationcheckcode.mznum)


GO
