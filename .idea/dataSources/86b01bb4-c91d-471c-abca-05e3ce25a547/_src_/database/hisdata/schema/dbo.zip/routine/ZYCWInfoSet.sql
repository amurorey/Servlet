CREATE     PROCEDURE [dbo].[ZYCWInfoSet] 
(@zynum int,@hscode varchar(10),@hsname varchar(20),@yscode varchar(10),@ysname varchar(20),
 @kscode varchar(10),@ksname varchar(20),@cwname varchar(30),@blflag int=null)
AS
begin
  declare @t_currentzynum int
  select @t_currentzynum=currentzynum
    from kscwset (nolock)
    where kscode=@kscode and cwname=@cwname

  if @t_currentzynum is null
    return -1  --当前床位没有住患者

  if @zynum<>@t_currentzynum
    return -2  --当前床位所住患者已发生变化

  if exists(select m01 from mbase (nolock) where m01=@zynum and m53 is not null)
    return -3  --已出室

  if @blflag=1 and exists(select zynum from turnmess (nolock) where zynum=@zynum)
    return -4  --该病人有转科记录，不能不书写病历

  declare @t_yscode varchar(10)
  declare @t_ysname varchar(20)
  declare @t_hscode varchar(10)
  declare @t_hsname varchar(20)
  select @t_yscode=rtrim(YSCODE),@t_ysname=rtrim(ysname),
          @t_hscode=rtrim(HSCODE),@t_hsname=RTRIM(hsname)
    from KSCWSET (nolock) where KSCODE=@kscode and CWNAME=@cwname
  if @t_yscode <> @yscode or @t_hscode <> @hscode
  begin
    declare @t_logstr nvarchar(512)
    select @t_logstr= '住院号:' + CONVERT(varchar(20), @zynum) + '  床位:' + @cwname + '  主管医师:' + @t_ysname + '改为:' + @ysname + 
                                                                                        '  主管护士:' + @t_hsname + '改为:' + @hsname
  
    insert hislog(OperCode,OperName,OperDate,OperFlag,OperLog,note)
      values(@hscode,@hsname,getdate(),5,@t_logstr,'修改床位信息')
  end
  
  update kscwset
    set hscode=@hscode,hsname=@hsname,yscode=@yscode,ysname=@ysname
    where kscode=@kscode and cwname=@cwname

  update mbase
    set m35=@ysname
    from mbase
    where m01=@zynum

  declare @t_blflag int
  select @t_blflag=m64 from mbase (nolock)
    where m01=@zynum

  if @t_blflag = @blflag
  begin
    update ba_fpage
      set fp118=@ysname,fp149=@hsname
      from ba_fpage (nolock) where fp0=rtrim(convert(char(20),@zynum))
  end else
  begin
    declare @t_m51 datetime  --入科日期
    select @t_m51=m51 from mbase (nolock) where m01=@zynum
    if @t_blflag is null  --原=null  现=1  取消病案信息
    begin
      update mbase
        set m64=1
        where m01=@zynum

      select @t_m51=convert(datetime,convert(char(10),@t_m51,101)) /*仅保留年、月、日*/

      execute ba_processbqgzrb @KSCode,@KSName,@t_m51,1,-1  /*在日报中减少一个入院病人*/
      delete ba_fpage where fp0=rtrim(convert(char(20),@zynum))
      delete ba_invoice where zynum=rtrim(convert(char(20),@zynum))
    end else              --原=1     现=null  增加病案信息
    begin
      update mbase
        set m64=null
        where m01=@zynum

      insert ba_fpage(fp0,fp2,fp3,fp4,fp5,fp7,fp14,fp22,fp23,fp23_name,fp24,fp25,fp40,fp81,fp118,fp149,fp_patientid,fp5_str)
          select rtrim(convert(char(20),m01)) as m01,m04,case when m05='男' then '1' else '2' end,m06,m07,m03,m10,m09,
               m16,m17,@cwname,m51,m51,1,@ysname,@hsname,patientid,m07_str
          from mbase where m01=@zynum and m16=@kscode

      /*初始化病案首页库中的字段*/
      update ba_fpage
        set fp80='1',fp122='1',fp82='1',fp83='0',fp84='0',fp85='0',fp90='1'
        where fp0=rtrim(convert(char(20),@zynum))

      select @t_m51=convert(datetime,convert(char(10),@t_m51,101)) /*仅保留年、月、日*/
      execute ba_processbqgzrb @KSCode,@KSName,@t_m51,1,1  /*在日报中增加一个入院病人*/
    end
  end

end
GO
