


CREATE VIEW AllCFInfView AS
select cfnum,yscode,ysname,yskscode,ysksname,cfmoney,fydate,fpdate as jzdate,yfcode,1 as flag from mzcfinf (nolock) where deldate is null
union all
select cfnum,yscode,ysname,yskscode,ysksname,cfmoney,fydate,fpdate,yfcode,1 from mzcfinfhis (nolock) where deldate is null
union all
select cfnum,yscode,ysname,lykscode,lyksname,cfmoney,fydate,jzdate,yfcode,2 from zycfinf (nolock) where deldate is null
union all
select cfnum,yscode,ysname,lykscode,lyksname,cfmoney,fydate,jzdate,yfcode,2 from zycfinfhis (nolock) where deldate is null


GO
