CREATE      PROCEDURE [dbo].[TW_MZReserve]
(@kscode varchar(10),@yscode varchar(10),@registercode varchar(4),@ReserveDate datetime,
 @patientname varchar(20),@sex char(1),@birthday datetime,@tel varchar(20),@personid varchar(20),
 @transno varchar(20),
 @retstr varchar(100) output,@patientid_ret varchar(10) output)
AS
begin
  if rtrim(@kscode)='' or @kscode is null
  begin
    select @retstr='科室代码为空'
    return -1
  end
  
  if rtrim(@yscode)='' or @yscode is null
  begin
    select @retstr='医师代码为空'
    return -1
  end

  if rtrim(@registercode)='' or @registercode is null
  begin
    select @retstr='预约科室为空'
    return -1
  end

  if @reservedate is null 
  begin
    select @retstr='预约时间为空'
    return -1
  end

  if rtrim(@patientname)='' or @patientname is null
  begin
    select @retstr='患者姓名为空'
    return -1
  end
  
  if rtrim(@sex)='' or @sex is null
  begin
    select @retstr='性别为空'
    return -1
  end

  if @birthday is null 
  begin
    select @retstr='出生日期为空'
    return -1
  end

  if exists(select transno from mzreserve (nolock) where transno=@transno)
  begin
    select @retstr='预约交易流水号重复'
    return -1
  end

  if not exists(select groupcode from checkgroupcode where groupcode=@registercode)
  begin
    select @retstr='无此挂号代码'
    return -1
  end

  if not exists(select code from kscode where code=@kscode)
  begin
    select @retstr='无科室代码对应的科室'
    return -1
  end

  if not exists(select code from yscode where code=@yscode)
  begin
    select @retstr='无医师代码对应的医师名称'
    return -1
  end

  declare @t_patientid int

  begin transaction
  --若不满足以下条件则新生成patientid
  if not exists(select patientid from patientbase (nolock) where patientname=@patientname and sex=@sex and personid=@personid and birthday=@birthday)
  begin
    execute GetUniqueNo 26,@NewUniqueNo=@t_patientid output
    if @@error <> 0 

    begin
      rollback
      select @retstr='生成患者ID号时错误'
      return -1
    end
    
    insert patientbase(patientid,patientname,pym,sex,birthday,
                       tel,personid,opername,operdate,
                       createdate,createoper,transno_bank)
        values(convert(varchar(20),@t_patientid),@patientname,'',case when @sex='1' then '男' else '女' end,@birthday,
               @tel,@personid,'自助挂号',getdate(),
               getdate(),'自助挂号',@transno)
    if @@error <> 0 
    begin

      rollback
      select @retstr='生成患者基本信息时错误'
      return -1
    end

    select @patientid_ret=@t_patientid
  end else
  begin
    select @t_patientid=patientid from patientbase (nolock) where patientname=@patientname and sex=@sex and personid=@personid and birthday=@birthday
  end

  declare @t_ksname varchar(20)
  select @t_ksname=name from kscode (nolock) where code=@kscode

  declare @t_ysname varchar(20)
  select @t_ysname=name from yscode (nolock) where code=@yscode

  declare @t_checkgroupname varchar(40)
  declare @t_money numeric(12,2)
  select @t_checkgroupname=groupname,@t_money=groupprice from checkgroupcode (nolock) where groupcode=@registercode

  insert mzreserve(PatientID,PatientName,Sex,Birthday,PersonID,Tel,KSCode,KSName,yscode,ysname,CheckGroupCode,CheckGroupName,CheckMoney,
                    Status,ReserveDate,OperDate,OperName,TransNo)
    values(@t_patientid,@patientname,@sex,@birthday,@personid,@tel,@kscode,@t_ksname,@yscode,@t_ysname,@registercode,@t_checkgroupname,@t_money,
           null,@reservedate,getdate(),'自助挂号',@transno)
  if @@error <> 0 
  begin
    rollback
    select @retstr='生成预约记录时错误'
    return -1
  end

  commit transaction

  select @patientid_ret=@t_patientid
  select @retstr='预约成功'
  return 0
end
GO
