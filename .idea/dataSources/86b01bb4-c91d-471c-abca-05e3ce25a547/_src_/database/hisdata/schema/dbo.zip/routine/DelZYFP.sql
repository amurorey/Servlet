CREATE  PROCEDURE [dbo].[DelZYFP] 
(@zynum int,@fpnum int,@operator char(10),@outflag int,@YWZQID_YDYB char(40)=null)
AS
begin
  if exists(select fpnum from zyinvoicebase where fpnum=@fpnum and zynum=@zynum and jsdate is not null)
    return 1
  if exists(select fpnum from zyinvoicebase where fpnum=@fpnum and zynum=@zynum and deldate is not null)
    return 2
  if exists(select fpnum from zyinvoicebase where fpnum=@fpnum and zynum=@zynum and fpoper<>@operator)
    return 3

  declare @lastfpnum int
  select @lastfpnum=max(fpnum) from zyinvoicebase where zynum=@zynum and deldate is null
  if @fpnum<>@lastfpnum
    return 4


/*  if exists(select zynum from zyinvoicebase where zynum=@zynum and outflag is null and deldate is not null)    return 4
  if exists(select fpnum from zyinvoicebase where fpnum=@fpnum and zynum=@zynum and outflag is null)
    return 5*/
  declare @moneytemp numeric(12,2),@jtmoneytemp numeric(12,2),@otherzfmoney numeric(12,2),@currentdatetemp datetime
  select @moneytemp=fpmoney,@jtmoneytemp=jtmoney,@otherzfmoney=case when otherzfmoney is not null then otherzfmoney else 0 end 
    from zyinvoicebase
    where fpnum=@fpnum and zynum=@zynum
  select @currentdatetemp=getdate()
  update zyinvoicebase
    set deldate=@currentdatetemp,deloper=@operator
    where fpnum=@fpnum and zynum=@zynum
  update zyinvoice
    set deldate=@currentdatetemp,deloper=@operator
    where fpnum=@fpnum and zynum=@zynum 
  update zycfinf
    set yjfpnum=null,fpdate=null
  where yjfpnum=@fpnum and zynum=@zynum 
  update zycfypk
    set yjfpnum=null,fpdate=null
  where yjfpnum=@fpnum and zynum=@zynum 
  update zycheck
    set yjfpnum=null,fpdate=null
  where yjfpnum=@fpnum and zynum=@zynum 

  if @outflag=1 /*正常出院时*/
  begin
    update mbase
      set m28=null,m33=m33-@moneytemp,m26=0,m30=null,m32=null,m50=case when m50 is not null then m50 else 0 end - @otherzfmoney
      where m01=@zynum

    insert prepay(p01,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
      select p01,p03,p04,p05,'作废出院发票:'+convert(char(10),@fpnum),-p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP
      from prepay where p01=@zynum and fpnum=@fpnum and p10=1

    update prepay
      set fpnum=null,
          InvoiceNum_FP=null,
          InvoiceOperID_FP=null
      where p01=@zynum and fpnum=@fpnum and p10 is null
  end else     /*预结时*/
  begin
    update mbase
      set m33=m33-@moneytemp,m30=null,m32=null,
          m27=case when m27 is not null then m27 else 0 end-case when @jtmoneytemp is not null then @jtmoneytemp else 0 end,
          m50=case when m50 is not null then m50 else 0 end - @otherzfmoney,
          M68=null
      where m01=@zynum

    declare @t_note varchar(50)
    if @outflag=2
      set @t_note='作废预结发票:'+convert(char(10),@fpnum)
    else
      set @t_note='作废分项发票:'+convert(char(10),@fpnum)

    insert prepay(p01,p03,p04,p05,p06,p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP)
      select p01,p03,p04,p05,@t_note,-p07,p08,p10,fpnum,InvoiceNum_FP,InvoiceOperID_FP
      from prepay where p01=@zynum and fpnum=@fpnum and p10=2

    update prepay
      set fpnum=null,
          InvoiceNum_FP=null,
          InvoiceOperID_FP=null
      where p01=@zynum and fpnum=@fpnum and p10 is null
  end

  update yb_zyinvoice
    set deldate=@currentdatetemp,
        deloper=@operator
    where fpnum=@fpnum and zynum=@zynum

  update dryb_invoicebase
    set deldate=@currentdatetemp,
        deloper=@operator 
    where fpnum=@fpnum and zynum=@zynum

  update yhyb_invoicebase
    set deldate=@currentdatetemp,
        deloper=@operator
    where fpnum=@fpnum and zynum=@zynum

  update xnh_invoicebase
    set deldate=@currentdatetemp,
        deloper=@operator 
    where fpnum=@fpnum and zynum=@zynum

  update ydyb_invoicebase
    set deldate=@currentdatetemp,
        deloper=@operator,
        YWZQID_Del=@YWZQID_YDYB
    where fpnum=@fpnum and zynum=@zynum

  return 0
end
GO
