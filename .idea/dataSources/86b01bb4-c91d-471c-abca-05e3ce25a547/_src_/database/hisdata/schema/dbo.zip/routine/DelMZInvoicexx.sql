/****** Object:  Stored Procedure dbo.DelMZInvoicexx    Script Date: 2003-10-25 22:51:59 ******/
/****** Object:  Stored Procedure dbo.DelMZInvoice    Script Date: 2003-06-20 09:00:14 ******/
CREATE PROCEDURE [dbo].[DelMZInvoicexx]
(@fpnum int, @opername char(10), @note char(30)='')
AS
if exists(select fpnum from mzinvoice where fpnum=@fpnum and deldate is not null)
  return 1
if exists(select fpnum from mzcfinf where fpnum=@fpnum and fydate is not null)
  return 3
if exists(select fpnum from mzinvoice where fpnum=@fpnum and cdnum is not null)
  return 4
declare @currentdate datetime
select @currentdate=getdate()
/***Compute the count of this invoice***/
select yfcode,fpnum,goodsno,sum(ypcount*cfcount) as sumypcount 
  into #fpypcount
  from mzcfypkhis
  where fpnum=@fpnum
  group by yfcode,fpnum,goodsno
update yfstore
  set a09=a09+sumypcount,a15=a15-sumypcount,a16=a16-sumypcount
  from yfstore,#fpypcount
  where yfstore.a10=#fpypcount.yfcode and
     yfstore.a01=#fpypcount.goodsno
update mzinvoicehis
  set deldate=@currentdate
where fpnum=@fpnum
update mzcfinfhis
  set deldate=@currentdate
  where fpnum=@fpnum
update mzcfypkhis
  set deldate=@currentdate
where fpnum=@fpnum
update mzcheckhis
  set deldate=@currentdate
where fpnum=@fpnum
insert mzchangeprice
    select mzcfypkhis.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,ypcount*cfcount,
          (a08-ypprice)*ypcount*cfcount,(a07-ypprice_1)*ypcount*cfcount,@opername,
          @note,yfcode.yfcode,yfcode.yfname
    from yfstore,mzcfypkhis,yfcode
    where a01=mzcfypkhis.goodsno and yfstore.a10=mzcfypkhis.yfcode and mzcfypkhis.yfcode=yfcode.yfcode
          and (mzcfypkhis.ypprice<>a08 or mzcfypkhis.ypprice_1<>a07) and mzcfypkhis.fpnum=@fpnum
return 0
GO
