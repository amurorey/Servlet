

CREATE       VIEW dbo.UT_PATIENT_COST
AS
SELECT '0' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.zynum)) AS patient_code, 
      patientname AS patient_name, 
      bedno AS bed_no, 
      lykscode AS ward_code, 
      checkno AS item_code, 
      checkname AS item_name, 
      patient_applicationcheckcode.checkmoney AS cost, 
      samplecode AS module_kind,  
      patient_applicationcheckcode.emergency_flag, 
      patient_applicationsheet.YSName AS doctor, 
      patient_applicationsheet.ApplyDate AS check_date, 
      patient_applicationsheet.ysksname AS office, 
      yldyname AS cost_type, 
      JZOper AS cost_user, 
      JZDate AS cost_date, 
      convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
      convert(varchar(8),newgroupkeyno) as ord_item_no,
      '0' AS cost_flag, 
      '0' AS check_flag, 
      'null' AS remark_info, 
      NULL AS other1, 
      NULL AS other2
FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and patient_applicationcheckcode.zynum is not null
      and yzrundate is not null and dbo.patient_applicationcheckcode.fskscode='3001' and groupcode is null and yzrundate>dateadd(day,-5, getdate())
union all
SELECT '0' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.zynum)) AS patient_code, 
      patientname AS patient_name, 
      bedno AS bed_no, 
      lykscode AS ward_code, 
      groupcode AS item_code, 
      groupname AS item_name, 
      patient_applicationcheckcode.groupprice AS cost, 
      samplecode AS module_kind,  
      patient_applicationcheckcode.emergency_flag, 
      patient_applicationsheet.YSName AS doctor, 
      patient_applicationsheet.ApplyDate AS check_date, 
      patient_applicationsheet.ysksname AS office, 
      yldyname AS cost_type, 
      JZOper AS cost_user, 
      JZDate AS cost_date, 
      convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
      convert(varchar(8),newgroupkeyno) as ord_item_no,
      '0' AS cost_flag, 
      '0' AS check_flag, 
      'null' AS remark_info, 
      NULL AS other1, 
      NULL AS other2
FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
    WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and
          yzrundate>dateadd(day,-5, getdate()) and yzrundate is not null and dbo.patient_applicationcheckcode.fskscode='3001' and groupcode is not null 
          and patient_applicationsheet.zynum is not null
          and patient_applicationcheckcode.zynum is not null
          and keyno in(select min(keyno) from patient_applicationcheckcode 
               group by newgroupkeyno)
union all
SELECT '1' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.mznum)) AS patient_code, 
      patientname AS patient_name, 
      bedno AS bed_no, 
      yskscode AS ward_code, 
      checkno AS item_code, 
      checkname AS item_name, 
      patient_applicationcheckcode.checkmoney AS cost, 
      samplecode AS module_kind,  
      patient_applicationcheckcode.emergency_flag, 
      patient_applicationsheet.YSName AS doctor, 
      patient_applicationsheet.ApplyDate AS check_date, 
      patient_applicationsheet.ysksname AS office, 
      yldyname AS cost_type, 
      JZOper AS cost_user, 
      JZDate AS cost_date, 
      convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
      convert(varchar(8),newgroupkeyno) as ord_item_no,
      '0' AS cost_flag, 
      '0' AS check_flag, 
      'null' AS remark_info, 
      NULL AS other1, 
      NULL AS other2
FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and patient_applicationcheckcode.mznum is not null and
      jzdate>dateadd(day,-5, getdate()) and jzdate is not null and dbo.patient_applicationcheckcode.fskscode='3001' and groupcode is null
union all
SELECT '1' AS patient_kind, rtrim(convert(char(20),patient_applicationcheckcode.mznum)) AS patient_code, 
      patientname AS patient_name, 
      bedno AS bed_no, 
      yskscode AS ward_code, 
      groupcode AS item_code, 
      groupname AS item_name, 
      patient_applicationcheckcode.groupprice AS cost, 
      samplecode AS module_kind,  
      patient_applicationcheckcode.emergency_flag, 
      patient_applicationsheet.YSName AS doctor, 
      patient_applicationsheet.ApplyDate AS check_date, 
      patient_applicationsheet.ysksname AS office, 
      yldyname AS cost_type, 
      JZOper AS cost_user, 
      JZDate AS cost_date, 
      convert(varchar(30),patient_applicationcheckcode.applynum) AS order_no,
      convert(varchar(8),newgroupkeyno) as ord_item_no,
      '0' AS cost_flag, 
      '0' AS check_flag, 
      'null' AS remark_info, 
      NULL AS other1, 
      NULL AS other2
FROM patient_applicationcheckcode (nolock),patient_applicationsheet (nolock)
    WHERE patient_applicationcheckcode.applynum = patient_applicationsheet.applynum and
          jzdate>dateadd(day,-5,getdate()) and jzdate is not null and dbo.patient_applicationcheckcode.fskscode='3001' and groupcode is not null 
                         and patient_applicationcheckcode.mznum is not null
          and keyno in(select min(keyno) from patient_applicationcheckcode 
                   group by newgroupkeyno)
/*union all
SELECT '1' AS patient_kind, 
      case when mznum is null then 'm'+rtrim(convert(char(20),mzinvoice.fpnum)) else rtrim(convert(char(20),mznum)) end as patient_code,
      dbo.YJ_ApplySheet.patientname AS patient_name, 
      null AS bed_no, NULL AS ward_code, 
      dbo.YJ_ApplySheet.ItemCode AS item_code, 
      dbo.YJ_ApplySheet.ItemName AS item_name, 
      dbo.YJ_ApplySheet.ItemMoney AS cost, NULL AS module_kind, NULL 
      AS emergency_flag, dbo.YJ_ApplySheet.ApplyYSName AS doctor, 
      dbo.YJ_ApplySheet.ApplyDate AS check_date, 
      dbo.YJ_ApplySheet.ApplyKSName AS office, YLDY AS cost_type, 
      dbo.YJ_ApplySheet.JZOperName AS cost_user, 
      dbo.YJ_ApplySheet.JZDate AS cost_date, 
      convert(varchar(30),ApplyNum) AS order_no, 
      convert(varchar(8),keyno) as ord_item_no,
      '1' AS cost_flag, '0' AS check_flag, NULL 
      AS remark_info, NULL AS other1, NULL AS other2
FROM dbo.YJ_ApplySheet WITH (nolock) INNER JOIN
      dbo.mzinvoice WITH (nolock) ON 
      dbo.YJ_ApplySheet.FPNum = dbo.mzinvoice.fpnum
WHERE (dbo.YJ_ApplySheet.Patientkind=1) AND mzinvoice.deldate is null
      and (dbo.YJ_ApplySheet.ItemKSCode = '3001')*/











GO
