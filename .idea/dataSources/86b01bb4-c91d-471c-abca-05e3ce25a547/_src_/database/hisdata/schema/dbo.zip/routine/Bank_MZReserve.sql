CREATE     PROCEDURE [dbo].[Bank_MZReserve]
(@patientid varchar(20),@bankcardno varchar(40),@kscode varchar(10),@yscode varchar(10),@registercode varchar(4),@ReserveDate datetime,@checkmoney1 numeric(12,2),@checkmoney2 numeric(12,2),
 @transno varchar(50), @retstr varchar(100) output)
AS
begin
  if exists(select transno from mzreserve (nolock) where transno=@transno)
  begin
    select @retstr='预约交易流水号重复'
    return -1
  end

  if not exists(select groupcode from checkgroupcode where groupcode=@registercode)
  begin
    select @retstr='无此挂号代码'
    return -1
  end

  if not exists(select code from kscode where code=@kscode)
  begin
    select @retstr='无科室代码对应的科室'
    return -1
  end

  if not exists(select code from yscode where code=@yscode)
  begin
    select @retstr='无医师代码对应的医师名称'
    return -1
  end

  if not exists(select patientid from patientbase (nolock) where patientid=@patientid)
  begin
    select @retstr='无此patientid对应的患者信息，请先注册银行卡'
    return -1
  end

  if @bankcardno<>'' and not exists(select patientid from bank_regcard (nolock) where patientid=@patientid and cardno=@bankcardno)
  begin
    select @retstr='此patientid与当前银行卡尚未绑定'
    return -1
  end

  if exists(select keyno from mzreserve (nolock) where patientid=@patientid and convert(varchar(30),operdate,101)=convert(varchar(30),getdate(),101))
  begin
    select @retstr='同一患者一天内只允许预约挂号一次'
    return -1
  end


  --判断是否存在排班信息--
  declare @t_regtime varchar(100)
  declare @t_doctlevelname varchar(100)
  declare @t_specialty varchar(100)
  declare @t_regfee numeric(12,2)
  declare @t_treatfee numeric(12,2)
  select @t_regtime=regtime,@t_doctlevelname=doctlevelname,@t_specialty=specialty,@t_regfee=regfee,@t_treatfee=treatfee from
  (SELECT  
	A.KSCode AS DeptID,
	A.KSName AS DeptName,
	A.YSCode AS DoctID,
	A.YSName AS DoctName,
	B.YHFlag AS DoctLevelID,
        A.CheckGroupCode as RegID,
	CASE YHFLAG 
          WHEN 2 THEN '普通医师（初职）'
	  WHEN 3 THEN '主任或专家（高职）'
	  WHEN 5 THEN '主治医师（中职）'
	END AS DoctLevelName,
	A.CheckGroupName AS RegName,
	CASE WHEN DATEPART(WEEKDAY,GETDATE())<WEEKDAY THEN
                                      DATEADD(DAY,WEEKDAY-DATEPART(WEEKDAY,GETDATE()), convert(datetime,convert(varchar(30), getdate(),112)))
                                 ELSE
                                      DATEADD(DAY,7+WEEKDAY-DATEPART(WEEKDAY,GETDATE()),convert(datetime,convert(varchar(30), getdate(),112))) END AS RegDate,
	A.TIMEINTERVAL AS RegTime,
	A.CHECKMONEY1 AS RegFee,
	A.CHECKMONEY2 AS TreatFee,
        a.Specialty
    FROM MZSCHEDULE A (NOLOCK),yscode B (nolock)
    where a.yscode=b.code and 
          ((status=1 and 
          CASE WHEN DATEPART(WEEKDAY,GETDATE())<WEEKDAY THEN DATEADD(DAY,WEEKDAY-DATEPART(WEEKDAY,GETDATE()),GETDATE())
               ELSE DATEADD(DAY,7+WEEKDAY-DATEPART(WEEKDAY,GETDATE()),GETDATE()) END < specialdate) or 
           specialdate is null or status=2)) disp
      where deptid=@kscode and doctid=@yscode and regdate=@ReserveDate

  if @t_regtime is null
  begin
    select @retstr='在预约时间内无排班信息'
    return -1
  end

  if @checkmoney1<>@t_regfee or @checkmoney2<>@t_treatfee
  begin
    select @retstr='传入的费用与实际费用不一致'
    return -1
  end

  declare @t_ksname varchar(20)
  select @t_ksname=name from kscode (nolock) where code=@kscode

  declare @t_ysname varchar(20)
  select @t_ysname=name from yscode (nolock) where code=@yscode

  declare @t_checkgroupname varchar(40)
  declare @t_money numeric(12,2)
  select @t_checkgroupname=groupname,@t_money=groupprice from checkgroupcode (nolock) where groupcode=@registercode

  insert mzreserve(PatientID,PatientName,Sex,Birthday,PersonID,Tel,KSCode,KSName,yscode,ysname,CheckGroupCode,CheckGroupName,CheckMoney,
                    Status,ReserveDate,OperDate,OperName,TransNo,DoctLevelName,timeinterval,Special,checkmoney1,checkmoney2)
    select patientid,patientname,sex,birthday,personid,tel,@kscode,@t_ksname,@yscode,@t_ysname,@registercode,@t_checkgroupname,@t_money,
           null,@reservedate,getdate(),'自助挂号',@transno,@t_doctlevelname,@t_regtime,@t_specialty,@checkmoney1,@checkmoney2
      from patientbase (nolock) 
      where patientid=@patientid

  select @retstr='预约成功'
  return 0
end
GO
