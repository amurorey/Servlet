


CREATE VIEW MZALLFPKMVIEW AS
  select mzinvoice.fpname,mzcfypk.fpnum,kmcode,kmname,ypmoney*cfcount as kmmoney,mzcfypk.fpdate,ysname,yskscode,ysksname,yskscode as fskscode,ysksname as fsksname,mzinvoice.jsdate
  from mzcfypk,mzinvoice (nolock) where mzcfypk.deldate is null and mzcfypk.fpnum=mzinvoice.fpnum
union all
  select mzinvoicehis.fpname,mzcfypkhis.fpnum,kmcode,kmname,ypmoney*cfcount as kmmoney,mzcfypkhis.fpdate,ysname,yskscode,ysksname,yskscode as fskscode,ysksname as fsksname,mzinvoicehis.jsdate
  from mzcfypkhis,mzinvoicehis (nolock) where mzcfypkhis.deldate is null and mzcfypkhis.fpnum=mzinvoicehis.fpnum
union all
  select mzinvoice.fpname,mzcheck.fpnum,kmcode,kmname,checkmoney,mzcheck.fpdate,ysname,yskscode,ysksname,fskscode,fsksname,mzinvoice.jsdate
  from mzcheck,mzinvoice (nolock) where mzcheck.deldate is null and mzcheck.fpnum=mzinvoice.fpnum
union all
  select mzinvoicehis.fpname,mzcheckhis.fpnum,kmcode,kmname,checkmoney,mzcheckhis.fpdate,ysname,yskscode,ysksname,fskscode,fsksname,mzinvoicehis.jsdate
  from mzcheckhis,mzinvoicehis (nolock) where mzcheckhis.deldate is null and mzcheckhis.fpnum=mzinvoicehis.fpnum


GO
