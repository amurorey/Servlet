CREATE  PROCEDURE [dbo].[SaveKFChangeStore]
(@storecode char(3),@sheetno char(10),@procdate datetime,@userid int,@retval varchar(100)="" output)
AS
begin
/***check unique sheetno***/
if exists (select * from instock where b02=@sheetno and b24=@storecode)
  return 1
/****check if have enough store****/
if exists (select store.goodsid,store.e03 from store,_instock
           where store.goodsid=_instock.goodsid and _instock.b17+store.e10<0 
           and _instock.userid=@userid)
begin
  select @retval=rtrim(_instock.b06)
    from store,_instock
    where store.goodsid=_instock.goodsid and _instock.b17+store.e10<0 
          and _instock.userid=@userid
  return 2
end
/********************/
update _instock
  set b02=@sheetno,
      b03=@procdate,
      b28=getdate()
  where userid=@userid
insert kfchangestore 
         (B02,B03,B04,B05,B06,
         B07,B08,B09,B10,B11,B12,
         B13,B14,B15,B16,B17,B18,
         B18_1,B19,B20,B21,B22,
         B23,B24,B25,B26,B27,B28,
         B29,B30,B31,goodsID,B32,B33,B34,B35,B36)
  select B02,B03,B04,B05,B06,B07,B08,B09,B10,B11,B12,
         B13,B14,B15,B16,B17,B18,
         B18_1,B19,B20,B21,B22,
         B23,B24,B25,B26,B27,B28,
         B29,B30,B31,goodsID,B32,B33,B34,B35,B36
    from _instock
    where userid=@userid
/***update store table****/
update store
  set e10=store.e10+_instock.b17,
      e10_1=store.e10_1+_instock.b17*store.e07_2
  from store,_instock
  where store.goodsid=_instock.goodsid 
    and _instock.userid=@userid
return 0
end
GO
