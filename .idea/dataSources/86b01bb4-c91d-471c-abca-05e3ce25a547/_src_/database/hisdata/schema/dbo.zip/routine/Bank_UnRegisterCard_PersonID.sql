create  PROCEDURE [dbo].[Bank_UnRegisterCard_PersonID]
(@cardno varchar(20))
AS
begin
  if not exists(select patientid from patientbase (nolock) where personid=@cardno and bindingdate_bank is not null)
    return -1 

  update patientbase
    set bindingdate_bank=null
    where personid=@cardno and bindingdate_bank is not null

  return 0
end
GO
