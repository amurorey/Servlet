CREATE        PROCEDURE [dbo].[DispZYKMSheet]
(@zynum int,@kmcode char(10),@flag int=0)
AS
begin
  if @flag=0
  begin
    select jzdate,jzoper,goodsno as xmcode,goodsname as xmname,unitname,ypprice as xmprice,ypcount*CFCOUNT as xmcount,ypmoney*cfcount as xmmoney,operksname as fsksname,yplbname as yblbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycfypk (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,checkno,checkname as xmname,unitname,checkprice as xmprice,checkcount as xmcount,checkmoney as xmmoney,fsksname,checklbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycheck (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,goodsno,goodsname as xmname,unitname,ypprice as xmprice,ypcount*CFCOUNT as xmcount,ypmoney*cfcount as xmmoney,operksname as fsksname,yplbname as yblbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycfypkhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,checkno,checkname as xmname,unitname,checkprice as xmprice,checkcount as xmcount,checkmoney as xmmoney,fsksname,checklbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycheckhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    order by jzdate
  end else if @flag=1
  begin
    select fsksname,xmcode,xmname,yblbname,hzylflag,unitname,xmprice,sum(xmcount) as xmcount,kmcode,kmname,sum(xmmoney) as xmmoney from
    (select jzdate,jzoper,goodsno as xmcode,goodsname as xmname,unitname,ypprice as xmprice,ypcount*CFCOUNT as xmcount,ypmoney*cfcount as xmmoney,operksname as fsksname,yplbname as yblbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycfypk (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,checkno,checkname as xmname,unitname,checkprice as xmprice,checkcount as xmcount,checkmoney as xmmoney,fsksname,checklbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycheck (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,goodsno,goodsname as xmname,unitname,ypprice as xmprice,ypcount*CFCOUNT as xmcount,ypmoney*cfcount as xmmoney,operksname as fsksname,yplbname as yblbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycfypkhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select jzdate,jzoper,checkno,checkname as xmname,unitname,checkprice as xmprice,checkcount as xmcount,checkmoney as xmmoney,fsksname,checklbname,
      case when hzylflag is not null then '允许' else '' end as hzylflag,
      kmcode,kmname
      from zycheckhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null) disp
    group by xmcode,fsksname,xmname,yblbname,hzylflag,unitname,xmprice,kmcode,kmname
    order by fsksname,xmname
  end else
  begin
    select kmcode,kmname,sum(xmmoney) as summoney from
    (select kmcode,kmname,ypmoney*cfcount as xmmoney
      from zycfypk (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select kmcode,kmname,checkmoney as xmmoney
      from zycheck (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select kmcode,kmname,ypmoney*cfcount as xmmoney
      from zycfypkhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null
    union all
    select kmcode,kmname,checkmoney as xmmoney
      from zycheckhis (nolock)
      where zynum=@zynum and kmcode=@kmcode and deldate is null) disp
    group by kmcode,kmname
    order by kmcode
  end
end
GO
