CREATE       PROCEDURE [dbo].[DispZYCheck]
(@zynum int,@yzflag int=0) with recompile
/*@yzflag显示医嘱方式*/
/*0：全部  1：长期  2：临时  3：自动  4:特检特治疗  5：仅显示已审核项目*/
AS
begin
  if exists(select zynum from zycheck (nolock) where zynum=@zynum)
    if @yzflag=0
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheck.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheck.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null as yjapplynum,ybno,yzid,scale
        from zycheck (nolock) 
          where zynum=@zynum and groupcode is null
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheck (nolock) 
           where zynum=@zynum and groupcode is not null
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else if @yzflag=2  /*临时医嘱  yzflag=2 or yzflag is null*/
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheck.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheck.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
        from zycheck (nolock) 
          where zynum=@zynum and groupcode is null and (yzflag=@yzflag or yzflag is null)
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheck (nolock) 
           where zynum=@zynum and groupcode is not null and (yzflag=@yzflag or yzflag is null)
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else if @yzflag=4
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheck.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheck.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
        from zycheck (nolock) 
          where zynum=@zynum and groupcode is null and checklb=4
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheck (nolock) 
           where zynum=@zynum and groupcode is not null and checklb=4
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else if @yzflag=5
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheck.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheck.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
        from zycheck (nolock) 
          where zynum=@zynum and groupcode is null and checkdate is null
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheck (nolock) 
           where zynum=@zynum and groupcode is not null and checkdate is null
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheck.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheck.deldate,deloper,fsksname,cdcfnum,
              hzylflag,checkoper,checkdate,null,ybno,yzid,scale
         from zycheck (nolock) 
          where zynum=@zynum and yzflag=@yzflag and groupcode is null
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheck (nolock) 
           where zynum=@zynum and groupcode is not null and yzflag=@yzflag
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
  else
    if @yzflag=0 
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheckhis.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheckhis.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
         from zycheckhis (nolock) 
          where zynum=@zynum and groupcode is null
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheckhis (nolock) 
           where zynum=@zynum and groupcode is not null
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else if @yzflag=2  /*临时医嘱  yzflag=2 or yzflag is null*/
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheckhis.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheckhis.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
        from zycheckhis (nolock) 
          where zynum=@zynum and (yzflag=@yzflag or yzflag is null) and groupcode is null
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheckhis (nolock) 
           where zynum=@zynum and groupcode is not null and (yzflag=@yzflag or yzflag is null)
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else if @yzflag=4
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheckhis.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheckhis.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
         from zycheckhis (nolock) 
          where zynum=@zynum and groupcode is null and checklb=4
       union all
       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheckhis (nolock) 
           where zynum=@zynum and groupcode is not null and checklb=4
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
    else
      select zynum,keyno,checkno,groupkeyno,groupcode,jzdate,checkname,checklbname,
             zycheckhis.unitname,checkprice,checkcount,checkmoney,ysname,
             jzoper,jsdate,zycheckhis.deldate,deloper,fsksname,cdcfnum,
             hzylflag,checkoper,checkdate,null,ybno,yzid,scale
        from zycheckhis (nolock) 
          where zynum=@zynum and yzflag=@yzflag and groupcode is null
       union all

       select zynum,max(keyno),groupcode,groupkeyno,groupcode,jzdate,
              '★'+groupname,'',
              '组套',groupprice,groupcount,sum(checkmoney),ysname,
              jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,'',checkoper,checkdate,yjapplynum,'' as ybno,yzid,scale
         from zycheckhis (nolock) 
           where zynum=@zynum and groupcode is not null and yzflag=@yzflag
           group by zynum,groupkeyno,groupcode,jzdate,groupname,yjapplynum,groupprice,groupcount,ysname,jzoper,jsdate,deldate,deloper,fsksname,cdcfnum,checkoper,checkdate,yzid,scale
       order by jzdate desc,keyno asc
end
GO
