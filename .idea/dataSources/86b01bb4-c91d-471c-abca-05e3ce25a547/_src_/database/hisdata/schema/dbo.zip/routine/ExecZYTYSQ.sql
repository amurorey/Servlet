/*执行住院退药申请*/
CREATE         PROCEDURE [dbo].[ExecZYTYSQ]
(@userid numeric,@opername char(10))
AS
begin
  if not exists(select zynum from _zycfypk (nolock) where userid=@userid and fycheckflag is not null)
    return 1 --在执行退药前请先对申请药品进行审核

  if exists(select m01 from mbase (nolock) where m19 is not null and m01 in(select zynum from _zycfypk (nolock) where userid=@userid and fycheckflag is not null))
    return 2 --在执行审核时有病人已办理出院，请重新刷新条件后再执行此操作

  declare @t_count1 int
  declare @t_count2 int
  select @t_count1=count(*) from zytysq (nolock) where keyno in(select _keyno from _zycfypk (nolock) where userid=@userid and fycheckflag is not null) and yfcheckokdate is null
  select @t_count2=count(*) from _zycfypk (nolock) where userid=@userid and fycheckflag is not null
  if @t_count1<>@t_count2
    return 3  /*在审核退药申请时前台操作员又进行了删除操作*/

  if exists(select zytysq.keyno from zytysq (nolock),_zycfypk (nolock)
              where zytysq.keyno=_keyno and userid=@userid and fycheckflag is not null and zytysq.ypcount<>_zycfypk.ypcount)
    return 4  /*在审核退药申请时前台操作员又进行了修改操作*/

  if exists(select keyno from zytysq (nolock) where keyno in(select _keyno from _zycfypk (nolock) where userid=@userid and fycheckflag is not null) and yfcheckokdate is not null)
    return 5  /*出现多窗口操作同一数据*/


  if exists(select zycfypk.zynum from zycfypk (nolock),zytysq (nolock)
               where zycfypk.tyid=zytysq.tyid and zycfypk.ypcount>0
                 and zytysq.keyno in(select _keyno from _zycfypk (nolock) where userid=@userid and _zycfypk.fycheckflag is not null) and yjfpnum is not null)
    return 6


  /*update cfnum*/
  declare @t_cfnum int
  declare @t_zynumsqoper char(30)
  DECLARE _zycfypkgroup_cursor CURSOR FOR
    SELECT rtrim(convert(char(10),_zycfypk.zynum))+rtrim(sqopername)+rtrim(_zycfypk.yscode) 
      FROM zytysq (nolock),_zycfypk (nolock)
      where zytysq.keyno=_zycfypk._keyno and userid=@userid and fycheckflag is not null 
      group by _zycfypk.zynum,sqopername,_zycfypk.yscode
  OPEN _zycfypkgroup_cursor
  FETCH NEXT FROM _zycfypkgroup_cursor into @t_zynumsqoper
  WHILE @@FETCH_STATUS = 0
  BEGIN
    execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output

    update _zycfypk
      set cfnum=@t_cfnum
      from _zycfypk,zytysq
      where  _zycfypk._keyno=zytysq.keyno and userid=@userid and fycheckflag is not null and rtrim(convert(char(10),_zycfypk.zynum))+rtrim(sqopername)+rtrim(_zycfypk.yscode)=@t_zynumsqoper

    FETCH NEXT FROM _zycfypkgroup_cursor into @t_zynumsqoper
  END
  CLOSE _zycfypkgroup_cursor
  DEALLOCATE _zycfypkgroup_cursor
  /*************************************/


  update _zycfypk
    set hzylflag=case when a32='1' then '允许' else null end,
        jbypflag=a37
     from _zycfypk,goods
    where goodsno=a01 and userid=@userid

  declare @currentdate datetime
  select @currentdate=getdate()

  declare @t_fyno int
  execute GetUniqueNo 32,@NewUniqueNo=@t_fyno output

  insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                 cfcount,goodsname,procname,unitname,yfcode,jzdate,
                 jzoper,kmcode,kmname,lykscode,lyksname,yscode,ysname,
                 yskscode,ysksname,yplb,yplbname,xjsjnum,percount,ypjl,
                 ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,
                 operksname,operkscode,fydate,fyopername,tycfnum,tyid,ybno,ybkmcode,hzylflag,zgysname,jbypflag,fyno)
    select zytysq.zynum,_zycfypk.cfnum,zytysq.goodsno,-zytysq.ypcount,zytysq.ypprice,zytysq.ypprice_1,-zytysq.ypmoney,
           1,zytysq.goodsname,zytysq.procname,zytysq.unitname,zytysq.yfcode,@currentdate,
           zytysq.sqopername,zytysq.kmcode,zytysq.kmname,zytysq.lykscode,zytysq.lyksname,zytysq.yscode,zytysq.ysname,
           zytysq.yskscode,zytysq.ysksname,zytysq.yplb,zytysq.yplbname,null,-zytysq.ypcount,null,
           null,null,null,zytysq.yzid,3,zytysq.yfname,
           zytysq.fsksname,zytysq.fskscode,@currentdate,@opername,zytysq.tycfnum,zytysq.tyid,zytysq.ybno,zytysq.ybkmcode,hzylflag,zgysname,jbypflag,-@t_fyno
        from zytysq (nolock),_zycfypk (nolock)
        where zytysq.keyno=_zycfypk._keyno and userid=@userid and _zycfypk.fycheckflag is not null
        order by zytysq.zynum

  /*更新被退药品记录中的退药数量*/
  update zycfypk
    set tycount=(case when tycount is null then 0 else tycount end)+zytysq.ypcount
    from zycfypk,zytysq
    where zycfypk.tyid=zytysq.tyid and zycfypk.ypcount>0
      and zytysq.keyno in(select _keyno from _zycfypk where userid=@userid and _zycfypk.fycheckflag is not null)

  select yfcode,goodsno,sum(-ypcount) as sumypcount
    into #sumgoods
      from zytysq
      where keyno in(select _keyno from _zycfypk where userid=@userid and fycheckflag is not null)
      group by yfcode,goodsno

  update yfstore
    set a09=a09-sumypcount,a15=a15+sumypcount
    from yfstore,#sumgoods
    where a01=goodsno and a10=yfcode


  /***Update MBASE table***/
  select zynum,sum(-ypmoney) as sumypmoney
    into #sumypmoney
    from zytysq
      where keyno in(select _keyno from _zycfypk where userid=@userid and fycheckflag is not null)
    group by zynum

  update mbase
    set m25=m25+case when sumypmoney is not null then sumypmoney else 0 end
    from mbase,#sumypmoney
    where m01=zynum
  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice   
    select goodsno,@currentdate,ypprice,ypprice_1,a08,a07,ypcount,(a08-ypprice)*ypcount, 
          (a07-ypprice_1)*ypcount,@opername,'执行退药申请时价差',yfcode,yfname
      from yfstore,zytysq
      where a01=goodsno and yfcode=a10 and (ypprice<>a08 or ypprice_1<>a07)
           and zytysq.keyno in(select _keyno from _zycfypk where userid=@userid and fycheckflag is not null)

  /*update zytysq*/
  update zytysq
    set yfcheckokoper=@opername,yfcheckokdate=@currentdate,fyno=-@t_fyno
    where keyno in(select _keyno from _zycfypk where userid=@userid and fycheckflag is not null)

  return 0
end
GO
