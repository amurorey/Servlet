CREATE     PROCEDURE [dbo].[BA_FPageCheck]
(@FP0 char(20),@opercode char(10)=null,@opername char(20),@checkflag int)
--@checkflag=1  医师审核
--@checkflag=-1 医师取消审核
--@checkflag=2  医师提交
--@checkflag=-2 医师取消提交
--@checkflag=3  病案室审核
--@checkflag=-3 病案室取消审核
AS
begin
  declare @t_fp0 char(20)
  declare @t_currentdate datetime
  declare @t_fp121_date datetime
  declare @t_blcommitdate datetime
  declare @t_blcommitoper char(10)
  declare @t_fp132 datetime

  select @t_currentdate=getdate()
  

  if @checkflag=1
  begin
    select @t_fp121_date=null,@t_fp132=null,@t_blcommitdate=null
    select @t_fp0=fp0,@t_fp121_date=fp121_date,@t_fp132=fp132,@t_blcommitdate=blcommitdate from ba_fpage where fp0=@fp0
    if @t_fp121_date is not null
      return -1  --病案室已审核,医师不能再次审核
    if @t_fp132 is not null --and @t_blcommitdate is null
      return -2  --医生已审核

    update ba_fpage
      set fp131=@opername,fp132=@t_currentdate
      where fp0=@fp0

    insert ba_fpagelog(fp0,operdate,opername,opernote)
      values(@fp0,@t_currentdate,@OperName,'由临床医师审核确认')
  end else if @checkflag=-1
  begin
    select @t_fp0=fp0,@t_blcommitdate=blcommitdate from ba_fpage where fp0=@fp0 and fp121 is not null and rtrim(fp121)<>''
    if @t_fp0 is not null
      return -1  --病案室已审核,医师不能取消审核

    if @t_blcommitdate is not null 
      return -2  --病历已提交不能取消审核

      update ba_fpage
        set fp131=null,fp132=null
        where fp0=@fp0

      insert ba_fpagelog(fp0,operdate,opername,opernote)
        values(@fp0,@t_currentdate,@OperName,'由临床医师取消审核')
  end else if @checkflag=2
  begin
    select @t_fp0=fp0 from ba_fpage where fp0=@fp0 and fp121 is not null and rtrim(fp121)<>''
    if @t_fp0 is not null
      return -1  --病案室已审核,医师不能提交

    select @t_fp0=fp0 from ba_fpage where fp0=@fp0 and blcommitdate is not null
    if @t_fp0 is not null
      return -2  --已提交，不能再次提交

    select @t_fp0=fp0 from ba_fpage where fp0=@fp0 and fp132 is null
    if @t_fp0 is not null
      return -3  --提交前请先审核

    update ba_fpage
      set blcommitdate=@t_currentdate,blcommitoper=@opername
      where fp0=@fp0

    insert ba_fpagelog(fp0,operdate,opername,opernote)
      values(@fp0,@t_currentdate,@OperName,'由临床医师提交')
  end else if @checkflag=-2
  begin
    select @t_fp121_date=null
    select @t_blcommitdate=null
    select @t_fp0=fp0,@t_fp121_date=fp121_date,@t_blcommitdate=blcommitdate,@t_blcommitoper=blcommitoper
      from ba_fpage where fp0=@fp0
    if @t_fp121_date is not null
      return -1  --病案室已审核,医师取消提交


    if @t_blcommitdate is null
      return -2  --未提交，不能取消提交


    if rtrim(@t_blcommitoper)<>rtrim(@opername)
      return -3  --只允许提交操作员取消提交

    update ba_fpage
      set blcommitdate=null,blcommitoper=null
      where fp0=@fp0

    insert ba_fpagelog(fp0,operdate,opername,opernote)
      values(@fp0,@t_currentdate,@OperName,'由临床医师取消提交')
  end else if @checkflag=3
  begin
    select @t_fp0=fp0 from ba_fpage where fp0=@fp0 and fp121 is not null and rtrim(fp121)<>''
    if @t_fp0 is not null
      return -1  --病案室已审核,不能再次审核

    update ba_fpage
      set fp121=@opername,fp121_date=getdate()
      where fp0=@fp0

    declare @t_bastoreflag int
    select @t_bastoreflag=bastoreflag from unitset
    --如果不进行病案入库操作则自动去当前时间为首次入库时间
    if @t_bastoreflag is null or @t_bastoreflag=0
    begin
      insert ba_instore(zynum,operdate,opercode,opername)
        select fp0,getdate(),@opercode,@opername
        from ba_fpage (nolock)
        where fp0=@fp0

      update ba_fpage
        set fp161_date=getdate()
        from ba_fpage (nolock)
        where fp0=@fp0
    end

    insert ba_fpagelog(fp0,operdate,opername,opernote)
      values(@fp0,getdate(),@OperName,'由病案室操作员审核确认')
  end else if @checkflag=-3
  begin
    select @t_fp0=fp0 from ba_fpage where fp0=@fp0 and fp121 is null
    if @t_fp0 is not null
      return -1  --病案室未审核,不能取消审核

    update ba_fpage
      set fp121=null,fp121_date=null
      where fp0=@fp0

    insert ba_fpagelog(fp0,operdate,opername,opernote)
      values(@fp0,getdate(),@OperName,'由病案室操作员取消审核')
  end
end
GO
