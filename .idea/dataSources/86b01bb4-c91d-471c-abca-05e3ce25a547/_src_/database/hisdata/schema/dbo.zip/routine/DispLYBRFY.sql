CREATE PROCEDURE [dbo].[DispLYBRFY] AS
begin
  select m17 as currentlyksname,zynum,kmcode,kmname,checkmoney as kmmoney  into #lybrfy from zycheck,mbase (nolock) where zynum=m01 and deldate is null and m19 is null
  union all
  select m17,zynum,kmcode,kmname,ypmoney from zycfypk,mbase (nolock) where zynum=m01 and deldate is null and m19 is null


  select currentlyksname,zynum,kmcode,kmname,sum(kmmoney) as kmmoney from #lybrfy,kmcode where code=kmcode 
    group by currentlyksname,zynum,kmcode,kmname
    order by currentlyksname,zynum,kmcode,kmname
end
GO
