CREATE PROCEDURE [dbo].[DelZYCFYPK]
(@zynum int,@keyno numeric(18,0),@opername char(10),@note char(20))
AS
begin
  if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null) 
    return 1
  if exists(select keyno from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and fydate is not null)
    return 2
  if exists(select keyno from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and yjfpnum is not null)
    return 3
  if exists(select keyno from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and deldate is not null)
    return 4
  if exists(select keyno from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and ybtransflag is not null)
    return 5

  declare @currentdate datetime
  select @currentdate=getdate()

  update yfstore
    set a09=a09+ypcount*cfcount,a15=a15-ypcount*cfcount,a16=a16-ypcount*cfcount
    from yfstore,zycfypk    where a10=yfcode and a01=goodsno and zynum=@zynum and keyno=@keyno

  update zycfypk
    set deldate=@currentdate,deloper=@opername
  where zynum=@zynum and keyno=@keyno
  update mbase
    set m25=m25-ypmoney*cfcount
    from mbase,zycfypk
    where m01=zynum and keyno=@keyno

  insert mzchangeprice
    select zycfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,ypcount*cfcount,
          (a08-ypprice)*ypcount*cfcount,(a07-ypprice_1)*ypcount*cfcount,@opername,
          @note,yfcode.yfcode,yfcode.yfname
    from yfstore,zycfypk,yfcode
    where a01=zycfypk.goodsno and yfstore.a10=zycfypk.yfcode and zycfypk.yfcode=yfcode.yfcode
          and (zycfypk.ypprice<>a08 or zycfypk.ypprice_1<>a07) and zycfypk.keyno=@keyno
  return 0
end
GO
