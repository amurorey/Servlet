CREATE  PROCEDURE [dbo].[DelMZFYProc]
(@fpnum int,@cfnum int,@yfcode char(3),@opername char(10))
AS
begin
  declare @currentdate datetime
  select @currentdate=getdate()


  declare @mzmoreyfset int
  select @mzmoreyfset=mzmoreyfset from unitset


  if exists(select cfnum from mzcfinf (nolock) where cfnum=@cfnum and fpnum=@fpnum and fydate is null)
    return 1

  if exists(select yfcode from mzcfinf (nolock) where cfnum=@cfnum and fpnum=@fpnum and yfcode<>@yfcode)
    return 2
    
  if exists(select fpnum from MZINVOICE (nolock) where FPNUM=@fpnum and JSDATE is not null
            union all
            select fpnum from MZINVOICEHIS (nolock) where FPNUM=@fpnum and JSDATE is not null)
    return 3
            
  if exists(select cfnum from MZCFINF (nolock) where CFNUM=@cfnum and FPNUM=@fpnum and CFMONEY < 0
            union all
            select cfnum from MZCFINFHIS (nolock) where CFNUM=@cfnum and FPNUM=@fpnum and CFMONEY < 0)
    return 4

  update mzcfinf
    set fydate=null,
        fyopername=null
  where cfnum=@cfnum and fpnum=@fpnum
  update mzcfypk
    set fydate=null
  where cfnum=@cfnum and fpnum=@fpnum
  /***Compute the count of this CF***/
  select yfcode,fpnum,goodsno,sum(ypcount*cfcount) as sumypcount 
    into #cfypcount
    from mzcfypk
    where cfnum=@cfnum and fpnum=@fpnum
    group by yfcode,fpnum,goodsno

    /*判断是否是门诊划价时不判断库存方式 1:是 如果是则发药时下库存*/
  if @mzmoreyfset<>1  
  begin
    update yfstore
      set a16=a16+sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10
  end else
  begin
    update yfstore
      set a09=a09+sumypcount,a15=a15-sumypcount
    from yfstore,#cfypcount
    where #cfypcount.goodsno=a01 and #cfypcount.yfcode=a10

    insert mzchangeprice
       select mzcfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,-ypcount,(a08-ypprice)*(-ypcount)*cfcount,
              (a07-ypprice_1)*(-ypcount)*cfcount,@opername,
         '划价时价差',a10,a11 
       from yfstore,mzcfypk
       where a01=mzcfypk.goodsno and mzcfypk.yfcode=a10 and
                 (mzcfypk.ypprice<>a08 or mzcfypk.ypprice_1<>a07) and mzcfypk.cfnum=@cfnum and fpnum=@fpnum

    update mzcfinf
      set yfcode='',yfname=''
    where cfnum=@cfnum and fpnum=@fpnum
    update mzcfypk
      set yfcode=''
    where cfnum=@cfnum and fpnum=@fpnum
  end
end
GO
