CREATE       PROCEDURE [dbo].[AddZYCF] 
(@zynum int,@userid numeric,@opername char(10),@retval varchar(1024)="" output,
@currentdate datetime,@fyflag int,@operkscode char(4),@operksname char(20),
@xjsjnum char(10),@qfsetflag int,@yzflag int=2,@clflag int=null,@SubYZID int=null)
--@bqinputflag  是否是病区录入
AS
begin
  /**** @fyflag is 0:normal;  @fyflag is 1: process fy now ***/  
  declare @currentkscode char(4),@currentksname char(20),@qfmoney float
  /***判断是否有足够库存量***/
  if exists (select goodsno from _zycfypgroupview,yfstore
               where _zycfypgroupview.goodsno=yfstore.a01
               and _zycfypgroupview.yfcode=yfstore.a10
                and yfstore.a09<(_zycfypgroupview.sumypcount)
               and _zycfypgroupview.userid=@userid)
  begin
    declare @t_disptext char(100)
    DECLARE checkyfstore_cursor CURSOR FOR
      select rtrim(yfstore.a11)+'"'+rtrim(goodsname)+'"的库存为'+rtrim(convert(char(10),yfstore.a09))+'已不足' as disptext 
        from _zycfypgroupview,yfstore
         where _zycfypgroupview.goodsno=yfstore.a01
               and _zycfypgroupview.yfcode=yfstore.a10
               and yfstore.a09<(_zycfypgroupview.sumypcount)
               and _zycfypgroupview.userid=@userid    OPEN checkyfstore_cursor
    FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext+char(13)

      FETCH NEXT FROM checkyfstore_cursor into @t_disptext
    END
    CLOSE checkyfstore_cursor
    DEALLOCATE checkyfstore_cursor

    return 1
  end

  /***有无库存判断***/
  if exists (select goodsno from _zycfypgroupview where userid=@userid and
             goodsno not in(select a01 from yfstore,_zycfypgroupview (nolock) where goodsno=a01 and yfcode=a10))
  begin
    declare @t_disptext2 char(100)
    DECLARE checkyfstore_cursor2 CURSOR FOR
      select yfname+'无"'+rtrim(goodsname) as disptext
        from _zycfypgroupview where userid=@userid and
             goodsno not in(select a01 from yfstore,_zycfypgroupview (nolock) where goodsno=a01 and yfcode=a10)
    OPEN checkyfstore_cursor2
    FETCH NEXT FROM checkyfstore_cursor2 into @t_disptext2
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext2+char(13)

      FETCH NEXT FROM checkyfstore_cursor2 into @t_disptext2
    END
    CLOSE checkyfstore_cursor2
    DEALLOCATE checkyfstore_cursor2

    return 1
  end

  if exists(select m01 from mbase where m01=@zynum and m19 is null)
    select @currentkscode=m16,@currentksname=m17,@qfmoney=m25-m27-case when m50 is null then 0 else m50 end from mbase where m01=@zynum
  else
    return 2

  declare @sumcfmoney numeric(12,2)
  select @sumcfmoney=sum(ypmoney*cfcount) from _zycfypk,goods where goodsno=a01 and userid=@userid

  if (@xjsjnum is null) and @qfsetflag=0 and @qfmoney>0 and @sumcfmoney>0  /*禁止欠费输入(冲单时例外)*/
    return 3


  if (@xjsjnum is null) and @qfsetflag>=0 and @qfsetflag<@qfmoney+@sumcfmoney and @sumcfmoney>0 /*大于允许欠费额度(冲单时例外)*/
    return 4
  
  if @sumcfmoney<0  /*如果是冲单处理*/
  begin    select yfcode,goodsno,goodsname,sum(ypcount*cfcount) as sumypcount
      into #sumbrzyyp 
      from zycfypk (nolock)
      where zynum=@zynum and deldate is null
      group by yfcode,goodsno,goodsname

    if exists(select _zycfypgroupview.goodsname 
                from #sumbrzyyp,_zycfypgroupview
                where #sumbrzyyp.yfcode=_zycfypgroupview.yfcode and #sumbrzyyp.goodsno=_zycfypgroupview.goodsno 
                      and #sumbrzyyp.sumypcount<abs(_zycfypgroupview.sumypcount) and userid=@userid)
    begin
      select @retval='冲单药品"'+rtrim(_zycfypgroupview.goodsname)+'"冲单数量('+rtrim(convert(char(10),abs(_zycfypgroupview.sumypcount)))+
                     ')已大于以往实际处方总用量('+rtrim(convert(char(10),#sumbrzyyp.sumypcount))+')'
          from #sumbrzyyp,_zycfypgroupview
          where #sumbrzyyp.yfcode=_zycfypgroupview.yfcode and #sumbrzyyp.goodsno=_zycfypgroupview.goodsno 
                and #sumbrzyyp.sumypcount<abs(_zycfypgroupview.sumypcount) and userid=@userid
      return 5
    end

    if exists(select goodsname from _zycfypk (nolock) where userid=@userid and goodsno not in(select goodsno from #sumbrzyyp))
    begin      select @retval='"'+rtrim(goodsname)+'"该病人从未用过' from _zycfypk (nolock) where userid=@userid and goodsno not in(select goodsno from #sumbrzyyp)
      return 6
    end
  end

  if exists(select m01 from mbase (nolock) where m01=@zynum and m56 is not null)
    return 7  --已取消入院


  /*****Update _zycfypk*****/
  declare @t_cfnum int
  execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output
  update _zycfypk
    set cfnum=@t_cfnum
    where userid=@userid

  update _zycfypk 
    set hzylflag=case when a32='1' then '允许' else null end 
    from _zycfypk,goods
    where goodsno=a01 and userid=@userid

  update _zycfypk
    set yskscode=kscode,ysksname=ksname
    from _zycfypk,yscode
    where yscode=code and userid=@userid

  /*如果医保接口已运行则进行下列更新*/
  if exists(select YB_HOSPNO from unitset where YB_HOSPNO is not null)
  begin
    /*得到医报保对应的编码（如果有）*/
    update _zycfypk
      set ybno=a30
      from _zycfypk,goods
      where goodsno=a01 and userid=@userid

    /*得到医保科目*/
    update _zycfypk
      set ybkmcode=yb_goods.kmcode,
          yplb=case when yblb='1' or yblb='2' then yblb else '0' end,
          yplbname=case when yblb='1' then '甲类' when yblb='2' then '乙类' else '非甲非乙' end
      from _zycfypk,yb_goods
      where _zycfypk.ybno=yb_goods.goodsno and userid=@userid and yb_goods.flag=0
    update _zycfypk
      set ybkmcode=yb_checkcode.kmcode,
          yplb=case when yblb='1' or yblb='2' then yblb else '0' end,
          yplbname=case when yblb='1' then '甲类' when yblb='2' then '乙类' else '非甲非乙' end
      from _zycfypk,yb_checkcode
      where _zycfypk.ybno=yb_checkcode.checkno and userid=@userid and yb_checkcode.flag=0

    /*将没有对应的医保编码设置为十个9*/
    update _zycfypk
      set ybno='9999999999',yplb='0',yplbname='非甲非乙'
      where userid=@userid and (ybno is null or ybno='')

    /*将没有对应关系的编码的科目设为原科目*/
    update _zycfypk
      set ybkmcode=kmcode.ybkmcode
      from _zycfypk,kmcode
      where kmcode=code and userid=@userid and ybno='9999999999'
  end
  /********************************************/


  /***Insert into zycfypk table***/
  if @operkscode is null or @operkscode=''
  begin
    select @operkscode=@currentkscode
    select @operksname=@currentksname
  end

  declare @zgysname char(10)
  select @zgysname=ysname from mbase,kscwset (nolock)
    where kscode=m16 and cwname=m18 and m01=@zynum

  --如果是科室材料库，则执行科室取材料库所在科室
  if @clflag=1
    select @operkscode=code,@operksname=name 
      from _zycfypk (nolock),kscode (nolock) 
      where yfcode=ksclkcode and userid=@userid
  -------------------------------------------- 

  if @fyflag=0
  begin
    insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                   cfcount,goodsname,procname,unitname,yfcode,jzdate,
                   jzoper,kmcode,kmname,lykscode,lyksname,yscode,ysname,
                   yskscode,ysksname,yplb,yplbname,xjsjnum,percount,ypjl,
                   ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,ybno,ybkmcode,hzylflag,clflag,zgysname,jbypflag,SubYZID,
                   CopyFlag)
      select @zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
             cfcount,goodsname,procname,unitname,yfcode,@currentdate,@opername,kmcode,kmname,
             @currentkscode,@currentksname,yscode,ysname,yskscode,ysksname,yplb,yplbname,@xjsjnum,ypcount,
             ypjl,ypjlunit,yzusedmethod,yppath,yzid,@yzflag,yfname,@operksname,@operkscode,ybno,ybkmcode,hzylflag,@clflag,@zgysname,jbypflag,@SubYZID,
             case when YZID is null and YZID <> 0 then 1 else null end  --如果yzid不为空则表示此记录是复制医嘱执行后的记账记录
        from _zycfypk
        where userid=@userid
        order by keyno
  end else
  begin
    insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                   cfcount,goodsname,procname,unitname,yfcode,jzdate,
                   jzoper,kmcode,kmname,lykscode,lyksname,yscode,ysname,
                   yskscode,ysksname,fydate,fyopername,yplb,yplbname,ypjl,ypjlunit,yzusedmethod,yppath,yzid,
                   yzflag,yfname,operksname,operkscode,ybno,ybkmcode,hzylflag,clflag,zgysname,jbypflag,SubYZID,
                   CopyFlag)
      select @zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
             cfcount,goodsname,procname,unitname,yfcode,@currentdate,@opername,kmcode,kmname,
             @currentkscode,@currentksname,yscode,ysname,yskscode,ysksname,@currentdate,@opername,yplb,yplbname,
             ypjl,ypjlunit,yzusedmethod,yppath,yzid,@yzflag,yfname,@operksname,@operkscode,ybno,ybkmcode,hzylflag,@clflag,@zgysname,jbypflag,@SubYZID,
             case when YZID is null and YZID <> 0 then 1 else null end  --如果yzid不为空则表示此记录是复制医嘱执行后的记账记录
        from _zycfypk
        where userid=@userid        
        order by keyno
  end

  /***Update YFSTORE table***/
  if @fyflag=0  begin
    update yfstore
       set a09=a09-sumypcount,a15=a15+sumypcount,a16=a16+sumypcount
      from yfstore,_zycfypgroupview
      where a01=goodsno and a10=yfcode and userid=@userid
  end else
  begin
    update yfstore
       set a09=a09-sumypcount,a15=a15+sumypcount
      from yfstore,_zycfypgroupview
      where a01=goodsno and a10=yfcode and userid=@userid
  end

  /***Update MBASE table***/
  update mbase
    set m25=m25+@sumcfmoney
  where m01=@zynum and @sumcfmoney is not null
  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice
     select _zycfypk.goodsno,@currentdate,ypprice,ypprice_1,a08,a07,-ypcount,(a08-ypprice)*(-ypcount)*cfcount,
            (a07-ypprice_1)*(-ypcount)*cfcount,@opername,
            '划价时价差',yfcode,yfname 
     from yfstore,_zycfypk
     where a01=_zycfypk.goodsno and yfcode=a10 and
           (_zycfypk.ypprice<>a08 or _zycfypk.ypprice_1<>a07) and _zycfypk.userid=@userid
  return 0
end
GO
