/*执行住院材料退费*/
CREATE    PROCEDURE [dbo].[ExecZYTY_CL]
(@zynum int,@keyno numeric(18,0),@opername char(10),@operkscode char(4)=null)
AS
begin
  if exists(select m01 from mbase (nolock) where m19 is not null and m01=@zynum)
    return 1  --已出院

  if exists(select zynum from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and
              deldate is not null)
    return 2  --记录已被删除

  if exists(select zynum from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and
                yjfpnum is not null)
    return 3  --记录已被结算


  if @operkscode is not null
  begin
    if not exists(select zynum,jzoper from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and OPERKSCODE=@operkscode)
      return 4  --非本科室人员记账
  end

  if exists(select zynum from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and tyid is not null)
    return 5  --该记录已被退材料

  if exists(select zynum from zycfypk (nolock) where zynum=@zynum and keyno=@keyno and tycount=ypcount)
    return 6  --该记录不能再次退材料



  /*Get cfnum and tyid*/
  declare @t_cfnum int
  execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output

  declare @t_tyid int
  execute GetUniqueNo 17,@NewUniqueNo=@t_tyid output
  /*************************************/

  declare @currentdate datetime
  select @currentdate=getdate()

  insert zycfypk(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                 cfcount,goodsname,procname,unitname,yfcode,jzdate,
                 jzoper,kmcode,kmname,lykscode,lyksname,yscode,ysname,
                 yskscode,ysksname,yplb,yplbname,xjsjnum,percount,ypjl,
                 ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,
                 operksname,operkscode,fydate,fyopername,tycfnum,tyid,ybno,ybkmcode,hzylflag,clflag,zgysname)
    select zynum,@t_cfnum,goodsno,-ypcount,ypprice,ypprice_1,-ypmoney,
           1,goodsname,procname,unitname,yfcode,@currentdate,
           @opername,kmcode,kmname,lykscode,lyksname,yscode,ysname,
           yskscode,ysksname,yplb,yplbname,null,-percount,null,
           null,null,null,yzid,3,yfname,
           operksname,operkscode,@currentdate,@opername,cfnum,@t_tyid,ybno,ybkmcode,hzylflag,clflag,zgysname
        from zycfypk
        where keyno=@keyno and zynum=@zynum

  /*更新被退材料记录中的退材料量*/
  update zycfypk
    set tycount=ypcount,tycfnum=@t_cfnum,tyid=@t_tyid
    from zycfypk
    where keyno=@keyno and zynum=@zynum


  /*退材料时增加库存*/
  update yfstore
    set a09=a09+ypcount,a15=a15-ypcount
    from yfstore,zycfypk
    where a01=goodsno and a10=yfcode and zynum=@zynum and keyno=@keyno


  /***Update MBASE table***/
  update mbase
    set m25=m25-ypmoney
    from mbase,zycfypk
    where m01=zynum and zynum=@zynum and keyno=@keyno

  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice     select goodsno,@currentdate,ypprice,ypprice_1,a08,a07,ypcount,(a08-ypprice)*ypcount,            (a07-ypprice_1)*ypcount,@opername,'执行退材料时价差',yfcode,yfname      from yfstore,zycfypk
     where a01=goodsno and yfcode=a10 and (ypprice<>a08 or ypprice_1<>a07)
           and keyno=@keyno and zynum=@zynum

  return 0
end
GO
