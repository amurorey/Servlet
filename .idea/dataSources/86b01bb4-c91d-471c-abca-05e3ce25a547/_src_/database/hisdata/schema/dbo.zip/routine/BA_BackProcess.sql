CREATE PROCEDURE [dbo].[BA_BackProcess]
(@opername char(10),@userid numeric(18),@errmess char(40) output)
AS
begin
  select @errmess=null
  select @errmess=rtrim(convert(char(20),fp0))+'  '+fp2+'未被借阅或已归还' 
    from ba_fpage,_ba_borrowsheet (nolock) 
    where fp0=zynum and ba_fpage.borrowdate is null and userid=@userid
  if @errmess is not null
    return -1
  
  select @errmess=null
  select @errmess=rtrim(convert(char(20),fp0))+'  '+fp2+'尚未归档' 
    from ba_fpage,_ba_borrowsheet (nolock) 
    where fp0=zynum and ba_fpage.fp125 is null and userid=@userid


  update ba_borrowsheet
    set backdate=getdate(),backopername=@opername
    from ba_borrowsheet,_ba_borrowsheet
    where ba_borrowsheet.zynum=_ba_borrowsheet.zynum and userid=@userid and BackDate is null

  update ba_fpage
    set borrowdate=null,borrowysname=null
    from ba_fpage,_ba_borrowsheet
    where fp0=zynum and userid=@userid

  delete _ba_borrowsheet where userid=@userid

  return 0
end
GO
