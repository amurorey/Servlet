


CREATE VIEW _MZCFKMVIEW(kmname,kmcode,summoney,userid)
AS
select kmname as a23,kmcode as a22,ypmoney*cfcount,_mzcfypk.userid
  from _mzcfypk


GO
