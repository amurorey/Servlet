CREATE                PROCEDURE [dbo].[GetUniqueNo]
(@Flag int,@NewUniqueNo int output)
/******NOTE******/
/****The @Flag is a params, if it is "0" then get a unique no.
                            if it is "1" then get a goods no.
                            if it is "2" then get a goodsID.
                            if it is "3" then get a customer no.
                            if it is "4" then get a YSCode
                            if it is "5" then get a checkcode
                            if it is "6" then get a CFNUM
                            if it is "7" then get a FPNUM 
                            if it is "8" then get a ZYNUM
                            if it is "9" then get a ZYFPNUM
                            if it is "10" then get a PREPAYNUM
                            if it is "11" then get a YFSTORECHANGENUM
                            if it is "12" then get a CARDID
                            if it is "13" then get a CHECKGROUPCODE
                            if it is "14" then get a GROUPKEYNO
                            if it is "15" then get a YZID
                            if it is "16" then get a ZYYZID
                            if it is "17" then get a TYID
                            if it is "18" then get a mzcfmodcode
                            if it is "20" then get a yjsqnum
                            if it is "22" then get a mznum
                            if it is "23" then get a yzmodcode
                            if it is "24" then get a tfkeyno
                            if it is "25" then get a keynoid
                            if it is "26" then get a PatientID
                            if it is "27" then get a mzperpaynum
                            if it is "28" then get a ApplicationNum
                            if it is "29" then get a BANum(病案号）
                            if it is "30" then get a subyzid(子医嘱ID号）
                            if it is "31" then get a kftempid(库房暂存时代码）
                            if it is "32" then get a fyno(本次发药号，同一时间发药此号相同）
                            if it is "33" then get a InvoiceID(发票库房批次号）
                            if it is "34" then get a InvoiceOperID(发票操作员批次号）
                            if it is "35" then get a BillsID(发票出、入库及报损单据号
                            if it is "36" then get a BorrowSheetID用于记录电子病历借阅申请当前最大号
                            if it is "37" then get a NutritionCardGroupNo红河州营养卡打印时ID
                            if it is "38" then get a BA_Dict_Borrow_No得到病案借阅内容项目编号
                            if it is "39" then get a BA_Dict_Borrow_UseTo_No得到病案借阅申请理由编号
                            if it is "40" then get a BA_Borrow_No得到病案借阅申请编号*/
AS
begin
  declare @temp int
  select @temp=count(*) from systeminfo
  if @temp=0 
  begin
    insert systeminfo(UniqueNo,GoodsNo,GoodsID,CustomerNo,YSCODE,CHECKCODE,CFNUM,FPNUM,ZYNUM,ZYFPNUM,PREPAYNUM,YFSTORECHANGENO,CARDID,CHECKGROUPCODE,GROUPKEYNO,YZID,ZYYZID,TYID,MZCFMODCODE,YJSQNum,MZNum,YZModCode,TFKeyNo,KeyNoID,PatientID,MZPrepayNum,ApplicationNum,BANum,SubYZID,kftempid,fyno,InvoiceID,InvoiceOperID,BillsID,BL_BorrowSheetID,NutritionCardGroupNo,BA_Dict_Borrow_No,BA_Dict_Borrow_UseTo_No,BA_Borrow_No)
      values(0,0,0,0,0,0,0,0,1000000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10000000,0,0,0,0,0,0,0,0,10000000,0,0,0,0,0)
  end
  if @Flag=0
  begin
    update SystemInfo set UniqueNo=UniqueNo+1
    select @NewUniqueNo=UniqueNo from SystemInfo
  end
  if @Flag=1
  begin
    update SystemInfo set GoodsNo=GoodsNo+1
    select @NewUniqueNo=GoodsNo from SystemInfo
  end
  if @Flag=2
  begin
    update SystemInfo set GoodsID=GoodsID+1
    select @NewUniqueNo=GoodsID from SystemInfo
  end
  if @Flag=3
  begin
    update SystemInfo set CustomerNo=CustomerNo+1
    select @NewUniqueNo=CustomerNo from SystemInfo
  end
  if @Flag=4
  begin
    update SystemInfo set YSCode=YSCode+1
    select @NewUniqueNo=YSCode from SystemInfo
  end
  if @Flag=5
  begin
    update SystemInfo set CheckCode=CheckCode+1
    select @NewUniqueNo=CheckCode from SystemInfo
  end
  if @Flag=6
  begin
    update SystemInfo set cfnum=cfnum+1
    select @NewUniqueNo=cfnum from SystemInfo
  end
  if @Flag=7
  begin
    update SystemInfo set fpnum=fpnum+1
    select @NewUniqueNo=fpnum from SystemInfo
  end
  if @Flag=8
  begin
    update SystemInfo set zynum=zynum+1
    select @NewUniqueNo=zynum from SystemInfo
  end
  if @Flag=9
  begin
    update SystemInfo set zyfpnum=zyfpnum+1
    select @NewUniqueNo=zyfpnum from SystemInfo
  end 
  if @Flag=10
  begin
    update SystemInfo set prepaynum=prepaynum+1
    select @NewUniqueNo=prepaynum from SystemInfo
  end
  if @Flag=11
  begin
    update SystemInfo set yfstorechangeno=yfstorechangeno+1
    select @NewUniqueNo=yfstorechangeno from SystemInfo
  end
  if @Flag=12
  begin
    update SystemInfo set cardid=cardid+1
    select @NewUniqueNo=cardid from SystemInfo
  end
  if @Flag=13
  begin
    update SystemInfo set checkgroupcode=checkgroupcode+1
    select @NewUniqueNo=checkgroupcode from SystemInfo
  end
  if @Flag=14
  begin
    update SystemInfo set groupkeyno=groupkeyno+1
    select @NewUniqueNo=groupkeyno from SystemInfo
  end

  if @Flag=15
  begin
    update SystemInfo set yzid=yzid+1
    select @NewUniqueNo=yzid from SystemInfo  
  end

  if @Flag=16
  begin
    update SystemInfo set zyyzid=zyyzid+1
    select @NewUniqueNo=zyyzid from SystemInfo  
  end

  if @Flag=17
  begin
    update SystemInfo set tyid=tyid+1
    select @NewUniqueNo=tyid from SystemInfo  
  end

  if @Flag=18
  begin
    update SystemInfo set mzcfmodcode=mzcfmodcode+1
    select @NewUniqueNo=mzcfmodcode from SystemInfo  
  end

  if @Flag=20
  begin
    update SystemInfo set yjsqnum=yjsqnum+1
    select @NewUniqueNo=yjsqnum from SystemInfo  
  end

  if @Flag=22
  begin
    update SystemInfo set mznum=mznum+1
    select @NewUniqueNo=mznum from SystemInfo  
  end

  if @Flag=23
  begin
    update SystemInfo set yzmodcode=yzmodcode+1
    select @NewUniqueNo=yzmodcode from SystemInfo  
  end

  if @flag=24
  begin
    update SystemInfo set tfkeyno=tfkeyno+1
    select @NewUniqueNo=tfkeyno from SystemInfo  
  end

  if @flag=25
  begin
    update SystemInfo set keynoid=keynoid+1
    select @NewUniqueNo=keynoid from SystemInfo  
  end

  if @flag=26
  begin
    update SystemInfo set patientid=patientid+1
    select @NewUniqueNo=PatientID from systeminfo
  end

  if @flag=27
  begin
    update SystemInfo set mzprepaynum=mzprepaynum+1
    select @NewUniqueNo=mzprepaynum from systeminfo
  end

  if @flag=28
  begin
    update SystemInfo set applicationnum=applicationnum+1
    select @NewUniqueNo=applicationnum from systeminfo
  end

  if @flag=29
  begin
    if exists(select banum from systeminfo where banum=0)
    begin
      select @NewUniqueNo=0
    end else
    begin
      update SystemInfo set banum=banum+1
      select @NewUniqueNo=banum from systeminfo
    end
  end
 
  if @flag=30
  begin
    update SystemInfo set subyzid=subyzid+1
    select @NewUniqueNo=subyzid from systeminfo
  end

  if @flag=31
  begin
    update SystemInfo set kftempid=kftempid+1
    select @NewUniqueNo=kftempid from systeminfo
  end

  if @flag=32
  begin
    update SystemInfo set fyno=fyno+1
    select @NewUniqueNo=fyno from systeminfo
  end
  
  if @flag=33
  begin
    update SystemInfo set InvoiceID=InvoiceID+1
    select @NewUniqueNo=InvoiceID from systeminfo
  end

  if @flag=34
  begin
    update SystemInfo set InvoiceOperID=InvoiceOperID+1
    select @NewUniqueNo=InvoiceOperID from systeminfo
  end
  
  if @flag=35
  begin
    update SystemInfo set BillsID=BillsID+1
    select @NewUniqueNo=BillsID from systeminfo
  end

  if @Flag=36
  begin
    update SystemInfo set BL_BorrowSheetID=BL_BorrowSheetID+1
    select @NewUniqueNo=BL_BorrowSheetID from systeminfo
  end

  if @Flag=37
  begin
    update SystemInfo set NutritionCardGroupNo=NutritionCardGroupNo+1
    select @NewUniqueNo=NutritionCardGroupNo from systeminfo
  end
  
  if @Flag=38
  begin
    update SystemInfo set BA_Dict_Borrow_No=BA_Dict_Borrow_No+1
    select @NewUniqueNo=BA_Dict_Borrow_No from systeminfo
  end
  if @Flag=39
  begin
    update SystemInfo set BA_Dict_Borrow_UseTo_No=BA_Dict_Borrow_UseTo_No+1
    select @NewUniqueNo=BA_Dict_Borrow_UseTo_No from systeminfo
  end
  if @Flag=40
  begin
    update SystemInfo set BA_Borrow_No=BA_Borrow_No+1
    select @NewUniqueNo=BA_Borrow_No from systeminfo
  end
end
GO
