/*YZSheet表中XMFLAG的描述
YZFlag=1  长期医嘱
YZFlag=2  临时医嘱 （临时医嘱包括  检查申请xmflag=11  临时处方xmflag=6其中cfcount is null 则为西药临时处方  cfcount>0则为临时草药医嘱）

XMFlag=1  西药医嘱
XMFlag=2  西药组医嘱
XMFlag=3  中成药医嘱（指向中药房，非草药处方）
XMFlag=4  诊疗医嘱
XMFlag=5  非记账医嘱
XMFlag=6  临时处方（包括西药处方及草药处方）

xmflag=7  术后医嘱
XMFlag=8  产后医嘱
XMFlag=9  重整医嘱  
XMFlag=10 转科后医嘱(在接收转科后处理）

XMFlag=11 检查申请
XMFlag=12 会诊申请
*/

CREATE                      PROCEDURE [dbo].[DispYZSheet]
(@zynum int,@zyyzid int,@subyzid int=0,@yzflag int,@xmflag int=null,@dispflag int)
AS
begin
  declare @t_tabletext varchar(128)
  declare @t_zynum int
  select @t_zynum=zynum from yzsheet (nolock) where zynum=@zynum
  if @t_zynum is not null
    set @t_tabletext=' from yzsheet (nolock) left join goods (nolock) on xmcode=a01'
  else
    set @t_tabletext=' from yzsheethis (nolock) left join goods (nolock) on xmcode=a01'

  --此处强制更新sortid
  update yzsheet 
    set sortid=yzid
    where zynum=@zynum and zyyzid=@zyyzid and sortid is null
  -------------------
  declare @t_casetext varchar(1024)
  if @yzflag=1  /*显示长期医嘱*/
  begin
    declare @t_maxyzresetkeyno numeric(12,0)
    select @t_maxyzresetkeyno=max(keyno) from yzsheet (nolock) 
      where zynum=@zynum and xmflag in(7,8,9,10) and isnull(subyzid,0)=@subyzid
    if @t_maxyzresetkeyno is null 
      set @t_maxyzresetkeyno=0

    if @dispflag=1  /*显示所有长期医嘱*/
      set @t_casetext=' and yzflag=1'
    else
      set @t_casetext= ' and yzflag=1 and deldate is null and (yzstopdate is null or yzstophscode is null) and (not xmflag in(7,8,9,10) or keyno='+rtrim(convert(char(15),@t_maxyzresetkeyno))+')'
  end else       /*显示临时医嘱*/
  begin
    if @dispflag=1  /*显示所有临时医嘱*/
      set @t_casetext=' and (yzflag=2)'
    else
      set @t_casetext=' and (yzflag=2) and yzlastrundate is null and deldate is null'
  end

  set @t_casetext=@t_casetext+' and isnull(subyzid,0)='+rtrim(convert(char(20),@subyzid))

  if @xmflag=1
    set @t_casetext=@t_casetext+ ' and xmflag in(1,2,3,6,7,8,9,10)'  --仅显示药品医嘱
  else if @xmflag=2
    set @t_casetext=@t_casetext+ ' and xmflag in(4,5,7,8,9,10,11)'   --仅显示诊疗医嘱

/*  declare @t_orderflag int
  select @t_orderflag=yzorderflag from unitset
  declare @t_orderstr varchar(200)
  if @t_orderflag is null
    select @t_orderstr=' order by keyno'
  else
    select @t_orderstr=' order by sortid,keyno'*/

  declare @t_orderstr varchar(200)
  select @t_orderstr=' order by sortid,keyno'

  declare @t_sqltext varchar(6000)
  set @t_sqltext=N'select keyno,yzid,checkgroupkeyno,checkgroupcode,yzbegdate,zynum,'+
      'case when (xmflag=1 or xmflag=3) and a37=''1'' then ''(基)''+xmname'+
      ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) in(''┏'',''┃'',''┗'') then substring(xmname,1,1)+''(基)''+rtrim(substring(xmname,2,100))'+
      ' when xmflag=2 and a37=''1'' and substring(xmname,1,1) not in(''┏'',''┃'',''┗'') then ''(基)''+xmname'+
      ' when xmflag=4 and XMDescription is not null and rtrim(XMDescription)<>'''' then XMDescription'+
      ' when xmflag=5 then ''◇''+xmname else xmname end as xmname,'+
      'ypjl,ypjlunit,'+
      'convert(varchar(10),xmcount)+xmunit as xmcount,round(xmprice,2) as xmprice,'+
      'yzusedmethod,yppath,yzyscode,yzysname,yzcheckhscode,yzcheckhsname,yzrunhscode,yzrunhsname,'+
      'yzstopdate,yzstophsname,yzstopysname,yzlastrundate,yzrundate,yzcountforweek,yblb,yblbname,fsksname,'+
      'case when hzylflag is not null then ''允许'' else null end as hzylflag,yfname,'+
      'case when totcount is not null then convert(varchar(10),totcount)+xmunit else null end as totcount,note,xmflag,'+
      'case when a40=1 then ''非限制'' when a40=2 then ''限制'' when a40=3 then ''特殊'' else ''''  end as kjsflag,deldate,delopername,yzstophscode,jzflag,yzcreatebyhsorys,notjzflag,dspermin,sortid,drugdispense,'+
      'case when kjspurpose=1 then ''预防'' when kjspurpose=2 then ''治疗'' else '''' end as kjspurposedisp,'+
      'A54'+
      @t_tabletext+
      ' where zynum='+convert(varchar(20),@zynum)+' and zyyzid='+convert(varchar(20),@zyyzid)+' and checkgroupcode is null and cfcount is null'+
      @t_casetext +
      ' union all '+
      'select max(keyno),yzid,checkgroupkeyno,checkgroupcode,yzbegdate,zynum,'+
      'case when yjapplynum is null then ''★'' else ''▽'' end+case when XMDescription is not null and rtrim(XMDescription) <> '''' then XMDescription else checkgroupname end,'+
      'null,null,'+
      'convert(varchar(10),checkgroupcount)+''组套'',checkgroupprice,'+
      'yzusedmethod,null,yzyscode,yzysname,yzcheckhscode,yzcheckhsname,yzrunhscode,yzrunhsname,'+
      'yzstopdate,yzstophsname,yzstopysname,yzlastrundate,yzrundate,yzcountforweek,null,null,fsksname,null,null,'+
      'case when totcount is not null then convert(varchar(10),totcount)+''组套'' else null end,note,xmflag,'+
      'null,deldate,delopername,yzstophscode,jzflag,yzcreatebyhsorys,notjzflag,dspermin,sortid,null,null,null'+
      @t_tabletext+
      ' where zynum='+convert(varchar(20),@zynum)+' and zyyzid='+convert(varchar(20),@zyyzid)+' and checkgroupcode is not null and cfcount is null'+
      @t_casetext +
      ' group by checkgroupkeyno,yzid,yzbegdate,zynum,checkgroupcode,checkgroupname,XMDescription,yjapplynum,checkgroupcount,checkgroupprice,'+
      'yzusedmethod,yzyscode,yzysname,yzcheckhscode,yzcheckhsname,yzrunhscode,yzrunhsname,'+
      'yzstopdate,yzstophsname,yzstopysname,yzstopysname,yzlastrundate,yzrundate,yzcountforweek,fsksname,totcount,note,xmflag,deldate,delopername,yzstophscode,jzflag,yzcreatebyhsorys,notjzflag,dspermin,sortid'+
      ' union all '+
      'select max(keyno),yzid,null,null,yzbegdate,zynum,'+
      'xmdescription,'+
      'null,null,'+
      'null,null,'+
      'null,null,yzyscode,yzysname,yzcheckhscode,yzcheckhsname,yzrunhscode,yzrunhsname,'+
      'null,null,null,yzlastrundate,yzrundate,null,null,null,fsksname,null,null,'+
      'null,null,xmflag,'+
      'null,deldate,delopername,null,null,yzcreatebyhsorys,notjzflag,dspermin,sortid,null,null,null'+
      @t_tabletext+
      ' where zynum='+convert(varchar(20),@zynum)+' and zyyzid='+convert(varchar(20),@zyyzid)+' and checkgroupcode is null and cfcount is not null'+
      @t_casetext +
      ' group by yzid,yzbegdate,zynum,XMDescription,yzyscode,yzysname,yzcheckhscode,yzcheckhsname,yzrunhscode,yzrunhsname,'+
      ' yzlastrundate,yzrundate,fsksname,xmflag,deldate,delopername,yzcreatebyhsorys,notjzflag,dspermin,sortid'+
      @t_orderstr

  --exec sp_executesql @t_sqltext
  exec(@t_sqltext)
end
GO
