CREATE    PROCEDURE [dbo].[SaveStart] 
(@b01 int,@b02 varchar(10),@b03 datetime,@b04 varchar(15),@b05 varchar(10),
 @b06 varchar(40),@b07 varchar(3),@b08 varchar(10),@b09 varchar(10),@b10 varchar(40),
 @b11 varchar(10),@b12 varchar(4),@b13 money,@b14 varchar(10),@b15 float,
 @b16 money,@b17 numeric(12,2),@b18 money,@b18_1 money,@b19 datetime=null,@b20 varchar(12)=null,
 @b21 int=null,@b22 varchar(12)=null,@b23 varchar(10)=null,@b24 varchar(3),@b25 varchar(10),
 @b26 varchar(40)=null,@b27 varchar(10),@b29 varchar(10)=null,@b30 datetime=null,@b31 char(2),
 @b32 char(20)=null,@b33 char(20)=null,@b34 char(20)=null,@b35 char(20)=null,@b36 char(40)=null,
 @b38 char(10)=null,@goodsID int=null,@flag int)
AS
begin
insert start
  values(@b01,@b02,@b03,@b04,@b05,@b06,
         @b07,@b08,@b09,@b10,@b11,@b12,
         @b13,@b14,@b15,@b16,@b17,@b18,
         @b18_1,@b19,@b20,@b21,@b22,
         @b23,@b24,@b25,@b26,@b27,getdate(),
         @b29,@b30,@goodsID,@b31,@b32,@b33,@b34,@b35,@b36,@B38)
if @flag=0
begin
  insert store
    select goodsid,b05,b20,b06,b07,
         b08,b11,b12,a12,a13,b13,
         case
           when round(b13/a13,4) < 0.0001 then 0.0001
           else round(b13/a13,4)
         end,
         b16,
         case
           when round(b16/a13,4) < 0.0001 then 0.0001
           else round(b16/a13,4)
         end,
         b17,b17*a13,b24,b25,
         a14,a15,b03,b14,b15,b19,b22,b23,b09,b10,a24,b31,b32,b33,b34,b35,b36,null
    from start,goods
    where a01=b05 and start.goodsid=@goodsID
end else
begin
  if exists(select e01 from store where goodsid=@goodsID and e10<-@b17)
    return 1
  update store
    set e10=e10+@b17,
        e10_1=e10_1+@b17*e07_2
  from store
  where store.goodsid=@goodsID
end
return 0
end
GO
