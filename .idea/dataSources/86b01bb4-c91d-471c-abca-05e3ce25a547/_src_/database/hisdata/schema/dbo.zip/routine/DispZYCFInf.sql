CREATE PROCEDURE [dbo].[DispZYCFInf]
(@zynum int,@yfcode char(4)=null) with recompile
AS 
begin
  if @yfcode is null 
  begin
    if exists(select zynum from zycfypk where zynum=@zynum) 
      select zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag,
             sum(cfcount*case when deldate is null then ypmoney else 0 end) as cfmoney
        from zycfypk (nolock)
        where zynum=@zynum and clflag is null
        group by zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag
        order by jzdate desc
    else
      select zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag,
             sum(cfcount*case when deldate is null then ypmoney else 0 end) as cfmoney
        from zycfypkhis (nolock)
        where zynum=@zynum and clflag is null
        group by zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag
        order by jzdate desc
  end else
  begin
    if exists(select zynum from zycfypk where zynum=@zynum) 
      select zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag,
             sum(cfcount*case when deldate is null then ypmoney else 0 end) as cfmoney
        from zycfypk (nolock)
        where zynum=@zynum and yfcode=@yfcode and clflag is null
        group by zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag
        order by jzdate desc
    else
      select zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag,
             sum(cfcount*case when deldate is null then ypmoney else 0 end) as cfmoney
        from zycfypkhis (nolock)
        where zynum=@zynum and yfcode=@yfcode and clflag is null
        group by zynum,cfnum,cfcount,yfcode,yfname,ysname,jzdate,jzoper,yzflag
        order by jzdate desc
  end
end
GO
