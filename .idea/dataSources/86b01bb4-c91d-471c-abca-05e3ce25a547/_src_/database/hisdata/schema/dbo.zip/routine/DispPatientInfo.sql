CREATE                               PROCEDURE [dbo].[DispPatientInfo]
(@zynum int,@mznum int,@SubYZID int=0)
AS
begin
  declare @t_unitname char(40)
  select @t_unitname=unitname from unitset

  if @zynum<>0
  begin
    declare @t_name nvarchar(100)
    declare @t_str nvarchar(1024)
    select @t_str=''
    DECLARE diagnose_cursor CURSOR FOR
      select rtrim(diagnosename_ys)
        from ba_diagnose (nolock)
          where zynum=rtrim(convert(char(20),@zynum))
    OPEN diagnose_cursor
    FETCH NEXT FROM diagnose_cursor into @t_name
    WHILE @@FETCH_STATUS = 0
    BEGIN
      if @t_name is not null and rtrim(@t_name)<>''
        select @t_str=@t_str+@t_name+'；'

      FETCH NEXT FROM diagnose_cursor into @t_name
    END
    CLOSE diagnose_cursor
    DEALLOCATE diagnose_cursor

    if @SubYZID<>0
    begin
      select null as mznum,
           null as yscode,
           null as ysname,
           null as registerdate,
           null as processdate,
           m62 as Complaint,
           null as Symptom,
           null as Advice,
           null as Allergy,
           case when fp0 is null then convert(varchar(20),m01) else fp0 end as fp0,
           fp1,
           FP_PatientID as patientid,
           case when fp2 is null then m04 else fp2 end as fp2,
           case when fp3 is null then m05
                when fp3='1' then '男'
                else '女'
           end as fp3,
           case when fp4 is null then m06 else fp4 end as fp4,
           case when fp5 is null then convert(varchar(20),m07) else fp5 end as fp5,
           case when fp8='1' then '未婚' 
                when fp8='2' then '已婚'
                when fp8='3' then '丧偶'
                when fp8='4' then '离异'
           else '其他' end as fp8,
           fp9_ys,
           fp9_name,
           case when fp10_ys is null then m10 else fp10_ys end as fp10_ys,
           fp11_ys,
           fp11_name,
           fp12,
           case when fp14 is null then m10 else fp14 end as fp14,
           case when fp17_ys is null then m10 else fp17_ys end as fp17_ys,
           case when fp22 is null then m09 else fp22 end as fp22,
           case when fp23_name is null then m13 else fp23_name end as fp23_name,
           case when fp25 is null then m51 else fp25 end as fp25,
           case when fp29_name is null then m17 else fp29_name end as fp29_name,
           case when fp31 is null then m53 else fp31 end as fp31,
           case when fp33 is null then m22 else fp33 end as fp33,
           case when fp36_ys is null then m40 else fp36_ys end as fp36_ys,
           case when fp37_ys is null then m40 else fp37_ys end as fp37_ys,
           @t_str as fp41_ys,
           case when fp42='1' then '治愈'
                when fp42='2' then '好转'
                when fp42='3' then '未愈'
                when fp42='4' then '死亡'
                else '其他'
           end as fp42,
           fp56,
           fp134,
           fp136,
           case when fp137_ys is null then m10 else fp137_ys end as fp137_ys,
           m16,
           m17,
           m18,
           m35,
           case when FP6='1' then '城镇职工医保'
                when FP6='2' then '城镇居民医保'
                when FP6='3' then '新农合'
                when FP6='4' then '贫困救助'
                when FP6='5' then '商业医疗保险'
                when FP6='6' then '全公费'
                when FP6='7' then '全自费'
                when FP6='8' then '其它社会保险'
                else '其它'
           end as TreatmentName,
           --FP22,
           FP22_1,
           FP22_2,
           FP22_3,
           PersonNo,
           getdate() as nowdate,
           SubYZID,
           BabyName as SubName,
           Sex as SubSex,
           BirthDay as SubBirthDay,
           Weight as SubWeight,
           Diagnose as SubDiagnose,
           datediff(day,BirthDay,getdate())+1 as SubDayTime,
           '' as MenarcheFlag,
           '' as fp37ClearOrNot,
           @t_unitname as unitname
      from Mbase (nolock) left join BA_Fpage (nolock) on (convert(varchar,m01)=fp0) left join YZSubBase (nolock) on (m01=zynum)
      where m01=@zynum and case when SubYZID is null then 0 else SubYZID end=@SubYZID
    end else
    begin
      select null as mznum,
           null as yscode,
           null as ysname,
           null as registerdate,
           null as processdate,
           m62 as Complaint,
           null as Symptom,
           null as Advice,
           null as Allergy,
           case when fp0 is null then convert(varchar(20),m01) else fp0 end as fp0,
           fp1,
           FP_PatientID as patientid,
           case when fp2 is null then m04 else fp2 end as fp2,
           case when fp3 is null then m05
                when fp3='1' then '男'
                else '女'
           end as fp3,
           case when fp4 is null then m06 else fp4 end as fp4,
           case when fp5 is null then convert(varchar(20),m07) else fp5 end as fp5,
           case when fp8='1' then '未婚' 
                when fp8='2' then '已婚'
                when fp8='3' then '丧偶'
                when fp8='4' then '离异'
           else '其他' end as fp8,
           fp9_ys,
           fp9_name,
           case when fp10_ys is null then m10 else fp10_ys end as fp10_ys,
           fp11_ys,
           fp11_name,
           fp12,
           case when fp14 is null then m10 else fp14 end as fp14,
           case when fp17_ys is null then m10 else fp17_ys end as fp17_ys,
           case when fp22 is null then m09 else fp22 end as fp22,
           case when fp23_name is null then m13 else fp23_name end as fp23_name,
           case when fp25 is null then m51 else fp25 end as fp25,
           case when fp29_name is null then m17 else fp29_name end as fp29_name,
           case when fp31 is null then m53 else fp31 end as fp31,
           case when fp33 is null then m22 else fp33 end as fp33,
           case when fp36_ys is null then m40 else fp36_ys end as fp36_ys,
           case when fp37_ys is null then m40 else fp37_ys end as fp37_ys,
           @t_str as fp41_ys,
           case when fp42='1' then '治愈'
                when fp42='2' then '好转'
                when fp42='3' then '未愈'
                when fp42='4' then '死亡'
                else '其他'
           end as fp42,
           fp56,
           fp134,
           fp136,
           case when fp137_ys is null then m10 else fp137_ys end as fp137_ys,
           m16,
           m17,
           m18,
           m35,
           case when FP6='1' then '城镇职工医保'
                when FP6='2' then '城镇居民医保'
                when FP6='3' then '新农合'
                when FP6='4' then '贫困救助'
                when FP6='5' then '商业医疗保险'
                when FP6='6' then '全公费'
                when FP6='7' then '全自费'
                when FP6='8' then '其它社会保险'
                else '其它'
           end as TreatmentName,
           --FP22,
           FP22_1,
           FP22_2,
           FP22_3,
           PersonNo,
           getdate() as nowdate,
           null as SubYZID,
           null as SubName,
           null as SubSex,
           null as SubBirthDay,
           null as SubWeight,
           null as SubDiagnose,
           null as SubDayTime,
           '' as MenarcheFlag,
           '' as fp37ClearOrNot,
           @t_unitname as unitname
      from Mbase (nolock) left join BA_Fpage (nolock) on (convert(varchar,m01)=fp0)
      where m01=@zynum
    end
  end else
  begin
    select mzregistersheet.mznum,
           mzregistersheet.yscode,
           mzregistersheet.ysname,
           mzregistersheet.registerdate,
           case when mzregistersheet.ProcessDate is null then getdate()
                else mzregistersheet.ProcessDate
           end as processdate,
           mzregistersheet.Complaint,
           mzregistersheet.Symptom,
           mzregistersheet.Advice,
           patientbase.Allergy,
           null as fp0,
           null as fp1,
           mzregistersheet.patientid,
           mzregistersheet.patientname as fp2,
           mzregistersheet.sex as fp3,
           mzregistersheet.birthday as fp4,
           mzregistersheet.age as fp5,
           null as fp8,
           patientbase.professional as fp9_ys,
           patientbase.professional as fp9_name,
           mzregistersheet.address as fp10_ys,
           patientbase.NationType as fp11_ys,
           patientbase.NationType as fp11_name,
           null as fp12,
           mzregistersheet.address as fp14,
           patientbase.AddressOfPersonID as fp17_ys,
           mzregistersheet.Tel as fp22,
           null as fp23_name,
           mzregistersheet.registerdate as fp25,
           null as fp29_name,
           null as fp31,
           null as fp33,
           mzregistersheet.diagnose as fp36_ys,
           null as fp37_ys,
           null as fp41_ys,
           null as fp42,
           null as fp56,
           null as fp134,
           null as fp136,
           mzregistersheet.address as fp137_ys,
           mzregistersheet.kscode as m16,
           mzregistersheet.ksname as m17,
           null as m18,
           mzregistersheet.processdoctor as m35,
           MZRegisterSheet.TreatmentName as TreatmentName,
           --null as FP22,
           null as FP22_1,
           null as FP22_2,
           null as FP22_3,
           patientbase.personid as PersonNo,
           getdate() as nowdate,
           null as SubYZID,
           null as SubName,
           null as SubSex,
           null as SubBirthDay,
           null as SubWeight,
           null as SubDiagnose,
           null as SubDayTime,
           '' as MenarcheFlag,
           '' as fp37ClearOrNot,
           @t_unitname as unitname
    from mzregistersheet (nolock),patientbase (nolock)
    where mzregistersheet.patientid=patientbase.patientid and mznum=@mznum
  end
end
GO
