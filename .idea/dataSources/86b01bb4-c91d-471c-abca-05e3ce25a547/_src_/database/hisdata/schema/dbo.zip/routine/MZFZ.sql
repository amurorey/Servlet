CREATE      PROCEDURE [dbo].[MZFZ]
(@mznum int,@flag int=0,@ysname varchar(20)=null,@mzattrib int=null,@linenum char(10) output)
AS
begin
  if @flag=0  --分诊
  begin
    if exists(select mznum from mzlinebase (nolock) where mznum=@mznum)
      return -1  --已被分诊

    if exists(select mznum from mzregistersheet (nolock) where mznum=@mznum and processdate is not null)
      return -2  --已就诊

    declare @kscode char(4)
    declare @yscode char(4)
    declare @departmentcode char(4)
    declare @departmentName char(20)
    declare @t_linenum int
    declare @reserveflag int

    if @mzattrib is null 
      select @mzattrib=xmattrib
        from mzregistersheet (nolock) where mznum=@mznum
   
    
    select @kscode=kscode,@yscode=yscode,@reserveflag=reserveflag
        from mzregistersheet (nolock) where mznum=@mznum

    select @departmentcode=departmentcode,@departmentname=departmentname
      from kscode (nolock) where code=@kscode
   
    if @reserveflag is null    -- 非预约时
    begin
      if exists(select kscode from mzlinenum (nolock) where kscode=@kscode and mzattrib=@mzattrib and reserveflag is null and (yscode=@yscode or mzattrib<>3))
      begin
        if @mzattrib <> 3
        begin
          update mzlinenum  
            set num=num+1
            where kscode=@kscode and mzattrib=@mzattrib and reserveflag is null


          select @linenum=rtrim(convert(char(10),num)) from mzlinenum (nolock)
            where kscode=@kscode and mzattrib=@mzattrib and reserveflag is null
        end else
        begin
          update mzlinenum  
            set num=num+1
            where kscode=@kscode and mzattrib=@mzattrib and yscode=@yscode and reserveflag is null

          select @linenum=rtrim(convert(char(10),num)) from mzlinenum (nolock)
            where kscode=@kscode and mzattrib=@mzattrib and yscode=@yscode and reserveflag is null
        end
      end else
      begin
        insert mzlinenum(kscode,mzattrib,num,departmentcode,yscode)
          values(@kscode,@mzattrib,1,@departmentcode,@yscode)

          select @linenum=1
      end
    end else                  --预约时
    begin
      if exists(select kscode from mzlinenum (nolock) where kscode=@kscode and mzattrib=@mzattrib and reserveflag=1)
      begin
        update mzlinenum  
          set num=num+1
          where kscode=@kscode and mzattrib=@mzattrib and reserveflag=1

          select @linenum=rtrim(convert(char(10),num)) from mzlinenum (nolock)
            where kscode=@kscode and mzattrib=@mzattrib and reserveflag=1
      end else
      begin
        insert mzlinenum(kscode,mzattrib,num,departmentcode,reserveflag)
          values(@kscode,@mzattrib,1,@departmentcode,1)

        select @linenum=1
      end
    end


    if len(@linenum)=1 
      select @linenum='00'+@linenum
    else if len(@linenum)=2
      select @linenum='0'+@linenum

    if @reserveflag is null
    begin
      if @mzattrib=3
        select @linenum='V'+@linenum  --专家号（不同专家的号段重新取号）
      else if @mzattrib=2
        select @linenum='J'+@linenum  --急诊
      else
        select @linenum='P'+@linenum  --普通
    end else
    begin
      select @linenum='Y'+@linenum  --预约
    end


    insert mzlinebase(mznum,linenum,patientname,kscode,ksname,ysname,mzattrib,linedate,processflag,departmentcode,departmentname)
      select mznum,@linenum,patientname,kscode,ksname,ysname,@mzattrib,getdate(),1,@departmentcode,@departmentname
       from mzregistersheet (nolock) where mznum=@mznum

    update MZRegistersheet
      set callnum=@linenum
      where mznum=@mznum
  end else  --取消分诊
  begin
    delete mzlinebase where mznum=@mznum

    update mzregistersheet
      set callnum=@linenum
      where mznum=@mznum

  end

  update mzlinebase
    set ysname=@ysname
    where mznum=@mznum and @ysname is not null and rtrim(@ysname)<>''

  return 0
end
GO
