CREATE PROCEDURE [dbo].[GetUserID]
(@NewUserID int output)
AS
begin
  declare @temp int
  select @temp=count(*) from UserID
  if @temp=0 
  begin
    insert UserID values(0)
  end
  update UserID set UniqueNo=UniqueNo+1
  select @NewUserID=UniqueNo from UserID
end
GO
