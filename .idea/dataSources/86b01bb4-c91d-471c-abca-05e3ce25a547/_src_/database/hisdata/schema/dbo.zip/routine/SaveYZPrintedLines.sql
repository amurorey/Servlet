CREATE     PROCEDURE [dbo].[SaveYZPrintedLines]
(@zynum int,@zyyzid int,@printedlines int,@yzflag int,@subyzid int=0)
AS
begin
  if exists(select zynum from yzprintedlines (nolock) where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid)
    update yzprintedlines
      set printedlines_long=case when @yzflag=1 then @printedlines else printedlines_long end,
          printedlines_ls=case when @yzflag=2 then @printedlines else printedlines_ls end
    where zynum=@zynum and zyyzid=@zyyzid and case when subyzid is null then 0 else subyzid end=@subyzid
  else
    insert yzprintedlines(zynum,zyyzid,printedlines_long,printedlines_ls,subyzid)
      values(@zynum,@zyyzid,case when @yzflag=1 then @printedlines else null end,case when @yzflag=2 then @printedlines else null end,@subyzid)
end
GO
