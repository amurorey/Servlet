CREATE PROCEDURE [dbo].[YZJCReport1_1] 
(@begdate datetime,@enddate datetime)
AS
begin
select yskscode,ysksname,COUNT(*) as mzrc,SUM(summoney) as mzmoney
from
(
select yskscode,ysksname,yscode,ysname,fpname,fpdate,SUM(summoney) as summoney
  from (
         select yskscode,ysksname,YSCODE,YSNAME,MZINVOICE.FPNAME,
                CONVERT(varchar(10),mzcfypk.fpdate,121) as fpdate,
                sum(YPMONEY*CFCOUNT) as summoney
           from mzcfypk (nolock),mzinvoice (nolock)
           where mzcfypk.deldate is null and mzcfypk.fpnum=mzinvoice.fpnum
             and MZCFYPK.FPDATE>=@begdate and MZCFYPK.FPDATE<@enddate
           group by YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICE.FPNAME,
                    CONVERT(varchar(10),mzcfypk.fpdate,121)
         union all
         select yskscode,ysksname,YSCODE,YSNAME,MZINVOICEHIS.FPNAME,
                CONVERT(varchar(10),MZCFYPKHIS.FPDATE,121) as fpdate,
                sum(YPMONEY*CFCOUNT) as summoney
           from mzcfypkhis (nolock),mzinvoicehis (nolock)
           where MZCFYPKHIS.deldate is null and MZCFYPKHIS.fpnum=MZINVOICEHIS.fpnum
             and MZCFYPKHIS.FPDATE>=@begdate and MZCFYPKHIS.FPDATE<@enddate
           group by YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICEHIS.FPNAME,
                    CONVERT(varchar(10),MZCFYPKHIS.FPDATE,121)
         union all
         select YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICE.FPNAME,
                CONVERT(varchar(10),MZCHECK.FPDATE,121) as fpdate,
                SUM(CHECKMONEY) as summoney
           from MZCHECK (nolock),MZINVOICE (nolock)
           where MZCHECK.DELDATE is null and MZCHECK.FPNUM=MZINVOICE.FPNUM
             and MZCHECK.FPDATE>=@begdate and MZCHECK.FPDATE<@enddate
           group by YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICE.FPNAME,
                    CONVERT(varchar(10),MZCHECK.FPDATE,121)
         union all
         select YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICEHIS.FPNAME,
                CONVERT(varchar(10),MZCHECKHIS.FPDATE,121) as fpdate,
                SUM(CHECKMONEY) as summoney
           from MZCHECKHIS (nolock),MZINVOICEHIS (nolock)
           where MZCHECKHIS.DELDATE is null and MZCHECKHIS.FPNUM=MZINVOICEHIS.FPNUM
             and MZCHECKHIS.FPDATE>=@begdate and MZCHECKHIS.FPDATE<@enddate
           group by YSKSCODE,YSKSNAME,YSCODE,YSNAME,MZINVOICEHIS.FPNAME,
                    CONVERT(varchar(10),MZCHECKHIS.FPDATE,121)
       ) disptab
  group by yskscode,ysksname,yscode,ysname,fpname,fpdate
) as disptab2
group by yskscode,ysksname
order by yskscode,ysksname

end
GO
