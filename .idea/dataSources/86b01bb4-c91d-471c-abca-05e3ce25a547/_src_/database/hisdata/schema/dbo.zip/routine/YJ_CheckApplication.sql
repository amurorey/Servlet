--此存储过程用于医技科室对电子申请单的确认
--包括门诊及住院
--1、门诊仅对已收费的申请单进行确认
--2、住院分为记账及确认，如申请单设置为“医技科室确认后记账”则确认包括确认及记账，否则则仅进行确认操作

--返回值：-1:无此申请单号  0：正常  1：已被确认不能再次确认  2：患者已出院（指住院患者）  3：禁止欠费模式下已欠费（指住院患者）    4：欠费金额大于允许额度（指住院患者）
CREATE              PROCEDURE [dbo].[YJ_CheckApplication]
(@applynum int,@yjkscode varchar(20),@opername varchar(20),@userid numeric(18))
AS
begin
  if not exists(select applynum from patient_applicationsheet (nolock)
                  where applynum=@applynum)
    return -1
    
  if exists(select applynum from patient_applicationsheet (nolock)
              where applynum=@applynum and yjcheckdate is not null and priceflag=1)
  begin
    update Patient_ApplicationSheet
      set YJCheckDate2=GETDATE(),YJCheckOper2=@opername
      where APPLYNUM=@applynum and YJCheckDate is not null and PriceFlag=1
      
    return 0
  end;
    

  if exists(select applynum from patient_applicationsheet (nolock)
              where applynum=@applynum and yjcheckdate is not null and priceflag is null)
    return 1  --此申请单已被确认，不能再次确认

  declare @t_zynum int
  select @t_zynum=zynum from patient_applicationsheet
    where applynum=@applynum and yjcheckdate is null

  declare @t_m19 datetime
  declare @t_m56 datetime
  select @t_m19=null
  select @t_m19=m19,@t_m56=m56 from mbase (nolock) where m01=@t_zynum
  if (@t_m19 is not null) or (@t_m56 is not null)
    return 2  --住院患者已出院，不能确认此申请



  --如住院号不为空则为住院患者，则进行以下操作，如有未记账的申请则记账，同时判断是否欠费
  if @t_zynum is not null
  begin   
    --先将数据复制到临时表中
    declare @t_zyqfset int  --系统默认欠费设置
    select @t_zyqfset=defzyqfset from unitset

    declare @t_zgysname char(20)
    declare @qfmoney numeric(12,2)
    declare @t_m34 numeric(12,2)  --本病人欠费设置
    select @t_zgysname=m35,@qfmoney=m25-m27-case when m50 is null then 0 else m50 end,@t_m34=m34
      from mbase (nolock)
      where m01=@t_zynum


    if @t_m34 is null -- 如本患者没有单独设置过欠费则取系统默认设置
    begin
      if @t_zyqfset is null 
        set @t_zyqfset=-1  --允许无限欠费
      else
        set @t_zyqfset=0  --禁止欠费
    end else
    begin
      set @t_zyqfset=@t_m34
    end

    declare @sumcheckmoney numeric(12,2)
    select @sumcheckmoney=sum(patient_applicationcheckcode.checkmoney) 
      from patient_applicationcheckcode,patient_applicationsheet
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and 
            patient_applicationcheckcode.applynum=@applynum and jzdate is null and jzflag=1 /*必须满足医技科室确认后记账的记录1、医技科室审核后记账  2、出报告后记账*/

    select @sumcheckmoney=case when @sumcheckmoney is null then 0 else @sumcheckmoney end

    if @t_zyqfset=0 and @qfmoney>0 /*禁止欠费时如已欠费则退出*/
      return 3


    if @t_zyqfset>0 and @t_zyqfset<(@qfmoney+@sumcheckmoney) /*大于允许欠费额度*/
      return 3

    select checkno,checkprice,checkcount,patient_applicationcheckcode.checkmoney,
           checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
           yskscode,ysksname,checklb,checklbname,unitname,patient_applicationcheckcode.fskscode,
           patient_applicationcheckcode.fsksname,null as hsflag,null as hscode,null as hsname,yzid,null as yzusedmethod,2 as yzflag,
           groupcode,groupname,groupprice,groupcount,newgroupkeyno as groupkeyno,ybno,ybkmcode,'    ' as hzylflag,patient_applicationsheet.applynum as yjapplynum,getdate() as procdate,@userid as userid
      into #temptab
      from patient_applicationcheckcode,patient_applicationsheet
      where patient_applicationcheckcode.applynum=patient_applicationsheet.applynum and 
            patient_applicationcheckcode.applynum=@applynum and jzdate is null and jzflag=1/*必须满足医技科室确认后记账的记录1、医技科室审核后记账  2、出报告后记账*/


    select @sumcheckmoney=sum(case when checkmoney is null then 0 else checkmoney end) from #temptab

    if @t_zyqfset>=0 and @t_zyqfset<(@qfmoney+@sumcheckmoney) /*大于允许欠费额度*/
    begin
      return 4
    end


    --更新合作医疗标志
    update #temptab
      set hzylflag=case when checkcode.hzylflag=1 then '允许' else '' end,
          ybno=ybcheckcode,checklb=checkcode.checklb,checklbname=checkcode.checklbname
      from #temptab,checkcode
      where checkno=code

    /***Get CFNUM***/
    declare @t_checkcfnum int
    execute GetUniqueNo 6,@NewUniqueNo=@t_checkcfnum output

    insert zycheck(zynum,checkno,checkprice,checkcount,checkmoney,jzoper,jzdate,
                   checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                   yskscode,ysksname,checklb,checklbname,unitname,xjsjnum,fskscode,
                   fsksname,hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,jzkscode,
                   groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,
                   hzylflag,yjapplynum,zgysname,applicationflag,yjcheckdate,yjcheckoper)
      select @t_zynum,checkno,checkprice,checkcount,checkmoney,@opername,getdate(),
             checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
             yskscode,ysksname,checklb,checklbname,unitname,null,fskscode,
             fsksname,hsflag,null,null,yzid,yzusedmethod,2,@t_checkcfnum,@yjkscode,
             groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,
             case when rtrim(hzylflag)= '' then null else rtrim(hzylflag) end,yjapplynum,@t_zgysname,1,getdate(),@opername
        from #temptab
        where checkprice is not null
        order by groupkeyno

    --删除临时表中数据

    update patient_applicationsheet
      set jzdate=getdate(),jzoper=@opername
      where zynum=@t_zynum and applynum=@applynum and jzdate is null and jzflag=1

    update mbase
      set m25=m25+@sumcheckmoney
      where m01=@t_zynum and @sumcheckmoney is not null

    update zycheck
      set yjcheckdate=getdate(),yjcheckoper=@opername
      where zynum=@t_zynum and yjapplynum=@applynum and yjcheckdate is null
  end

  --以下对申请单进行审核（包括门诊及住院，此步骤不包括记账）
  update patient_applicationsheet
    set yjcheckdate=getdate(),yjcheckoper=@opername
    where applynum=@applynum and yjcheckdate is null

  update patient_applicationcheckcode
    set yjcheckdate=getdate(),yjcheckoper=@opername
    where applynum=@applynum and yjcheckdate is null

  update yj_applysheet
    set yjcheckdate=getdate(),yjcheckopername=@opername
    where applynum=@applynum and yjcheckdate is null

  update yj_applysheethis
    set yjcheckdate=getdate(),yjcheckopername=@opername
    where applynum=@applynum and yjcheckdate is null
  -----------------------------------------------------


  return 0
end
GO
