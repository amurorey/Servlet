CREATE          PROCEDURE [dbo].[TurnZYDataToHis] AS
begin
begin transaction
/*** Insert Current "zycfinf" table to "zycfinfhis" table ***/
/*insert zycfinfhis(cfnum,zynum,yscode,ysname,cfflag,cfprice,cfcount,cfmoney,jzdate,jzoper,
         fydate,fyopername,yfcode,yfname,deldate,deloper,yskscode,ysksname,lykscode,
         lyksname,yjfpnum,fpdate,operksname,operkscode,checkdate,checkoper)
  select cfnum,zynum,yscode,ysname,cfflag,cfprice,cfcount,cfmoney,jzdate,jzoper,
         fydate,fyopername,yfcode,yfname,deldate,deloper,yskscode,ysksname,lykscode,
         lyksname,yjfpnum,fpdate,operksname,operkscode,checkdate,checkoper
    from zycfinf,mbase
    where zycfinf.zynum=mbase.m01 and mbase.m31 is not null
if @@error <> 0 
begin
  rollback
  return -1
end*/

/*** Insert Current "zycfypk" table to "zycfypkhis" table ***/
insert zycfypkhis(zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                  cfcount,goodsname,procname,unitname,yfcode,jzdate,jzoper,
                  jsdate,fpdate,fydate,fyopername,deldate,deloper,kmcode,kmname,lykscode,
                  lyksname,yscode,ysname,yskscode,ysksname,yjfpnum,yplb,yplbname,xjsjnum,
                  percount,ypjl,ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,
                  tycfnum,tycount,tyid,ybno,ybkmcode,ybtransflag,hyflag,hzylflag,clflag,zgysname,jbypflag,
                  printedjdcard,putdrugdate,putdrugflag,fyno,PrintedJDCard2,SubYZID,DrugDispense,CopyFlag)
  select zynum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                  cfcount,goodsname,procname,unitname,yfcode,jzdate,jzoper,
                  jsdate,fpdate,fydate,fyopername,deldate,deloper,kmcode,kmname,lykscode,
                  lyksname,yscode,ysname,yskscode,ysksname,yjfpnum,yplb,yplbname,xjsjnum,
                  percount,ypjl,ypjlunit,yzusedmethod,yppath,yzid,yzflag,yfname,operksname,operkscode,
                  tycfnum,tycount,tyid,ybno,ybkmcode,ybtransflag,hyflag,hzylflag,clflag,zgysname,jbypflag,
                  printedjdcard,putdrugdate,putdrugflag,fyno,PrintedJDCard2,SubYZID,DrugDispense,CopyFlag
    from zycfypk,mbase
    where zycfypk.zynum=mbase.m01 and mbase.m31 is not null
if @@error <> 0 
begin
  rollback
  return -1
end
/*** Insert Current "zycheck" table to "zycheckhis" table ***/
insert zycheckhis(zynum,checkno,checkprice,checkcount,checkmoney,jzdate,jzoper,jsdate,fpdate,
                  deldate,deloper,checkname,kmname,kmcode,lykscode,lyksname,yscode,ysname,
                  yskscode,ysksname,yjfpnum,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,
                  hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,cdcfnum,tfid,jzkscode,
                  groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,ybtransflag,
                  hzylflag,checkoper,checkdate,yjapplynum,tfkeyno,ybjyid,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID,Scale)
  select zynum,checkno,checkprice,checkcount,checkmoney,jzdate,jzoper,jsdate,fpdate,
         deldate,deloper,checkname,kmname,kmcode,lykscode,lyksname,yscode,
         ysname,yskscode,ysksname,yjfpnum,checklb,checklbname,unitname,xjsjnum,fskscode,fsksname,
         hsflag,hscode,hsname,yzid,yzusedmethod,yzflag,cfnum,cdcfnum,tfid,jzkscode,
         groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,ybtransflag,
         hzylflag,checkoper,checkdate,yjapplynum,tfkeyno,ybjyid,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID,Scale
    from zycheck,mbase
    where zycheck.zynum=mbase.m01 and mbase.m31 is not null
if @@error <> 0 
begin
  rollback
  return -1
end
/*** Insert Current "prepay" table to "prepayhis" table ***/
insert prepayhis(p01,p02,p03,p04,p05,p06,p07,p08,p09,p10,fpnum,InvoiceNum,InvoiceOperID,InvoiceNum_FP,InvoiceOperID_FP)
  select p01,p02,p03,p04,p05,p06,p07,p08,p09,p10,fpnum,InvoiceNum,InvoiceOperID,InvoiceNum_FP,InvoiceOperID_FP
    from prepay,mbase
    where prepay.p01=mbase.m01 and mbase.m31 is not null
   
if @@error <> 0 
begin
  rollback
  return -1
end


/*** Insert Current "yzsheet" table to "yzsheethis" table ***/
insert yzsheethis(ZYNUM,ZYYZID,YZID,YZFLAG,YZBEGDATE,XMCODE,XMNAME,KMCODE,
                  KMNAME,XMUNIT,XMPRICE,XMCOUNT,XMMONEY,XMFLAG,YPJL,YPJLUNIT,YZUSEDMETHOD,
                  YZCOUNTFORDAY,YZCOUNTFORWEEK,YPPATH,DSPERMIN,YFCODE,YFNAME,YZYSCODE,
                  YZYSNAME,YZYSKSCODE,YZYSKSNAME,YZCHECKHSCODE,YZCHECKHSNAME,YZRUNHSCODE,
                  YZRUNHSNAME,YZLASTRUNDATE,YZSTOPDATE,YZSTOPYSCODE,YZSTOPYSNAME,YZSTOPHSCODE,
                  YZSTOPHSNAME,YBLB,YBLBNAME,LYKSCODE,LYKSNAME,CHECKGROUPCODE,CHECKGROUPNAME,
                  CHECKGROUPPRICE,CHECKGROUPCOUNT,CHECKGROUPKEYNO,YJApplyNUM,PRNFLAG,
                  FSKSCODE,FSKSNAME,HZYLFLAG,CFNum,TotCount,Note,CFCount,XMDescription,Diagnose,
                  DelDate,DelOperName,subyzid,jzflag,note2,YZCreatedate,yzcreateopername,yzcreatebyHSOrYS,notjzflag,
                  CFType,SortID,OperYZFlag,blflag,yzrundate,NotJZYZFlag,DrugDispense,KJSPurpose)
  select ZYNUM,ZYYZID,YZID,YZFLAG,YZBEGDATE,XMCODE,XMNAME,KMCODE,
         KMNAME,XMUNIT,XMPRICE,XMCOUNT,XMMONEY,XMFLAG,YPJL,YPJLUNIT,YZUSEDMETHOD,
         YZCOUNTFORDAY,YZCOUNTFORWEEK,YPPATH,DSPERMIN,YFCODE,YFNAME,YZYSCODE,
         YZYSNAME,YZYSKSCODE,YZYSKSNAME,YZCHECKHSCODE,YZCHECKHSNAME,YZRUNHSCODE,
         YZRUNHSNAME,YZLASTRUNDATE,YZSTOPDATE,YZSTOPYSCODE,YZSTOPYSNAME,YZSTOPHSCODE,
         YZSTOPHSNAME,YBLB,YBLBNAME,LYKSCODE,LYKSNAME,CHECKGROUPCODE,CHECKGROUPNAME,
         CHECKGROUPPRICE,CHECKGROUPCOUNT,CHECKGROUPKEYNO,YJApplyNUM,PRNFLAG,
         FSKSCODE,FSKSNAME,HZYLFLAG,CFNum,TotCount,Note,CFCount,XMDescription,Diagnose,
         DelDate,DelOperName,subyzid,jzflag,note2,YZCreatedate,yzcreateopername,yzcreatebyHSOrYS,notjzflag,
         CFType,SortID,OperYZFlag,blflag,yzrundate,NotJZYZFlag,DrugDispense,KJSPurpose
    from yzsheet,mbase
    where zynum=m01 and m31 is not null
    order by keyno
if @@error <> 0 
begin
  rollback
  return -1
end

/*** Insert YJ_ApplySheet to YJ_ApplySheetHIS Table ***/
insert yj_applysheethis(ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,GroupKeyNo,ItemCode,
       ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,
       ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,FPDate,JSDate,FPNum,DelDate,DelOperCode,DelOperName,
       YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,CDApplyNum,SampleCode,SampleType,Emergency_Flag)
  select ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,GroupKeyNo,ItemCode,
         ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,
         ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,FPDate,JSDate,FPNum,DelDate,DelOperCode,DelOperName,
         YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,CDApplyNum,SampleCode,SampleType,Emergency_Flag
  from yj_applysheet,mbase
  where patientinnum=m01 and m31 is not null
if @@error <> 0 
begin
  rollback
  return -1
end


/*** Delete Current Data of the operator ***/
delete zycfypk  from mbase,zycfypk
  where zycfypk.zynum=mbase.m01 and mbase.m31 is not null and zynum in(select zynum from zycfypkhis)
if @@error <> 0 
begin
  rollback
  return -1
end

--delete zycfinf
--  from mbase,zycfinf
--  where zycfinf.zynum=mbase.m01 and mbase.m31 is not null
--if @@error <> 0 
--begin
--  rollback
--  return -1
--end

delete zycheck
  from mbase,zycheck
  where zycheck.zynum=mbase.m01 and mbase.m31 is not null and zynum in(select zynum from zycheckhis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete prepay
  from mbase,prepay  where prepay.p01=mbase.m01 and mbase.m31 is not null and p01 in(select p01 from prepayhis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete yzsheet
  from yzsheet,mbase
  where zynum=m01 and m31 is not null and zynum in(select zynum from yzsheethis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete yj_applysheet
  from yj_applysheet,mbase
  where patientinnum=m01 and m31 is not null and patientinnum in(select patientinnum from yj_applysheethis where patientkind=2)
if @@error <> 0 
begin
  rollback
  return -1
end



delete _zycfinf where procdate<dateadd(day,-4,getdate())
delete _zycfypk where procdate<dateadd(day,-4,getdate())
delete _zycheck where procdate<dateadd(day,-4,getdate())
delete _zyfysheet where procdate<dateadd(day,-4,getdate())
delete _vw_lis_report where GetResultDate<dateadd(day,-2,getdate())
commit transaction
return 0
end
GO
