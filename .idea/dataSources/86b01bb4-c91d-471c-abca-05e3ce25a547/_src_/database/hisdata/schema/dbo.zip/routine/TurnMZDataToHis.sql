CREATE PROCEDURE [dbo].[TurnMZDataToHis] AS
begin
begin transaction
/*** Insert Current "mzinvoice" table to "mzinvoicehis" table ***/
insert mzinvoicehis(FPNUM,FPNAME,FPMONEY,YP_MONEY,CHECK_MONEY,FPDATE,OPERNAME,JSDATE,DELDATE,CDNUM,CFS,
                    YBFLAG,YBNUM,JFCARDID,ROUNDFLAG,JFINITDATE,YBAREACODE,YBAREANAME,ZFMONEY1,ZFMONEY2,
                    ROUNDMONEY,YBError,MZREGISTERFLAG,YLDY,patientid,mznum,transno,ZFMONEY3,InvoiceNum,InvoiceOperID,Sex)
  select FPNUM,FPNAME,FPMONEY,YP_MONEY,CHECK_MONEY,FPDATE,OPERNAME,JSDATE,DELDATE,CDNUM,CFS,
                    YBFLAG,YBNUM,JFCARDID,ROUNDFLAG,JFINITDATE,YBAREACODE,YBAREANAME,ZFMONEY1,ZFMONEY2,
                    ROUNDMONEY,YBError,MZREGISTERFLAG,YLDY,patientid,mznum,transno,ZFMONEY3,InvoiceNum,InvoiceOperID,Sex
    from mzinvoice where jsdate is not null
if @@error <> 0 
begin
  rollback
  return -1
end
/*** Insert Current "mzcfinf" table to "mzcfinfhis" table ***/
insert mzcfinfhis(CFNUM,FPNUM,YSCODE,CFFLAG,CFPRICE,CFCOUNT,CFMONEY,FYDATE,FYOPERNAME,
                  YFCODE,YFNAME,YSNAME,YSKSCODE,YSKSNAME,FPDATE,DELDATE,
                  YFCANCDDATE,YFCANCDOPERNAME)
  select cfnum,mzcfinf.fpnum,yscode,cfflag,cfprice,cfcount,cfmoney,fydate,fyopername,
         yfcode,yfname,ysname,yskscode,ysksname,mzcfinf.fpdate,mzcfinf.deldate,
         mzcfinf.yfcancddate,mzcfinf.yfcancdopername
    from mzcfinf,mzinvoicehis
    where mzcfinf.fpnum=mzinvoicehis.fpnum and
      mzinvoicehis.jsdate is not null
if @@error <> 0 
begin
  rollback
  return -1
end
/*** Insert Current "mzcfypk" table to "mzcfypkhis" table ***/
insert mzcfypkhis(fpnum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
                  cfcount,goodsname,procname,unitname,yfcode,fpdate,fydate,
                  deldate,yscode,kmcode,kmname,ysname,yskscode,ysksname,
                  jfcardid,yblb,yblbname,ybno,ybkmcode,jbypflag,fskscode,
                  fsksname,clflag,YZID,YPPath)
  select mzcfypk.fpnum,cfnum,goodsno,ypcount,ypprice,ypprice_1,ypmoney,
         cfcount,goodsname,procname,unitname,yfcode,mzcfypk.fpdate,fydate,
         mzcfypk.deldate,yscode,kmcode,kmname,ysname,yskscode,ysksname,
         mzcfypk.jfcardid,yblb,yblbname,ybno,ybkmcode,jbypflag,fskscode,
         fsksname,clflag,YZID,YPPath
    from mzcfypk,mzinvoicehis
    where mzcfypk.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null
if @@error <> 0 
begin
  rollback
  return -1
end
/*** Insert Current "mzcheck" table to "mzcheckhis" table ***/
insert mzcheckhis(fpnum,checkno,checkprice,checkcount,checkmoney,yscode,fpdate,deldate,checkname,kmname,kmcode,ysname,yskscode,ysksname,fskscode,fsksname,unitname,checklb,checklbname,groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,yjapplynum)
  select mzcheck.fpnum,checkno,checkprice,checkcount,checkmoney,yscode,mzcheck.fpdate,mzcheck.deldate,checkname,kmname,kmcode,ysname,yskscode,ysksname,fskscode,fsksname,unitname,checklb,checklbname,groupcode,groupname,groupprice,groupcount,groupkeyno,ybno,ybkmcode,yjapplynum
    from mzcheck,mzinvoicehis
    where mzcheck.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null
if @@error <> 0 
begin
  rollback
  return -1
end

/*** Insert YJ_ApplySheet to YJ_ApplySheetHIS Table ***/
insert yj_applysheethis(ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,GroupKeyNo,ItemCode,
       ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,
       ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,FPDate,JSDate,FPNum,DelDate,DelOperCode,DelOperName,
       YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,CDApplyNum,SampleCode,SampleType,Emergency_Flag)
  select ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,GroupKeyNo,ItemCode,
         ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,ApplyKSCode,ApplyKSName,
         ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,yj_applysheet.FPDate,yj_applysheet.JSDate,yj_applysheet.FPNum,yj_applysheet.DelDate,DelOperCode,DelOperName,
         YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,CDApplyNum,SampleCode,SampleType,Emergency_Flag
  from yj_applysheet,mzinvoicehis
  where yj_applysheet.fpnum=mzinvoicehis.fpnum and yj_applysheet.jsdate is not null and patientkind=1
if @@error <> 0 
begin
  rollback
  return -1
end



/*** Delete Current Data of the operator ***/
delete mzcfypk
  from mzcfypk,mzinvoicehis
  where mzcfypk.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null and mzcfypk.fpnum in(select fpnum from mzcfypkhis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete mzcfinf
  from mzcfinf,mzinvoicehis
  where mzcfinf.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null and mzcfinf.fpnum in(select fpnum from mzcfinfhis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete mzcheck
  from mzcheck,mzinvoicehis
  where mzcheck.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null and mzcheck.fpnum in(select fpnum from mzcheckhis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete mzinvoice
 from mzinvoice,mzinvoicehis
 where mzinvoice.fpnum=mzinvoicehis.fpnum and mzinvoicehis.jsdate is not null and mzinvoice.fpnum in(select fpnum from mzinvoicehis)
if @@error <> 0 
begin
  rollback
  return -1
end

delete yj_applysheet
  from yj_applysheet,mzinvoicehis
  where yj_applysheet.fpnum=mzinvoicehis.fpnum and yj_applysheet.jsdate is not null and patientkind=1 and yj_applysheet.fpnum in(select fpnum from yj_applysheethis where patientkind=1)
if @@error <> 0 
begin
  rollback
  return -1
end


delete _mzcfinf where procdate<dateadd(day,-4,getdate())
delete _mzcfypk where procdate<dateadd(day,-4,getdate())

delete _mzcheck where procdate<dateadd(day,-4,getdate())

commit transaction

------以下操作不在事务中操作------
delete operatorlog where datediff(dd,procdate,getdate())>180  --删除180天前的登录日志

declare @t_userid numeric(18,0)
select @t_userid=max(UserID) from _YHYB_TransSheet
delete _yhyb_transsheet where userid<@t_userid-500     --删除银海医保数据传输的临时表的残留数据
----------------------------------

return 0

end
GO
