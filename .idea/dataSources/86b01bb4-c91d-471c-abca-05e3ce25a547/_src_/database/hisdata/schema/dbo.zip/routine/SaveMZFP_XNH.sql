CREATE        PROCEDURE [dbo].[SaveMZFP_XNH]
(@yldyname char(20),@ywzqid char(40),@bsdid char(40),@jsid varchar(20),@userid numeric,
 @fpnum int,@fpname char(20),@xnhnum char(20),@jfcardid char(10)=null,
 @ylznum char(20),@xnhareacode char(10),@xnhareaname char(20),@yllbcode char(4),@yllbname char(20),@sex char(4),
 @personno char(20),@fpdate datetime,@fpopercode char(10),@fpopername char(10),
 @fpmoney numeric(12,2),@oldfpnumval int=null,@leftzhmoney numeric(12,2),@yberror numeric(12,2)=null,
 @YBFPMoney numeric(12,2),@XJZFMoney numeric(12,2),@TCZFMoney numeric(12,2),@ZHZFMoney numeric(12,2),
 @DEZFMoney numeric(12,2),@SJBCMoney numeric(12,2),@QFXMoney numeric(12,2),@ZFMoney numeric(12,2),
 @ZLMoney numeric(12,2),@FHBCMoney numeric(12,2),@JRTCMoney numeric(12,2),@JRDEMoney numeric(12,2),
 @TCFDZFMoney numeric(12,2),@DEFDZFMoney numeric(12,2),@CFDXZFMoney numeric(12,2),@CBZCWFMoney numeric(12,2),
 @YLDYLBCode char(3),@YLDYLBName varchar(50),@JBCode varchar(50)=null,@JBName varchar(100)=null,
 @retval char(1024) output,@mznum int=null,@patientid nvarchar(10)=null,@CXJZFMoney numeric(12,2)=null,
 @DBBCBXZFMoney numeric(12,2)=null,@XHDBBXZFMoney numeric(12,2)=null,
 @InvoiceNum varchar(20)=null,@InvoiceOperID int=null)
AS
begin
  declare @ret int
  declare @ybzf numeric(12,2)
  select @ybzf=@YBFPMoney-@XJZFMoney  --医保总费用-现金支付=医保支付总额

  execute @ret=SaveMZFP @fpnum=@fpnum,
                        @userid=@userid,
                        @fpname=@fpname,
                        @fpmoney=@fpmoney,
                        @opername=@fpopername,
                        @retval=@retval output,
                        @currentdate=@fpdate,
                        @oldfpnum=@oldfpnumval,
                        @ybflag=2,
                        @ybnum=@xnhnum,
                        @jfcardid=@jfcardid,
                        @roundflag=null,
                        @ybareacode=@xnhareacode,
                        @ybareaname=@xnhareaname,
                        @zfmoney1=@ybzf,
                        @zfmoney2=@XJZFMoney,
                        @roundmoney=null,
                        @mznum=@mznum,
                        @yldyname=@yldyname,
                        @fpnum_tmp=null,
                        @yberror=@yberror,
                        @patientid=@patientID,
                        @InvoiceNum=@InvoiceNum,
                        @InvoiceOperID=@InvoiceOperID,
                        @sex=@sex
                        

/*  exec @ret=SaveMZFP @fpnum,@userid,@fpname,@fpmoney,@fpopername,@retval output,@fpdate,
       @oldfpnumval,2,@xnhnum,@jfcardid,null,@xnhareacode,@xnhareaname,@ybzf,@XJZFMoney,
       null,@mznum,@yldyname,null,@yberror,@patientid*/
  if @ret <> 0 
    return @ret

  insert xnh_invoicebase(FPNum,PatientState,YWZQID,BSDID,JSID,FPName,XNHNum,YLZNum,
                         XNHAreaCode,XNHAreaName,YLLBCode,YLLBName,JBCode,JBName,Sex,PersonNo,
	       	         MZNum,FPDate,FPOperCode,FPOperName,LeftZHMoney,FPMoney,
                         YBFPMoney,XJZFMoney,TCZFMoney,ZHZFMoney,DEZFMoney,SJBCMoney,
		         QFXMoney,ZFMoney,ZLMoney,FHBCMoney,JRTCMoney,JRDEMoney,
                         TCFDZFMoney,DEFDZFMoney,CFDXZFMoney,CBZCWFMoney,YLDYLBCode,YLDYLBName,
                         CDNum,CXJZFMoney,DBBCBXZFMoney,XHDBBXZFMoney)
    values(@FPNum,1,@YWZQID,@BSDID,@JSID,@FPName,@XNHNum,@YLZNum,
           @XNHAreaCode,@XNHAreaName,@YLLBCode,@YLLBName,@JBCode,@JBName,@Sex,@PersonNo,
	   @FPNum,@FPDate,@FPOperCode,@FPOperName,@LeftZHMoney,@FPMoney,
           @YBFPMoney,@XJZFMoney,@TCZFMoney,@ZHZFMoney,@DEZFMoney,@SJBCMoney,
           @QFXMoney,@ZFMoney,@ZLMoney,@FHBCMoney,@JRTCMoney,@JRDEMoney,
           @TCFDZFMoney,@DEFDZFMoney,@CFDXZFMoney,@CBZCWFMoney,@YLDYLBCode,@YLDYLBName,
           @oldfpnumval,@CXJZFMoney,@DBBCBXZFMoney,@XHDBBXZFMoney)

  if (@oldfpnumval<>0) and (@oldfpnumval is not null) 
    update xnh_invoicebase
     set CDNum=@fpnum
     where fpnum=@oldfpnumval
 return 0
end
GO
