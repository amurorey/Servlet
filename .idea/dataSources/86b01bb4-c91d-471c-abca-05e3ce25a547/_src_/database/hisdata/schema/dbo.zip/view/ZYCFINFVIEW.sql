













/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2005-01-24 09:32:15 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2004-12-05 21:16:02 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2004-11-19 10:15:21 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2004-10-18 16:22:46 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2004-08-19 10:16:19 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2003-11-07 20:41:34 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2003-07-25 16:36:34 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2003-07-11 14:02:10 ******/
/****** Object:  View dbo.ZYCFINFVIEW    Script Date: 2003-06-20 08:59:59 ******/
CREATE VIEW dbo.ZYCFINFVIEW
AS
SELECT *
FROM zycfinf (nolock) where deldate is null
UNION ALL
SELECT *
FROM zycfinfhis (nolock) where deldate is null


GO
