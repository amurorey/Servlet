CREATE    PROCEDURE [dbo].[SaveOutSheet] 
(@sheetno char(10), @storecode char(3), @storename char(10),@procdate datetime,
 @customercode char(10), @customername char(40),@opername char(10),
 @userid int, @retval varchar(100)="" output, @flag int)
AS
begin
/****Check unique sheetno****/
if exists (select * from outstock where c02=@sheetno and c24=@storecode)
  return 1
/****check if have enough in store****/
if exists (select store.goodsid,store.e03 from store,_instock
            where store.goodsid=_instock.goodsid and _instock.b17>store.e10 and _instock.userid=@userid)
begin
  select @retval='批次号为"'+ltrim(str(_instock.goodsid))+'"的"'+rtrim(_instock.b06)+'"已不足'
    from store,_instock
    where store.goodsid=_instock.goodsid and _instock.b17>store.e10 and _instock.userid=@userid
  return 2
end
/***check if have enough in yfstore***/
if exists(select yfstore.a01 from yfstore,_instock,goods
  where _instock.b05=goods.a01 and yfstore.a01=_instock.b05 
    and _instock.b09=yfstore.a10 and _instock.b17*goods.a13+yfstore.a09<0
    and _instock.userid=@userid)
begin
  select @retval='品名为:"'+rtrim(yfstore.a02)+'"的商品在药房库存已不足' 
    from yfstore,_instock,goods
    where _instock.b05=goods.a01 and yfstore.a01=_instock.b05 
    and _instock.b09=yfstore.a10 and _instock.b17*goods.a13+yfstore.a09<0
    and _instock.userid=@userid
  return 3
end

declare @t_applynum int
select @t_applynum=applynum from _instock where userid=@userid and ApplyNum is not null
if @t_applynum is not null 
begin
  if not exists(select O02 from OutStockApply (nolock) where O02=@t_applynum)
  return 4
end


update instock_save
  set b02=@sheetno
  from instock_save a,_instock b
  where a.code_save=b.code_save and b.userid=@userid

/************************************/
/****Update _instock table****/
update _instock
  set b02=@sheetno,
      b03=@procdate,
      b09=@customercode,
      b10=@customername,
      b24=@storecode,
      b25=@storename,
      b27=@opername,
      b28=getdate()
  where userid=@userid
update _instock
  set b13_1=case 
             when (round(b13/a13,4) < 0.0001) and b13 <>0 then 0.0001
             else round(b13/a13,4)
            end,
      b16_1=case  
             when round(b16/a13,4) < 0.0001 and b16 <>0  then 0.0001
             else round(b16/a13,4)
            end
   from _instock,goods
   where a01=b05 and userid=@userid
/****Insert into outstock table****/
insert outstock
        (c02,c03,c04,c05,c06,
         c07,c08,c09,c10,c11,c12,
         c13,c13_1,c14,c15,c16,c16_1,c17,c17_1,c18,
         c18_1,c19,c20,c21,c22,
         c23,c24,c25,c26,c27,c28,
         c29,c30,goodsid,c31,c32,c33,c34,c35,c36,c37,c38,
         applynum,applyid)
  select b02,b03,b04,b05,b06,
         b07,b08,b09,b10,b11,b12,
         b13,b13_1,b14,b15,b16,b16_1,b17,b17*a13,b18,
         b18_1,b19,b20,b21,b22,
         b23,b24,b25,b26,b27,b28,
         b29,b30,goodsid,b31,b32,b33,b34,b35,b36,b37,b38,
         applynum,applyid
    from _instock,goods
    where userid=@userid and b05=a01

/***update store table***/
update store
  set e10=store.e10-disp.b17,
      e10_1=(store.e10-disp.b17)*store.e07_2
  from store,(select goodsid,sum(b17) as b17 from _instock where userid=@userid group by goodsid) disp
  where store.goodsid=disp.goodsid 

/*以下变量用于计算调价盈余*/
declare @t_goodsno varchar(20)
declare @t_goodsno2 varchar(20)
declare @t_pj numeric(12,4)
declare @t_lj numeric(12,4)
declare @t_pj2 numeric(12,4)
declare @t_lj2 numeric(12,4)
declare @t_sl int
declare @t_goodsid int
declare @s_sl int
/*----------------------*/

/***if @flag is 1 it means '冲单'***/
if @flag<>1 
begin
  /***update mzchangeprice if the price of yfstore is not a same price***/

  /*如果是门诊多药房划价则出库时将门诊对应的所有药房的价格设为一致*/
  if exists(select mzmoreyfset from unitset where mzmoreyfset is not null)
  begin
    insert mzchangeprice(GOODSNO,PROCDATE,OLDPRICE1,OLDPRICE2,NEWPRICE1,NEWPRICE2,YPCOUT,MONEY1,MONEY2,OPERNAME,NOTE,YFCODE,YFNAME)
      select b05,getdate(),a08,a07,b16_1,b13_1,a09,a09*(b16_1-a08),a09*(b13_1-a07),@opername,
           '入库价差',a10,a11
      from _instock,yfstore
      where b05=a01  and ( b16_1<>a08 or b13_1<>a07) and userid=@userid and a10 in(select yfcode from mzmoreyfcode)

    update yfstore
      set yfstore.a05=b11,
          a07=b13_1,a08=b16_1,a19=b19,a25=b20,goodsid=_instock.goodsid
      from yfstore,_instock
      where b05=a01 and userid=@userid and a10 in(select yfcode from mzmoreyfcode) and _instock.goodsid in(select max(goodsid) from _instock where userid=@userid group by b05)
  end else
  begin
    DECLARE t_cursor CURSOR FOR
      select a01 as goodsno,a07 as pj,a08 as lj,a09 as sl,0 as goodsid
        from yfstore
        where a10=@customercode and a01 in(select b05 from _instock (nolock) where userid=@userid)
      union all
      select b05,b13_1,b16_1,b17*a13,goodsid
        from _instock (nolock),goods (nolock)
        where b05=a01 and userid=@userid
        order by goodsno,goodsid

    OPEN t_cursor
    FETCH NEXT FROM t_cursor into @t_goodsno,@t_pj,@t_lj,@t_sl,@t_goodsid
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @t_goodsno2=@t_goodsno,@t_pj2=@t_pj,@t_Lj2=@t_lj,@s_sl=0
      WHILE @@FETCH_STATUS = 0 and @t_goodsno=@t_goodsno2
      BEGIN
        if @t_pj2<>@t_pj or @t_lj2<>@t_lj
        begin
          insert mzchangeprice(GOODSNO,PROCDATE,OLDPRICE1,OLDPRICE2,NEWPRICE1,NEWPRICE2,YPCOUT,MONEY1,MONEY2,OPERNAME,NOTE,YFCODE,YFNAME)
            values(@t_goodsno,getdate(),@t_lj2,@t_pj2,@t_lj,@t_pj,@s_sl,(@t_lj-@t_lj2)*@s_sl,(@t_pj-@t_pj2)*@s_sl,@opername,'入库价差',@customercode,@customername)
    
          select @t_goodsno2=@t_goodsno,@t_pj2=@t_pj,@t_lj2=@t_lj  --重新赋值
        end   
        select @s_sl=@s_sl+@t_sl
        FETCH NEXT FROM t_cursor into @t_goodsno,@t_pj,@t_lj,@t_sl,@t_goodsid
      END
    END
    CLOSE t_cursor
    DEALLOCATE t_cursor

    update yfstore
      set yfstore.a05=b11,
          a07=b13_1,a08=b16_1,a19=b19,a25=b20,goodsid=_instock.goodsid
      from yfstore,_instock
      where b05=a01 and b09=a10 and userid=@userid and _instock.goodsid in(select max(goodsid) from _instock where userid=@userid group by b05)
  end

  --更新商品代码库中的产地
  update goods
    set a08=b11
    from goods (nolock),_instock (nolock)
    where goods.a01=_instock.b05 and goods.a10=_instock.b24 and _instock.goodsid in(select max(goodsid) from _instock where userid=@userid group by b05)
end else
begin
  /***update mzchangeprice if the price of yfstore is not a same price***/
  insert mzchangeprice(GOODSNO,PROCDATE,OLDPRICE1,OLDPRICE2,NEWPRICE1,NEWPRICE2,YPCOUT,MONEY1,MONEY2,OPERNAME,NOTE,YFCODE,YFNAME)
    select b05,getdate(),b16_1,b13_1,yfstore.a08,yfstore.a07,goods.a13*b17,
           goods.a13*b17*(yfstore.a08-b16_1),
           goods.a13*b17*(yfstore.a07-b13_1),@opername,
         '冲入库价差',yfstore.a10,yfstore.a11
    from _instock,yfstore,goods
    where b05=yfstore.a01 and b09=yfstore.a10 and b05=goods.a01 and
         ( b16_1<>yfstore.a08 or b13_1<>yfstore.a07) and yfstore.a09 <> 0 and userid=@userid
end

/***update yfstore if code is in yfstore table***/
update yfstore
  set yfstore.a09=yfstore.a09+disp.b17*goods.a13,
      yfstore.a14=yfstore.a14+disp.b17*goods.a13,
      yfstore.a26=case when goods.a37=0 then null else goods.A37 end
  from yfstore,(select b09,b05,sum(b17) as b17 from _instock where userid=@userid group by b09,b05) disp,goods
  where disp.b05=goods.a01 and yfstore.a01=disp.b05
    and disp.b09=yfstore.a10

/***insert into yfstore if code is not in yfstore table***/
insert yfstore(A01,A02,A03,A04,A05,A06,A07,A08,A09,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A20,A21,A22,A23,A24,A25,A26,GOODSID,A27,A28,A29)
  select a01,a07,a02,a03,b11,a12,b13_1,b16_1,disp.b17*a13,_instock.b09,b10,a14,a15,disp.b17*a13,0,0,b31,null,b19,null,null,null,null,null,null,case when a37=0 then null else A37 end,goodsid,a45,a46,a47
   from goods,_instock,yfcode,(select b05,b09,sum(b17) as b17 from _instock where userid=@userid group by b05,b09) disp
   where _instock.b05=a01 and _instock.b05=disp.b05 and _instock.b09=disp.b09 and 
         yfcode=_instock.b09  and userid=@userid and 
         _instock.b05 not in(select a01 from yfstore,_instock where a10=b09 and userid=@userid)
         and _instock.goodsid in(select max(goodsid) as goodsid from _instock where userid=@userid group by b05)

/***自动做库房调价盈余表当出库冲单时冲单单价不等于现行单价时***/
insert kfchangeprice
  select b02,_instock.goodsid,b05,b06,b12,b15,e10,b13,b13_1,b16,b16_1,e08,e08_1,e09,e09_1,-(e08-b13)*b17,
        -(e09-b16)*b17,getdate(),@opername,b24,b25,'出库时价差'
    from _instock,store (nolock) 
    where _instock.goodsid=store.goodsid and b24=e12 and userid=@userid and (e08<>b13 or e09<>b16)

/*更新申请单中的相应字段*/
update outstockapply
  set procdate=getdate(),procopername=@opername
  from outstockapply,(select applynum from _instock where userid=@userid group by applynum) disp
  where outstockapply.O02=disp.applynum

return 0
end
GO
