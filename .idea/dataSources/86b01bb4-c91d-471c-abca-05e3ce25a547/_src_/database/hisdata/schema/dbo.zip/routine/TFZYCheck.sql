/*说明：当GROUPKEYNO为NULL时，为退单条记录*/
/*      当GROUPKEYNO不为NULL时，为退组记录*/
/*      当@yjtfflag=1时可直接退费*/
CREATE        PROCEDURE [dbo].[TFZYCheck]
(@zynum int,@keyno numeric=null,@groupkeyno numeric=null,@opername char(10),@operkscode char(4)=null,@yjtfflag int=0)
AS
begin
  declare @t_currentdate datetime
  select @t_currentdate=getdate()

  declare @t_applynum int --医技申请单号
  declare @t_tfkeyno int
  declare @t_fskscode char(10)

  if @groupkeyno is null
  begin
    if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null)
      return 1

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and keyno=@keyno and
                deldate is not null)
      return 2

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and keyno=@keyno and
                yjfpnum is not null)
      return 3


    if @operkscode is not null
    begin
      if not exists(select checkno from zycheck (nolock)
                      where zynum=@zynum and keyno=@keyno
                        and (jzkscode=@operkscode or fskscode=@operkscode))
        return 4
    end

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and keyno=@keyno and tfid is not null)
      return 5
    

    select @t_applynum=null,@t_fskscode=null
    select @t_applynum=yjapplynum,@t_fskscode=fskscode from zycheck where keyno=@keyno and yjcheckdate is not null
    if @t_applynum is not null and @t_fskscode<>@operkscode
      return 6  --如果已审核并且记账科室不等于当前科室则不允许退费
      

    /***Get CFNUM***/
    declare @t_cfnum1 int
    execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum1 output
    /***Get 退费ID号***/
    declare @t_tfid1 numeric(18)
    execute GetUniqueNo 17,@NewUniqueNo=@t_tfid1 output
    /***Get NewGROUPKEYNO***/
    declare @t_groupkeyno1 numeric(18)
    execute GetUniqueNo 14,@NewUniqueNo=@t_groupkeyno1 output

    execute GetUniqueNo 24,@NewUniqueNo=@t_tfkeyno output

    insert zycheck(ZYNUM,CHECKNO,CHECKPRICE,CHECKCOUNT,CHECKMONEY,JZDATE,
                   JZOPER,JSDATE,FPDATE,DELDATE,DELOPER,CHECKNAME,KMNAME,
                   KMCODE,LYKSCODE,LYKSNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
                   YJFPNUM,CHECKLB,CHECKLBNAME,UNITNAME,XJSJNUM,FSKSCODE,
                   FSKSNAME,HSFLAG,HSCODE,HSNAME,YZID,YZUSEDMETHOD,YZFLAG,
                   CFNUM,CDCFNUM,TFID,GROUPKEYNO,ybno,ybkmcode,hzylflag,yjapplynum,tfkeyno,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID,scale)
      select ZYNUM,CHECKNO,CHECKPRICE,-CHECKCOUNT,-CHECKMONEY,@t_currentdate,
             @opername,JSDATE,FPDATE,DELDATE,DELOPER,CHECKNAME,KMNAME,
             KMCODE,LYKSCODE,LYKSNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
             YJFPNUM,CHECKLB,CHECKLBNAME,UNITNAME,XJSJNUM,FSKSCODE,
             FSKSNAME,HSFLAG,HSCODE,HSNAME,YZID,YZUSEDMETHOD,2,
             @t_cfnum1,CFNUM,@t_tfid1,@T_GROUPKEYNO1,ybno,ybkmcode,hzylflag,yjapplynum,@t_tfkeyno,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID,scale
        from zycheck (nolock)
        where keyno=@keyno and zynum=@zynum

    update zycheck
      set cdcfnum=@t_cfnum1,tfid=@t_tfid1,tfkeyno=@t_tfkeyno
      where keyno=@keyno and zynum=@zynum


    /***Get New ApplyNum医技申请单号***/
    update yj_applysheet
      set yjcancddate=@t_currentdate,yjcancdopername=@opername
      where applynum=@t_applynum

    declare @t_newyjapplynum1 numeric(18)
    execute GetUniqueNo 20,@NewUniqueNo=@t_newyjapplynum1 output

    insert yj_applysheet(ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,
                         ItemCode,ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,
                         ApplyKSCode,ApplyKSName,ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,
                         YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,CDApplyNum)
      select @t_newyjapplynum1,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,
             ItemCode,ItemName,ItemPrice,-ItemCount,-ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,
             ApplyKSCode,ApplyKSName,applyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,@OperName,@t_currentdate,
             YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,@t_applynum
        from yj_applysheet (nolock)
        where applynum=@t_applynum

    update yj_applysheet
      set cdapplynum=@t_newyjapplynum1
      where applynum=@t_applynum


    update mbase
      set m25=m25-checkmoney
      from mbase,zycheck
      where m01=zynum and zynum=@zynum and keyno=@keyno

    return 0
  end else
  begin
    if exists(select m01 from mbase (nolock) where m01=@zynum and m19 is not null)
      return 1

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and groupkeyno=@groupkeyno and 
               deldate is not null)
      return 2

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and groupkeyno=@groupkeyno and
                yjfpnum is not null)
      return 3


    if @operkscode is not null
    begin
      if not exists(select checkno from zycheck (nolock)
                      where zynum=@zynum and groupkeyno=@groupkeyno
                        and (jzkscode=@operkscode or fskscode=@operkscode))
        return 4
    end

    if exists(select zynum from zycheck (nolock) where zynum=@zynum and groupkeyno=@groupkeyno and tfid is not null)
      return 5


    select @t_applynum=null,@t_fskscode=null
    select @t_applynum=yjapplynum,@t_fskscode=fskscode from zycheck where groupkeyno=@groupkeyno and yjcheckdate is not null
    if @t_applynum is not null and ((@t_fskscode<>@operkscode) or (@t_fskscode is not null and @operkscode is null))
      return 6  --如果已审核并且记账科室不等于当前科室则不允许退费

    /***Get CFNUM***/
    declare @t_cfnum int
    execute GetUniqueNo 6,@NewUniqueNo=@t_cfnum output

    /***Get 退费ID号***/
    declare @t_tfid numeric(18)
    execute GetUniqueNo 17,@NewUniqueNo=@t_tfid output

    /***Get NewGROUPKEYNO***/
    declare @t_groupkeyno numeric(18)
    execute GetUniqueNo 14,@NewUniqueNo=@t_groupkeyno output

    /***在组套中生成TFKEYNO，每条记录一个号，退费记录与此号对应***/
    declare @t_keyno int

    DECLARE zycheck_cursor CURSOR FOR
    select keyno
      from zycheck (nolock)
      where groupkeyno=@groupkeyno and zynum=@zynum
    open zycheck_cursor 
    fetch next from zycheck_cursor into @t_keyno
    while @@fetch_status=0
    begin
      execute GetUniqueNo 24,@NewUniqueNo=@t_tfkeyno output
      update zycheck
      set tfkeyno=@t_tfkeyno
        where keyno=@t_keyno

      fetch next from zycheck_cursor into @t_keyno
    end
    close zycheck_cursor
    deallocate zycheck_cursor

    insert zycheck(ZYNUM,CHECKNO,CHECKPRICE,CHECKCOUNT,CHECKMONEY,JZDATE,
                   JZOPER,JSDATE,FPDATE,DELDATE,DELOPER,CHECKNAME,KMNAME,
                   KMCODE,LYKSCODE,LYKSNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
                   YJFPNUM,CHECKLB,CHECKLBNAME,UNITNAME,XJSJNUM,FSKSCODE,
                   FSKSNAME,HSFLAG,HSCODE,HSNAME,YZID,YZUSEDMETHOD,YZFLAG,
                   CFNUM,CDCFNUM,TFID,GROUPCODE,GROUPNAME,GROUPPRICE,GROUPCOUNT,
                   GROUPKEYNO,ybno,ybkmcode,hzylflag,yjapplynum,tfkeyno,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID)
      select ZYNUM,CHECKNO,CHECKPRICE,-CHECKCOUNT,-CHECKMONEY,@t_currentdate,
             @opername,JSDATE,FPDATE,DELDATE,DELOPER,CHECKNAME,KMNAME,
             KMCODE,LYKSCODE,LYKSNAME,YSCODE,YSNAME,YSKSCODE,YSKSNAME,
             YJFPNUM,CHECKLB,CHECKLBNAME,UNITNAME,XJSJNUM,FSKSCODE,
             FSKSNAME,HSFLAG,HSCODE,HSNAME,YZID,YZUSEDMETHOD,2,
             @t_cfnum,CFNUM,@t_tfid,GROUPCODE,GROUPNAME,GROUPPRICE,-GROUPCOUNT,
             @t_groupkeyno,ybno,ybkmcode,hzylflag,yjapplynum,tfkeyno,zgysname,applicationflag,yjcheckdate,yjcheckoper,SubYZID
        from zycheck (nolock)
        where groupkeyno=@groupkeyno and zynum=@zynum


    update zycheck
      set cdcfnum=@t_cfnum,tfid=@t_tfid
      where groupkeyno=@groupkeyno and zynum=@zynum
   

    /***Get New ApplyNum医技申请单号***/
    update yj_applysheet
      set yjcancddate=@t_currentdate,yjcancdopername=@opername
      where applynum=@t_applynum

    declare @t_newyjapplynum2 numeric(18)
    execute GetUniqueNo 20,@NewUniqueNo=@t_newyjapplynum2 output
    insert yj_applysheet(ApplyNum,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,
                         ItemCode,ItemName,ItemPrice,ItemCount,ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,
                         ApplyKSCode,ApplyKSName,ApplyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,JZOperName,JZDate,
                         YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,cdapplynum)
      select @t_newyjapplynum2,PatientName,PatientSex,PatientKind,PatientOutNum,PatientInNum,PatientNum,
             ItemCode,ItemName,ItemPrice,-ItemCount,-ItemMoney,ItemKSCode,ItemKSName,ApplyYSCode,ApplyYSName,
             ApplyKSCode,ApplyKSName,applyDate,YJCheckOperCode,YJCheckOperName,YJCheckDate,@OperName,@t_currentdate,
             YJCanCDDate,YJCanCDOperCode,YJCanCDOperName,@t_applynum
        from yj_applysheet (nolock)
        where applynum=@t_applynum

    update yj_applysheet
      set cdapplynum=@t_newyjapplynum2
      where applynum=@t_applynum

  
    declare @t_sumcheckmoney numeric(12,2)
    select @t_sumcheckmoney=sum(checkmoney) from zycheck where zynum=@zynum and groupkeyno=@groupkeyno
    update mbase
      set m25=m25-case when @t_sumcheckmoney is null then 0 else @t_sumcheckmoney end
      where m01=@zynum

    return 0
  end
end
GO
