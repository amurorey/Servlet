


CREATE VIEW dbo.MZALLFPVIEW
AS
SELECT fpnum,fpname,fpmoney,yp_money,check_money,fpdate,opername,jsdate,deldate,convert(char(2),fpdate,2)+'年' as fpyear,convert(char(2),fpdate,10)+'月' as fpmonth,convert(char(2),fpdate,5)+'日' as fpday
FROM mzinvoice (nolock)
WHERE deldate is null
UNION ALL
SELECT fpnum,fpname,fpmoney,yp_money,check_money,fpdate,opername,jsdate,deldate,convert(char(2),fpdate,2)+'年' as fpyear,convert(char(2),fpdate,10)+'月' as fpmonth,convert(char(2),fpdate,5)+'日' as fpday
FROM mzinvoicehis (nolock)
WHERE deldate is null


GO
