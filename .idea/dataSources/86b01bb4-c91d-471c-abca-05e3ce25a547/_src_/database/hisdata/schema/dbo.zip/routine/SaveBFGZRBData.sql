CREATE      PROCEDURE [dbo].[SaveBFGZRBData]
(@kscode [char] (4),
 @ksname [char] (20),
 @pcdate [datetime],
 @opername [char] (10),
 @b01 [int],
 @b02 [int],
 @b03 [int],
 @b04 [int],
 @b05 [int],
 @b06 [int],
 @b07 [int],
 @b08 [int],
 @b09 [int],
 @b10 [int],
 @b11 [int],
 @b12 [int],
 @b13 [int],
 @b14 [int],
 @b15 [int],
 @b16 [int],
 @b17 [int],
 @b18 [int],
 @b19 [int],
 @b20 [int],
 @b21 [int],
 @b22 [int],
 @b23 [int],
 @b24 [int],
 @b25 [int],
 @b26 [int],
 @b27 [int])

 AS
begin
  declare @t_opername char(10)
  set @t_opername=null
  select @t_opername=opername from ba_bfgzrb (nolock) where kscode=@kscode and pcdate>=@pcdate and pcdate<dateadd(day,1,@pcdate)
  if @t_opername is not null 
    return 1

  delete ba_bfgzrb where kscode=@kscode and pcdate>=@pcdate and pcdate<dateadd(day,1,@pcdate)

  insert ba_bfgzrb(kscode,ksname,pcdate,Operdate,opername,b01,b02,b03,b04,b05,b06,b07,b08,
         b09,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21,b22,b23,b24,b25,b26,b27)
  values(@kscode,@ksname,@pcdate,getdate(),@opername,@b01,@b02,@b03,@b04,@b05,@b06,@b07,@b08,
         @b09,@b10,@b11,@b12,@b13,@b14,@b15,@b16,@b17,@b18,@b19,@b20,@b21,@b22,@b23,@b24,@b25,@b26,@b27)

  update ba_bqgzrb
    set a11=b01,
        a12=b03,
        a13=b02-b03
    from ba_bqgzrb,ba_bfgzrb
    where ba_bqgzrb.ksdm=ba_bfgzrb.kscode and ba_bqgzrb.pcdate=ba_bfgzrb.pcdate
          and ba_bfgzrb.pcdate>=@pcdate and ba_bfgzrb.pcdate<dateadd(day,1,@pcdate)

  return 0

end
GO
