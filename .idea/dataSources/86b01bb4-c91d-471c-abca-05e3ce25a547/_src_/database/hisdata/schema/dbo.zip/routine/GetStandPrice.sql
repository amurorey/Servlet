CREATE PROCEDURE [dbo].[GetStandPrice]
(@RetVal char(1024)='' output)
AS
begin
  if exists(select acc_code from standcheckcode where acc_code not in(select code from kmcode (nolock)))
  begin
    declare @t_disptext char(100)
    DECLARE checkkm_cursor CURSOR FOR
      select '标准项目中的财务科目代码"'+acc_code+'"在HIS科目代码中没有设置！' as disptext
        from standcheckcode
             where acc_code not in(select code from kmcode (nolock))
    OPEN checkkm_cursor
    FETCH NEXT FROM checkkm_cursor into @t_disptext
    WHILE @@FETCH_STATUS = 0
    BEGIN
      select @retval=@retval+@t_disptext+char(13)

      FETCH NEXT FROM checkkm_cursor into @t_disptext
    END
    CLOSE checkkm_cursor
    DEALLOCATE checkkm_cursor

    return 1
  end

  declare @currentdate datetime
  select @currentdate=getdate()

  update checkcode
    set code=it_code,
        name=it_name,
        kmcode=acc_code,
        kmname=kmcode.name,
        unitname=unit,
        price=standcheckcode.price,
        minprice=price_min,
        maxprice=price_max,
        updatedate=@currentdate
    from standcheckcode,checkcode,kmcode
      where it_code=checkcode.code and checkcode.kmcode=kmcode.code

  /*更新医保属性*/
  update checkcode
    set checklb=case when rtrim(safe_class)='甲类' then '1' 
                     when rtrim(safe_class)='乙类' then '2'
                     when rtrim(safe_class)='丙类' then '3'
                     when rtrim(safe_class)='定额' then '9'
                end,
        checklbname=safe_class
    from checkcode,standcheckcode
    where code=it_code and standflag=1


  /*组套替换*/
  update checkgroupsheet
    set checkprice=price,checkmoney=price*checkcount
    from checkgroupsheet,checkcode
    where checkcode=code and standflag=1




  insert checkcode(CODE,NAME,PRICE,PYM,SPM,KMCODE,KMNAME,UNITNAME,UNCHANGEPRICE,
                   MINPRICE,MAXPRICE,STANDFLAG,UPDATEDATE)
    select it_code,it_name,price,'','',acc_code,kmcode.name,unit,1,
           price_min,price_max,1,@currentdate
      from standcheckcode,kmcode (nolock)
        where acc_code=code and it_code not in(select code from checkcode (nolock))


  /*更新注销标志*/
  update checkcode
    set deldate=@currentdate
    from checkcode,standcheckcode
      where code=it_code and logout='1'

  /*更新护士工作量标志*/
  update checkcode
    set hsflag=1
    where kmcode='F'

  return 0
end
GO
