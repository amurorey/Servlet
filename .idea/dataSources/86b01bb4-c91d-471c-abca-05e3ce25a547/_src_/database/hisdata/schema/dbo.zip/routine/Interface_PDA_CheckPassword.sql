-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Interface_PDA_CheckPassword]
(@UserCode varchar(20),@Password varchar(10))
AS
BEGIN
	SET NOCOUNT ON;
  

    if exists(select code from YSCODE (nolock) where CODE=@UserCode and [PASSWORD]=@Password)
      select 0 as ret
    else
      select -1 as ret
END
GO
