CREATE   PROCEDURE [dbo].[ST_CONFIRMOPERATION_DOCARE]
(@SCHEDULE_ID numeric(18),@OPERATING_DATE datetime,@OPERATING_ROOM_NO char(20),@SEQUENCE int,
@ANESTHESIA_DOCTOR char(20),@ANESTHESIA_METHOD varchar(40),@OPERATION_NUSRSE1 char(20),@OPERATION_NUSRSE2 char(20))
AS
begin
  if exists(select zynum from operationapply (nolock) where applynum=@SCHEDULE_ID and confirmdate is not null)
    return -1  --已被确认

  if exists(select zynum from operationapply (nolock) where applynum=@SCHEDULE_ID and deldate is not null)
    return -2  --已被确认

  update operationapply
    set date_plan=@OPERATING_DATE,prepareroom=@OPERATING_ROOM_NO,unitstimes=@SEQUENCE,
          mzname=@ANESTHESIA_METHOD,mzysname=@ANESTHESIA_DOCTOR,hsname_tour=@OPERATION_NUSRSE1,
          HSName_Wash=@OPERATION_NUSRSE2,
          confirmdate=getdate(),confirmoper='手术室确认'
    where applynum=@SCHEDULE_ID

  return 0
end
GO
