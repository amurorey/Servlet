












CREATE VIEW ZYCheckSearchView
AS
SELECT zynum, 'O' + CONVERT(char(20), keyno) as keyno, checkno, checkname, checkprice, 
      jzdate
FROM zycheck,checkcode(nolock)
WHERE checkno=code and standflag=1
UNION ALL
SELECT zynum, 'I' + CONVERT(char(20), keyno), checkno, checkname, checkprice, 
      jzdate
FROM zycheckhis,checkcode(nolock)
WHERE checkno=code and standflag=1


GO
