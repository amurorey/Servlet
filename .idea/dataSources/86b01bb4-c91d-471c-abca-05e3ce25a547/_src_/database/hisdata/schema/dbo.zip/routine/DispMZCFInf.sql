CREATE PROCEDURE [dbo].[DispMZCFInf]
(@fpnum int) with recompile
AS
begin
  if exists(select * from mzcfinf where fpnum=@fpnum)
    select cfnum,fpnum,ysname,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,fydate,yfcancddate,yfcancdopername,fyopername
      from mzcfinf (nolock)
      where fpnum=@fpnum
  else
    select cfnum,fpnum,ysname,cfflag,cfprice,cfcount,cfmoney,yfcode,yfname,fydate,yfcancddate,yfcancdopername,fyopername
      from mzcfinfhis (nolock)
      where fpnum=@fpnum
end
GO
