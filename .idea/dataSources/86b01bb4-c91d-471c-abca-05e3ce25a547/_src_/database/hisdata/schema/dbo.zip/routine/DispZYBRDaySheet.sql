CREATE PROCEDURE [dbo].[DispZYBRDaySheet] 
(@lykscode char(4),@begdate datetime,@enddate datetime,@groupflag int) with recompile
AS
begin
  if @groupflag=0
  begin
    select zynum,0 as flag,m01,m04,m11,m13,m16,m17,m18,jzdate,goodsname as xmname,unitname,cfcount*ypcount as quantity,ypprice as price,ypmoney*cfcount as xmmoney,yplbname as xmlbname,yplb as xmlbcode
      from zycfypk,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null    union all
    select zynum,0,m01,m04,m11,m13,m16,m17,m18,jzdate,goodsname as xmname,unitname,cfcount*ypcount as quantity,ypprice as price,ypmoney*cfcount as xmmoney,yplbname,yplb
      from zycfypkhis,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    union all
    select zynum,1,m01,m04,m11,m13,m16,m17,m18,jzdate,checkname,unitname,checkcount,checkprice,checkmoney,checklbname,checklb
      from zycheck,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    union all
    select zynum,1,m01,m04,m11,m13,m16,m17,m18,jzdate,checkname,unitname,checkcount,checkprice,checkmoney,checklbname,checklb      from zycheckhis,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    order by zynum,flag,jzdate
  end else  begin
    select zynum,0 as flag,m01,m04,m11,m13,m16,m17,m18,jzdate,goodsname as xmname,unitname,cfcount*ypcount as quantity,ypprice as price,ypmoney*cfcount as xmmoney,yplbname as xmlbname,yplb as xmlbcode
      into #zybrsheet
      from zycfypk,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    union all
    select zynum,0,m01,m04,m11,m13,m16,m17,m18,jzdate,goodsname as xmname,unitname,cfcount*ypcount as quantity,ypprice as price,ypmoney*cfcount as xmmoney,yplbname,yplb
      from zycfypkhis,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    union all
    select zynum,1,m01,m04,m11,m13,m16,m17,m18,jzdate,checkname,unitname,checkcount,checkprice,checkmoney,checklbname,checklb
      from zycheck,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null
    union all
    select zynum,1,m01,m04,m11,m13,m16,m17,m18,jzdate,checkname,unitname,checkcount,checkprice,checkmoney,checklbname,checklb
      from zycheckhis,mbase (nolock)
      where zynum=m01 and m16=@lykscode and jzdate>=@begdate and jzdate<@enddate and deldate is null and m19 is null


    select zynum,flag,xmlbcode,xmlbname,xmname,unitname,price,sum(quantity) as quantity, sum(xmmoney) as xmmoney
      from #zybrsheet
      group by zynum,flag,xmlbcode,xmlbname,xmname,unitname,price
  end
end
GO
