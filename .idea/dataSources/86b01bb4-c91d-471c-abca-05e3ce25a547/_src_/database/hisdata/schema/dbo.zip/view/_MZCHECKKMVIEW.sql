


CREATE VIEW _MZCHECKKMVIEW(kmname,kmcode,summoney,userid)
AS
  select rtrim(kmname),kmcode,checkmoney,userid from _mzcheck


GO
