CREATE  PROCEDURE [dbo].[UTST_PATIENT_LIST]
(@ward_code varchar(10))
AS
begin
  SELECT '0' AS patient_kind, CONVERT(char(20), M01) AS patient_code, 
        M04 AS patient_name, m02 as cost_type,
        CASE WHEN m05 = '男' THEN '1' WHEN m05 = '女' THEN '2' ELSE '3' END AS patient_sex,
        M06 AS patient_birthday, M03 AS medical_card, null AS office, M35 AS doctor, 
        m16 AS ward_code, M18 AS bed_no, M40 AS diagnosis, NULL AS remark_info, 
        CASE WHEN m19 IS NULL THEN '1' ELSE '0' END AS In_Hopital_Flag,--此字段为科华标准接口用
        CASE WHEN m19 IS NULL THEN '1' ELSE '0' END AS Expr1,--此字段为科华红河州医院用
        NULL AS other1, NULL AS other2
  FROM dbo.MBASE WITH (nolock) 
  where m16=@ward_code and m51 is not null and m53 is null
end
GO
