


CREATE VIEW MZFPKMVIEW AS
  select fpnum,kmcode,kmname,ypmoney*cfcount as kmmoney,fpdate
  from mzcfypk (nolock) where deldate is null
union all
  select fpnum,kmcode,kmname,checkmoney,fpdate
  from mzcheck (nolock) where deldate is null


GO
